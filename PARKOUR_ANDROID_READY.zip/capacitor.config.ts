import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.lorddeveloper.parkour',
  appName: 'PARKOUR',
  webDir: 'dist',
  server: { androidScheme: 'https' },
  android: { backgroundColor: '#07090d' },
};

export default config;
