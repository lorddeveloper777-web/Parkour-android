import * as THREE from 'three';
import { World, REGION_NAMES } from './world';
import { Player } from './player';

export type CType = 'reach' | 'race' | 'nofall' | 'collect' | 'rival' | 'move' | 'precision' | 'height' | 'speed' | 'escape' | 'explore' | 'final';
export interface ChallengeDef {
  id: string; name: string; desc: string; goals: string[]; type: CType; region: number; a: number; b: number; minLevel: number; xp: number; diff: number;
  need?: { move?: Record<string, number>; orbs?: number; speedKmh?: number; secret?: boolean }; rivalSpeed?: number; chaser?: number; times?: [number, number, number]; icon: string;
}
export const MOVE_NAMES: Record<string, string> = { wallrun: 'Wall runs', vault: 'Vaults', slide: 'Slides', walljump: 'Wall jumps', climb: 'Escaladas', swing: 'Balanços', roll: 'Rolamentos' };

export const DEFS: ChallengeDef[] = [
  { id: 'c1', name: 'Primeiros Passos', desc: 'Corra pelos primeiros telhados até o ponto final.', goals: ['Chegue ao ponto final', 'Aprenda a pular entre prédios'], type: 'reach', region: 0, a: 0, b: 0.4, minLevel: 1, xp: 150, diff: 1.35, icon: '👟' },
  { id: 'c2', name: 'Corrida Rápida', desc: 'Atravesse o Distrito Velho antes do tempo acabar.', goals: ['Chegue ao final antes do tempo', 'Mantenha o fluxo'], type: 'race', region: 0, a: 0, b: 1, minLevel: 1, xp: 250, diff: 1.0, icon: '⏱️' },
  { id: 'c3', name: 'Sem Cair', desc: 'Atravesse a região sem tocar o chão das ruas.', goals: ['Não toque o chão', 'Não morra'], type: 'nofall', region: 0, a: 0.3, b: 1, minLevel: 1, xp: 250, diff: 1.15, icon: '🧗' },
  { id: 'c4', name: 'Coletor de Orbes', desc: 'Colete todos os orbes azuis espalhados pelos telhados.', goals: ['Colete todos os orbes', 'Depois, chegue ao final'], type: 'collect', region: 0, a: 0.1, b: 0.9, minLevel: 1, xp: 250, diff: 1.3, need: { orbs: 8 }, icon: '🔷' },
  { id: 'c5', name: 'Rival do Telhado', desc: 'Corra contra um traceur rival pela Zona Industrial.', goals: ['Chegue antes do rival'], type: 'rival', region: 1, a: 0, b: 0.5, minLevel: 2, xp: 350, diff: 1.15, rivalSpeed: 6.4, icon: '🏁' },
  { id: 'c6', name: 'Mestre do Muro', desc: 'Use wall runs e wall jumps para chegar ao fim.', goals: ['2 wall runs', '1 wall jump', 'Chegue ao final'], type: 'move', region: 1, a: 0.4, b: 1, minLevel: 3, xp: 300, diff: 1.3, need: { move: { wallrun: 2, walljump: 1 } }, icon: '🧱' },
  { id: 'c7', name: 'Precisão Extrema', desc: 'Sem tocar o chão e com anéis pequenos. Cada salto conta.', goals: ['Não toque o chão', 'Passe pelos anéis'], type: 'precision', region: 2, a: 0, b: 0.5, minLevel: 4, xp: 450, diff: 1.2, icon: '🎯' },
  { id: 'c8', name: 'Velocidade Máxima', desc: 'Passe de 52 km/h antes de cruzar a linha final.', goals: ['Alcance 52 km/h', 'Chegue ao final'], type: 'speed', region: 2, a: 0.45, b: 1, minLevel: 4, xp: 400, diff: 1.15, need: { speedKmh: 52 }, icon: '⚡' },
  { id: 'c9', name: 'Fuja da Área', desc: 'O alarme disparou! Fuja antes que a perseguição alcance você.', goals: ['Fique à frente do perseguidor'], type: 'escape', region: 3, a: 0, b: 0.5, minLevel: 5, xp: 450, diff: 1.25, chaser: 2.6, icon: '🚨' },
  { id: 'c10', name: 'Parkour Avançado', desc: 'Use todos os movimentos no caminho até o final.', goals: ['2 vaults', '1 slide', '1 wall run', '1 escalada'], type: 'move', region: 3, a: 0.5, b: 1, minLevel: 6, xp: 500, diff: 1.45, need: { move: { vault: 2, slide: 1, wallrun: 1, climb: 1 } }, icon: '🥷' },
  { id: 'c11', name: 'Exploração', desc: 'Descubra a rota secreta escondida no Canteiro de Obras.', goals: ['Encontre a estrela roxa'], type: 'explore', region: 2, a: 0.2, b: 0.8, minLevel: 4, xp: 350, diff: 1, times: [90, 150, 240], icon: '🔍' },
  { id: 'c12', name: 'Altura Extrema', desc: 'Suba a base da Torre Central o mais rápido possível.', goals: ['Alcance a altura indicada'], type: 'height', region: 4, a: 0, b: 0.5, minLevel: 7, xp: 550, diff: 1.3, icon: '🏙️' },
  { id: 'c13', name: 'Topo da Torre', desc: 'Escale a Torre Central até o heliponto.', goals: ['Chegue ao topo'], type: 'reach', region: 4, a: 0, b: 1, minLevel: 8, xp: 650, diff: 1.3, icon: '🗼' },
  { id: 'final', name: 'CORRIDA FINAL', desc: 'Atravesse toda a cidade: corrida, salto, vault, wall run, escalada, slide e a Torre.', goals: ['Cruze todas as regiões', 'Chegue ao topo da Torre Central'], type: 'final', region: -1, a: 0, b: 1, minLevel: 1, xp: 1500, diff: 1.2, icon: '👑' },
];
export const MAIN_IDS = DEFS.filter((d) => d.id !== 'final').map((d) => d.id);

export interface Ring { x: number; y: number; z: number; yaw: number; r: number }
export interface Resolved {
  def: ChallengeDef; startIdx: number; endIdx: number; rings: Ring[]; path: THREE.Vector3[]; length: number; times: [number, number, number]; orbs: THREE.Vector3[]; secretIdx: number; start: Ring;
}
export function resolveAll(world: World): Record<string, Resolved> {
  const out: Record<string, Resolved> = {}; const R = world.route; const n = R.length;
  const range = (reg: number): [number, number] => { let a = -1, b = -1; R.forEach((p, i) => { if (p.region === reg) { if (a < 0) a = i; b = i; } }); return a < 0 ? [0, n - 1] : [a, b]; };
  for (const def of DEFS) {
    let lo = 0, hi = n - 1; if (def.region >= 0) [lo, hi] = range(def.region);
    const si = Math.round(lo + (hi - lo) * def.a), ei = Math.max(si + 2, Math.round(lo + (hi - lo) * def.b));
    const startIdx = Math.min(si, n - 3), endIdx = Math.min(ei, n - 1);
    const ringR = def.type === 'precision' ? 2.4 : 3.6; const step = def.type === 'final' ? 9 : def.type === 'precision' ? 4 : 7;
    const rings: Ring[] = []; const mk = (i: number, r: number): Ring => { const p = R[i], q = R[Math.min(n - 1, i + 1)], pr = R[Math.max(0, i - 1)]; const t = i === n - 1 ? p : q; return { x: p.x, y: p.y, z: p.z, yaw: Math.atan2(-(t.x - pr.x), -(t.z - pr.z)), r }; };
    for (let i = startIdx + step; i < endIdx; i += step) rings.push(mk(i, ringR));
    rings.push(mk(endIdx, ringR + 0.6));
    const path: THREE.Vector3[] = []; for (let i = startIdx; i <= endIdx; i++) path.push(new THREE.Vector3(R[i].x, R[i].y, R[i].z));
    const length = world.routeLen(startIdx, endIdx); let climb = 0; for (let i = startIdx; i < endIdx; i++) climb += Math.max(0, R[i + 1].y - R[i].y);
    const m = def.diff;
    const times: [number, number, number] = def.times ? def.times : [(length / 8.4 + 6 + climb * 0.35) * m, (length / 6.4 + 10 + climb * 0.55) * m, (length / 4.6 + 16 + climb * 0.8) * m].map((v) => Math.round(v)) as [number, number, number];
    const orbs: THREE.Vector3[] = [];
    if (def.type === 'collect') { const cnt = def.need?.orbs || 8; for (let k = 0; k < cnt; k++) { const i = Math.round(startIdx + 1 + (endIdx - startIdx - 2) * (k / (cnt - 1))); orbs.push(new THREE.Vector3(R[i].x, R[i].y + 1.6, R[i].z)); } }
    let secretIdx = -1;
    if (def.type === 'explore') { const mid = R[Math.round((startIdx + endIdx) / 2)]; let best = 1e9; world.secrets.forEach((s, i) => { const d = Math.hypot(s.x - mid.x, s.z - mid.z); if (d < best) { best = d; secretIdx = i; } }); }
    const s0 = mk(startIdx, 3.6);
    out[def.id] = { def, startIdx, endIdx, rings, path, length, times, orbs, secretIdx, start: s0 };
  }
  return out;
}
export const regionName = (i: number) => REGION_NAMES[i] || 'Cidade';

export class ChallengeRun {
  state: 'countdown' | 'running' | 'done' | 'failed' = 'countdown'; countdown = 3.4; time = 0; nextRing = 0; orbs = 0; moves: Record<string, number> = {}; maxKmh = 0;
  rivalDist = 0; rivalPos = new THREE.Vector3(); rivalYaw = 0; rivalAir = 0; chaserIdx = 0; progIdx = 0; failReason = ''; lastRing: Ring; secretFound = false; startScore = 0;
  segLen: number[] = []; totalLen = 0; lastCountInt = 4; justPassed = false;
  constructor(public r: Resolved, private world: World) {
    this.lastRing = r.start; this.progIdx = r.startIdx; this.chaserIdx = r.startIdx - 4;
    let s = 0; for (let i = 0; i < r.path.length - 1; i++) { const l = Math.hypot(r.path[i + 1].x - r.path[i].x, r.path[i + 1].z - r.path[i].z); this.segLen.push(l); s += l; } this.totalLen = s;
    this.rivalPos.copy(r.path[0]);
  }
  get limit() { return this.r.times[2]; }
  note(move: string) { this.moves[move] = (this.moves[move] || 0) + 1; }
  requirementsMet() {
    const n = this.r.def.need; if (!n) return true;
    if (n.orbs && this.orbs < n.orbs) return false;
    if (n.speedKmh && this.maxKmh < n.speedKmh) return false;
    if (n.move) for (const k of Object.keys(n.move)) if ((this.moves[k] || 0) < n.move[k]) return false;
    return true;
  }
  progressText(): string[] {
    const n = this.r.def.need, out: string[] = [];
    if (n?.orbs) out.push(`Orbes ${this.orbs}/${n.orbs}`);
    if (n?.speedKmh) out.push(`Velocidade ${Math.round(this.maxKmh)}/${n.speedKmh} km/h`);
    if (n?.move) for (const k of Object.keys(n.move)) out.push(`${MOVE_NAMES[k] || k} ${Math.min(this.moves[k] || 0, n.move[k])}/${n.move[k]}`);
    if (this.r.def.type === 'rival') out.push('Rival: ' + Math.round(100 * this.rivalDist / Math.max(1, this.totalLen)) + '%');
    if (this.r.def.type === 'escape') out.push('Perseguidor: ' + Math.max(0, Math.round((this.progIdx - this.chaserIdx) * 15)) + ' m');
    return out;
  }
  /** retorna 'finish' | 'fail' | null */
  update(dt: number, pl: Player, grounded: boolean): 'finish' | 'fail' | null {
    this.justPassed = false;
    if (this.state === 'countdown') { this.countdown -= dt; if (this.countdown <= 0) { this.state = 'running'; } return null; }
    if (this.state !== 'running') return null;
    this.time += dt; this.maxKmh = Math.max(this.maxKmh, pl.speedKmh);
    const def = this.r.def, R = this.world.route;
    if (this.time > this.limit && def.type !== 'explore') { this.failReason = 'Tempo esgotado'; this.state = 'failed'; return 'fail'; }
    if (def.type === 'explore' && this.time > this.limit) { this.failReason = 'Tempo esgotado'; this.state = 'failed'; return 'fail'; }
    if ((def.type === 'nofall' || def.type === 'precision') && grounded && pl.pos.y < 1.0 && pl.state !== 'mantle') { this.failReason = 'Você tocou o chão'; this.state = 'failed'; return 'fail'; }
    // progresso ao longo da rota
    for (let i = Math.max(0, this.progIdx - 2); i < Math.min(R.length, this.progIdx + 8); i++) {
      const p = R[i]; if (Math.abs(pl.pos.x - p.x) < p.hx + 1.5 && Math.abs(pl.pos.z - p.z) < p.hz + 1.5 && Math.abs(pl.pos.y - p.y) < 3 && i > this.progIdx) this.progIdx = i;
    }
    if (def.type === 'rival') {
      this.rivalDist += (this.rivalDist < this.totalLen ? def.rivalSpeed! : 0) * dt; let d = this.rivalDist, i = 0;
      while (i < this.segLen.length - 1 && d > this.segLen[i]) { d -= this.segLen[i]; i++; }
      const a = this.r.path[i], b = this.r.path[Math.min(i + 1, this.r.path.length - 1)], u = Math.min(1, d / Math.max(0.01, this.segLen[i] || 1));
      this.rivalPos.lerpVectors(a, b, u); const gapStart = 0.55; this.rivalAir = (u > gapStart ? Math.sin((u - gapStart) / (1 - gapStart) * Math.PI) : 0);
      this.rivalPos.y += this.rivalAir * 0.6; this.rivalYaw = Math.atan2(-(b.x - a.x), -(b.z - a.z));
      if (this.rivalDist >= this.totalLen - 1) { this.failReason = 'O rival chegou primeiro'; this.state = 'failed'; return 'fail'; }
    }
    if (def.type === 'escape') {
      this.chaserIdx += dt / def.chaser!; if (this.progIdx <= this.chaserIdx) { this.failReason = 'Você foi alcançado'; this.state = 'failed'; return 'fail'; }
    }
    if (def.type === 'explore') { if (this.secretFound) { this.state = 'done'; return 'finish'; } return null; }
    // anéis
    const ring = this.r.rings[this.nextRing];
    if (ring) {
      const dx = pl.pos.x - ring.x, dz = pl.pos.z - ring.z, dy = pl.pos.y + 1 - ring.y;
      const last = this.nextRing === this.r.rings.length - 1;
      if (dx * dx + dz * dz < ring.r * ring.r * (last ? 1.8 : 1.3) && dy > -2.5 && dy < 6) {
        if (last && !this.requirementsMet()) return null;
        this.lastRing = ring; this.nextRing++; this.justPassed = true;
        if (last) { this.state = 'done'; return 'finish'; }
      }
    }
    return null;
  }
  currentRing(): Ring | null { return this.r.rings[this.nextRing] || null; }
}
