import * as THREE from 'three';
import { SKY_VERT, SKY_FRAG, U, WEATHER, WeatherPreset } from './materials';
import { World } from './world';

const FINISH = `#include <tonemapping_fragment>\n#include <colorspace_fragment>`;

export class Particles {
  points: THREE.Points; max = 900; cur = 0;
  private pos: Float32Array; private col: Float32Array; private size: Float32Array; private alpha: Float32Array;
  private vel: Float32Array; private life: Float32Array; private maxLife: Float32Array; private grav: Float32Array; private s0: Float32Array; private s1: Float32Array; private drag: Float32Array;
  mat: THREE.ShaderMaterial; private c = new THREE.Color();
  constructor() {
    const n = this.max;
    this.pos = new Float32Array(n * 3); this.col = new Float32Array(n * 3); this.size = new Float32Array(n); this.alpha = new Float32Array(n);
    this.vel = new Float32Array(n * 3); this.life = new Float32Array(n); this.maxLife = new Float32Array(n).fill(1); this.grav = new Float32Array(n); this.s0 = new Float32Array(n); this.s1 = new Float32Array(n); this.drag = new Float32Array(n);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aColor', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aSize', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aAlpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    this.mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { uScale: { value: 600 } },
      vertexShader: `attribute float aSize; attribute float aAlpha; attribute vec3 aColor; varying vec3 vC; varying float vA; uniform float uScale;
        void main(){ vC=aColor; vA=aAlpha; vec4 mv = modelViewMatrix*vec4(position,1.0); gl_PointSize = aSize*uScale/max(0.1,-mv.z); gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `varying vec3 vC; varying float vA; void main(){ float d=length(gl_PointCoord-0.5); float a=smoothstep(0.5,0.12,d)*vA; if(a<0.01) discard; gl_FragColor=vec4(vC,a);\n${FINISH}\n}`,
    });
    this.points = new THREE.Points(g, this.mat); this.points.frustumCulled = false; this.points.renderOrder = 5;
  }
  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, color: number, size: number, life: number, grav = 9, drag = 1.5, endSize = size * 2) {
    const i = this.cur; this.cur = (this.cur + 1) % this.max;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z; this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.c.setHex(color); this.col[i * 3] = this.c.r; this.col[i * 3 + 1] = this.c.g; this.col[i * 3 + 2] = this.c.b;
    this.life[i] = life; this.maxLife[i] = life; this.grav[i] = grav; this.drag[i] = drag; this.s0[i] = size; this.s1[i] = endSize;
  }
  burst(x: number, y: number, z: number, n: number, speed: number, color: number, size = 0.25, life = 0.7, up = 1.5) {
    for (let k = 0; k < n; k++) { const a = Math.random() * Math.PI * 2, s = speed * (0.4 + Math.random() * 0.6); this.emit(x, y, z, Math.cos(a) * s, up * (0.3 + Math.random()), Math.sin(a) * s, color, size * (0.6 + Math.random() * 0.8), life * (0.6 + Math.random() * 0.6), 5, 2.5); }
  }
  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) { this.alpha[i] = 0; this.size[i] = 0; continue; }
      this.life[i] -= dt; const u = Math.max(0, this.life[i] / this.maxLife[i]);
      const d = Math.exp(-this.drag[i] * dt);
      this.vel[i * 3] *= d; this.vel[i * 3 + 2] *= d; this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * d - this.grav[i] * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      this.alpha[i] = u * 0.85; this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * (1 - u);
    }
    const g = this.points.geometry; (g.attributes.position as THREE.BufferAttribute).needsUpdate = true; (g.attributes.aColor as THREE.BufferAttribute).needsUpdate = true;
    (g.attributes.aSize as THREE.BufferAttribute).needsUpdate = true; (g.attributes.aAlpha as THREE.BufferAttribute).needsUpdate = true;
  }
}

export class Rain {
  lines: THREE.LineSegments; mat: THREE.ShaderMaterial;
  constructor(n = 3500) {
    const pos: number[] = [], top: number[] = [];
    for (let i = 0; i < n; i++) { const x = Math.random() * 60, y = Math.random() * 60, z = Math.random() * 60; pos.push(x, y, z, x, y, z); top.push(0, 1); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('aTop', new THREE.Float32BufferAttribute(top, 1));
    this.mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, uniforms: { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uVel: { value: new THREE.Vector3() } },
      vertexShader: `attribute float aTop; uniform float uTime; uniform vec3 uCam; uniform vec3 uVel; varying float vA;
        void main(){ vec3 p = position; p.y -= uTime*32.0; p.x += uTime*3.0; p = mod(p - uCam + 30.0, 60.0) - 30.0 + uCam; float fade = 1.0 - smoothstep(18.0, 30.0, length(p - uCam)); vA = fade*0.45;
          p += aTop * vec3(-0.12, 1.1, 0.0) - aTop*uVel*0.02; gl_Position = projectionMatrix*viewMatrix*vec4(p,1.0); }`,
      fragmentShader: `varying float vA; void main(){ gl_FragColor = vec4(0.72,0.8,0.95,vA);\n${FINISH}\n}`,
    });
    this.lines = new THREE.LineSegments(g, this.mat); this.lines.frustumCulled = false; this.lines.visible = false; this.lines.renderOrder = 6;
  }
}

export class Ambient {
  points: THREE.Points; mat: THREE.ShaderMaterial;
  constructor(n = 700) {
    const pos: number[] = [], col: number[] = [], size: number[] = [], fall: number[] = []; const c = new THREE.Color();
    for (let i = 0; i < n; i++) {
      pos.push(Math.random() * 60, Math.random() * 60, Math.random() * 60);
      const leaf = i % 7 === 0;
      c.setHex(leaf ? [0xb5651d, 0x8a5a2b, 0x6b7a2e, 0xc08a2e][i % 4] : 0xe8e0d0); col.push(c.r, c.g, c.b);
      size.push(leaf ? 0.14 : 0.05); fall.push(leaf ? 0.9 : 0.05);
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('aColor', new THREE.Float32BufferAttribute(col, 3));
    g.setAttribute('aSize', new THREE.Float32BufferAttribute(size, 1)); g.setAttribute('aFall', new THREE.Float32BufferAttribute(fall, 1));
    this.mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, uniforms: { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uScale: { value: 600 }, uWind: { value: new THREE.Vector3(1.5, 0, 0.7) }, uAmt: { value: 1 } },
      vertexShader: `attribute vec3 aColor; attribute float aSize; attribute float aFall; uniform float uTime; uniform vec3 uCam; uniform float uScale; uniform vec3 uWind; varying vec3 vC; varying float vA;
        void main(){ vC=aColor; vec3 p = position; float s = position.x*7.3+position.z*3.1;
          p += uWind*uTime*(0.6+aFall); p.y -= uTime*aFall; p.x += sin(uTime*1.3+s)*aFall*1.2; p.z += cos(uTime*1.1+s)*aFall*1.2;
          p = mod(p - uCam + 30.0, 60.0) - 30.0 + uCam; vA = (1.0 - smoothstep(14.0, 30.0, length(p - uCam)))*0.7;
          vec4 mv = viewMatrix*vec4(p,1.0); gl_PointSize = aSize*uScale/max(0.1,-mv.z); gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `varying vec3 vC; varying float vA; void main(){ float d=length(gl_PointCoord-0.5); float a=smoothstep(0.5,0.2,d)*vA; if(a<0.02) discard; gl_FragColor=vec4(vC,a);\n${FINISH}\n}`,
    });
    this.points = new THREE.Points(g, this.mat); this.points.frustumCulled = false; this.points.renderOrder = 4;
  }
}

export class Environment {
  skyMat: THREE.ShaderMaterial; sky: THREE.Mesh; sun: THREE.DirectionalLight; hemi: THREE.HemisphereLight;
  pmrem: THREE.PMREMGenerator; envRT: THREE.WebGLRenderTarget | null = null; preset: WeatherPreset = WEATHER.day; key = 'day';
  sunDir = new THREE.Vector3(); fog = new THREE.FogExp2(0xffffff, 0.002); world?: World; viewDist = 0.75;
  constructor(private scene: THREE.Scene, private renderer: THREE.WebGLRenderer) {
    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, depthTest: true, fog: false,
      uniforms: { uTop: { value: new THREE.Color() }, uMid: { value: new THREE.Color() }, uHor: { value: new THREE.Color() }, uSunDir: { value: new THREE.Vector3(0, 1, 0) }, uSunCol: { value: new THREE.Color() },
        uNightSky: { value: 0 }, uTime: U.uTime, uCloud: { value: 0.5 }, uCloudCol: { value: new THREE.Color() } },
      vertexShader: SKY_VERT, fragmentShader: SKY_FRAG.replace('gl_FragColor = vec4(col, 1.0);', `gl_FragColor = vec4(col, 1.0);\n${FINISH}`),
    });
    this.skyMat.depthFunc = THREE.LessEqualDepth;
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 16), this.skyMat); this.sky.scale.setScalar(900); this.sky.renderOrder = -10; this.sky.frustumCulled = false;
    scene.add(this.sky);
    this.sun = new THREE.DirectionalLight(0xffffff, 2); this.sun.castShadow = true; this.sun.shadow.bias = -0.0004; this.sun.shadow.normalBias = 0.05;
    const sc = this.sun.shadow.camera; sc.near = 10; sc.far = 600; scene.add(this.sun, this.sun.target);
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1); scene.add(this.hemi);
    scene.fog = this.fog; this.pmrem = new THREE.PMREMGenerator(renderer);
  }
  setShadowQuality(size: number, extent: number, on: boolean) {
    this.sun.castShadow = on; if (this.sun.shadow.mapSize.x !== size) { this.sun.shadow.mapSize.set(size, size); this.sun.shadow.map?.dispose(); this.sun.shadow.map = null; }
    const c = this.sun.shadow.camera; c.left = -extent; c.right = extent; c.top = extent; c.bottom = -extent; c.updateProjectionMatrix();
  }
  apply(key: string, viewDist: number, world?: World) {
    this.key = key; this.viewDist = viewDist; if (world) this.world = world;
    const p = (this.preset = WEATHER[key] || WEATHER.day); const u = this.skyMat.uniforms;
    u.uTop.value.setHex(p.top); u.uMid.value.setHex(p.mid); u.uHor.value.setHex(p.hor); u.uSunDir.value.set(...p.sunDir); u.uSunCol.value.setHex(p.sunCol).multiplyScalar(p.night > 0.8 ? 0.5 : 1);
    u.uNightSky.value = p.stars; u.uCloud.value = p.cloud; u.uCloudCol.value.setHex(p.cloudCol);
    this.sunDir.set(...p.sunDir).normalize(); this.sun.color.setHex(p.sunCol); this.sun.intensity = p.sunInt;
    this.hemi.color.setHex(p.hemiSky); this.hemi.groundColor.setHex(p.hemiGround); this.hemi.intensity = p.hemiInt;
    this.fog.color.setHex(p.fog); this.fog.density = p.fogDensity * (1 + (1 - viewDist) * 1.1);
    this.renderer.toneMappingExposure = p.exposure; U.uNight.value = p.night; U.uWet.value = p.wet;
    const w = this.world;
    if (w) { w.lampMat.color.setScalar(0.35 + p.lamp * 3.2); w.glowMat.color.setScalar(0.75 + p.lamp * 1.6); w.decalMat.opacity = p.lamp * 0.5; }
    // reflexos do ambiente
    const skyScene = new THREE.Scene(); const m = new THREE.Mesh(this.sky.geometry, this.skyMat); m.scale.setScalar(10); skyScene.add(m);
    const old = this.envRT; this.envRT = this.pmrem.fromScene(skyScene, 0.0, 0.1, 100); this.scene.environment = this.envRT.texture;
    (this.scene as any).environmentIntensity = key === 'night' ? 0.6 : key === 'sunset' ? 0.8 : 0.9; old?.dispose();
    this.scene.background = null;
  }
  update(center: THREE.Vector3, cam: THREE.Vector3) {
    this.sky.position.copy(cam);
    this.sun.position.copy(center).addScaledVector(this.sunDir, 260); this.sun.target.position.copy(center);
    this.sun.target.updateMatrixWorld();
  }
}
