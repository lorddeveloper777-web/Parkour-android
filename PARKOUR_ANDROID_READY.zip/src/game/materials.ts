import * as THREE from 'three';

export const U = {
  uNight: { value: 0 },
  uTime: { value: 0 },
  uWet: { value: 0 },
};

// MODE: 0 genérico/concreto, 1 prédio (janelas), 3 metal corrugado, 4 madeira, 5 rua/chão
export function makeStd(mode: number, opts: { roughness?: number; metalness?: number } = {}) {
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: opts.roughness ?? 0.85, metalness: opts.metalness ?? 0.0 });
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uNight = U.uNight; sh.uniforms.uTime = U.uTime; sh.uniforms.uWet = U.uWet;
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;')
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        vec4 wp_ = vec4(transformed, 1.0); vec3 wn_ = normal;
        #ifdef USE_INSTANCING
          wp_ = instanceMatrix * wp_; wn_ = mat3(instanceMatrix) * wn_;
        #endif
        wp_ = modelMatrix * wp_; vWP = wp_.xyz; vWN = normalize(mat3(modelMatrix) * wn_);`);
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', `#include <common>
        #define MODE ${mode}
        varying vec3 vWP; varying vec3 vWN; uniform float uNight; uniform float uTime; uniform float uWet;
        float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
        float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
          return mix(mix(h21(i),h21(i+vec2(1.,0.)),f.x), mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),f.x), f.y); }
        float winMask = 0.0; float winLit = 0.0; float winRnd = 0.0; float puddle = 0.0;`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        vec3 N_ = normalize(vWN);
        float seed = 0.0;
        #ifdef USE_INSTANCING_COLOR
          seed = dot(vColor, vec3(12.9, 78.2, 37.7));
        #endif
        float nz = vn(vWP.xz*1.3 + vWP.y*0.8)*0.55 + vn(vWP.xz*7.0 + vWP.y*4.0)*0.45;
        #if MODE != 5
          diffuseColor.rgb *= 0.78 + 0.44*nz;
        #endif
        bool sideFace = abs(N_.y) < 0.5;
        float uAlong = abs(N_.x) > abs(N_.z) ? vWP.z : vWP.x;
        #if MODE == 1
        if (sideFace) {
          vec2 g = vec2(uAlong/3.1, vWP.y/3.7);
          vec2 id = floor(g); vec2 f = fract(g);
          winMask = step(0.15,f.x)*step(f.x,0.85)*step(0.2,f.y)*step(f.y,0.8);
          winRnd = h21(id + seed + (abs(N_.x)>abs(N_.z)?0.:100.));
          winLit = step(0.5, winRnd) * winMask;
          vec3 glass = mix(vec3(0.04,0.07,0.10), vec3(0.22,0.33,0.45), winRnd*0.6);
          diffuseColor.rgb = mix(diffuseColor.rgb, glass, winMask);
          diffuseColor.rgb *= 1.0 - 0.18*step(f.y, 0.07);
          diffuseColor.rgb *= mix(1.0, 0.55 + 0.45*smoothstep(0.0, 6.0, vWP.y), 0.6);
        } else if (N_.y > 0.5) {
          vec2 q = vWP.xz*0.7; diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.22,0.23,0.25)*(0.8+0.4*vn(q*3.0)), 0.55);
          float edge = step(0.12, fract(vWP.x*0.2)) * step(0.12, fract(vWP.z*0.2)); diffuseColor.rgb *= 0.88 + 0.12*edge;
        }
        #elif MODE == 3
        if (sideFace) { float c = 0.5+0.5*sin(uAlong*16.0); diffuseColor.rgb *= 0.7+0.3*c;
          diffuseColor.rgb *= 0.85 + 0.15*step(0.5, fract(vWP.y*0.4)); }
        else { diffuseColor.rgb *= 0.9 + 0.1*step(0.5, fract(vWP.x*3.0+vWP.z*3.0)); }
        #elif MODE == 4
        diffuseColor.rgb *= 0.8 + 0.2*sin((vWP.x+vWP.z*0.3)*9.0 + vn(vWP.xz*2.0)*3.0);
        #elif MODE == 5
        {
          vec2 p = vWP.xz;
          vec2 d = abs(mod(p + 32.0, 64.0) - 32.0);   // distância ao eixo da rua mais próxima
          vec2 cell = floor((p + 32.0)/64.0);
          bool street = d.x < 8.0 || d.y < 8.0;
          bool inter = d.x < 8.0 && d.y < 8.0;
          vec3 col;
          float n2 = vn(p*0.9)*0.5 + vn(p*5.0)*0.5;
          if (street) {
            col = vec3(0.075,0.078,0.085) * (0.8 + 0.4*n2);
            // faixa central tracejada
            float along = d.x < 8.0 ? p.y : p.x; float across = d.x < 8.0 ? d.x : d.y;
            if (!inter) {
              float dash = step(0.5, fract(along/6.0));
              col = mix(col, vec3(0.85,0.7,0.15), step(across, 0.18) * dash);
              col = mix(col, vec3(0.7), step(abs(across-6.6), 0.12));
            }
            // faixa de pedestres perto dos cruzamentos
            float pc = d.x < 8.0 ? d.y : d.x;
            if (!inter && pc > 8.0 && pc < 11.0) { float zb = step(0.5, fract(across*0.9)); if (pc < 10.0) col = mix(col, vec3(0.75), zb*0.8); }
            puddle = smoothstep(0.55, 0.7, vn(p*0.35 + 7.0)) * uWet;
          } else {
            col = vec3(0.30,0.30,0.31) * (0.8 + 0.4*n2);
            float tiles = step(0.06, fract(p.x/2.5)) * step(0.06, fract(p.y/2.5));
            col *= 0.85 + 0.15*tiles;
            puddle = smoothstep(0.62, 0.75, vn(p*0.3 + 3.0)) * uWet * 0.8;
          }
          diffuseColor.rgb = col * (1.0 - 0.45*puddle);
        }
        #endif
      `)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
        roughnessFactor = mix(roughnessFactor, 0.1, winMask);
        roughnessFactor = mix(roughnessFactor, 0.06, puddle);
        roughnessFactor = mix(roughnessFactor, roughnessFactor*0.55, uWet*0.6);`)
      .replace('#include <metalnessmap_fragment>', `#include <metalnessmap_fragment>
        metalnessFactor = mix(metalnessFactor, 0.55, winMask);`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        vec3 wc = mix(vec3(1.0,0.72,0.4), vec3(0.55,0.8,1.0), step(0.82, fract(winRnd*7.3)));
        totalEmissiveRadiance += wc * winLit * uNight * 1.7;`);
  };
  return mat;
}

export const SKY_VERT = `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position.z = gl_Position.w; }`;
export const SKY_FRAG = `
varying vec3 vDir;
uniform vec3 uTop; uniform vec3 uMid; uniform vec3 uHor; uniform vec3 uSunDir; uniform vec3 uSunCol;
uniform float uNightSky; uniform float uTime; uniform float uCloud; uniform vec3 uCloudCol;
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(h21(i),h21(i+vec2(1.,0.)),f.x), mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),f.x), f.y); }
float fbm(vec2 p){ float a=0.5, s=0.0; for(int i=0;i<5;i++){ s+=a*vn(p); p=p*2.03+vec2(1.7,9.2); a*=0.5; } return s; }
void main(){
  vec3 d = normalize(vDir);
  float h = clamp(d.y, -0.2, 1.0);
  vec3 col = mix(uHor, uMid, smoothstep(0.0, 0.18, h));
  col = mix(col, uTop, smoothstep(0.12, 0.8, h));
  float sd = max(dot(d, normalize(uSunDir)), 0.0);
  col += uSunCol * (pow(sd, 6.0)*0.25 + pow(sd, 90.0)*0.8 + smoothstep(0.9993, 0.9998, sd)*6.0);
  if (d.y < 0.0) col = mix(uHor, uHor*0.6, clamp(-d.y*4.0,0.0,1.0));
  // nuvens
  if (d.y > 0.01) {
    vec2 cp = d.xz / (d.y + 0.12) * 0.9 + vec2(uTime*0.01, uTime*0.004);
    float cl = fbm(cp*1.4);
    float cov = smoothstep(1.0 - uCloud, 1.0 - uCloud + 0.28, cl);
    cov *= smoothstep(0.0, 0.2, d.y);
    vec3 cc = uCloudCol * (0.75 + 0.5*pow(sd, 3.0)) ;
    col = mix(col, cc, cov * 0.85);
  }
  // estrelas
  if (uNightSky > 0.01 && d.y > 0.0) {
    vec3 sp = d * 160.0; vec2 q = sp.xz / (sp.y*0.35+1.0);
    float s = step(0.9965, h21(floor(q*1.2))) * (0.6 + 0.4*sin(uTime*2.0 + h21(floor(q*1.2))*30.0));
    col += vec3(s) * uNightSky * smoothstep(0.0, 0.3, d.y);
  }
  gl_FragColor = vec4(col, 1.0);
}`;

export function radialTexture(inner = 'rgba(255,255,255,1)', outer = 'rgba(255,255,255,0)') {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d')!; const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, inner); gr.addColorStop(1, outer); g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c); return t;
}

export interface WeatherPreset {
  top: number; mid: number; hor: number; sunDir: [number, number, number]; sunCol: number; sunInt: number;
  hemiSky: number; hemiGround: number; hemiInt: number; fog: number; fogDensity: number; exposure: number;
  night: number; stars: number; cloud: number; cloudCol: number; wet: number; rain: boolean; lamp: number; ambientSound: number;
}
const dir = (elevDeg: number, azDeg: number): [number, number, number] => {
  const e = elevDeg * Math.PI / 180, a = azDeg * Math.PI / 180;
  return [Math.cos(e) * Math.sin(a), Math.sin(e), Math.cos(e) * Math.cos(a)];
};
export const WEATHER: Record<string, WeatherPreset> = {
  day: { top: 0x2f78d0, mid: 0x74aee0, hor: 0xcfe2f1, sunDir: dir(52, 40), sunCol: 0xfff0d8, sunInt: 3.4, hemiSky: 0xbcd8ff, hemiGround: 0x6a6258, hemiInt: 1.1,
    fog: 0xb9d0e4, fogDensity: 0.0018, exposure: 0.95, night: 0, stars: 0, cloud: 0.5, cloudCol: 0xffffff, wet: 0, rain: false, lamp: 0.0, ambientSound: 1 },
  sunset: { top: 0x23346e, mid: 0xb55a7e, hor: 0xff9a55, sunDir: dir(6, 38), sunCol: 0xff9b5a, sunInt: 3.0, hemiSky: 0xff9d78, hemiGround: 0x3b2a4a, hemiInt: 0.85,
    fog: 0xe5946a, fogDensity: 0.0021, exposure: 1.0, night: 0.35, stars: 0, cloud: 0.55, cloudCol: 0xffb08a, wet: 0, rain: false, lamp: 0.5, ambientSound: 1 },
  night: { top: 0x040818, mid: 0x0d1638, hor: 0x2a2f66, sunDir: dir(38, 140), sunCol: 0x8aa6ff, sunInt: 0.75, hemiSky: 0x3a4a9a, hemiGround: 0x151024, hemiInt: 0.55,
    fog: 0x0f1535, fogDensity: 0.0025, exposure: 1.05, night: 1, stars: 1, cloud: 0.25, cloudCol: 0x2a3566, wet: 0, rain: false, lamp: 1, ambientSound: 0.8 },
  rain: { top: 0x39414d, mid: 0x586270, hor: 0x78828e, sunDir: dir(30, 60), sunCol: 0xb6c4d8, sunInt: 0.9, hemiSky: 0x8a98aa, hemiGround: 0x2c2e33, hemiInt: 0.9,
    fog: 0x5f6a77, fogDensity: 0.0058, exposure: 0.95, night: 0.55, stars: 0, cloud: 1.0, cloudCol: 0x6b7480, wet: 1, rain: true, lamp: 0.7, ambientSound: 0.6 },
  fog: { top: 0x9aa8b5, mid: 0xb4bfc9, hor: 0xcdd3d8, sunDir: dir(35, 100), sunCol: 0xfff3e0, sunInt: 1.6, hemiSky: 0xd2dae2, hemiGround: 0x777b80, hemiInt: 1.1,
    fog: 0xc3cad1, fogDensity: 0.0125, exposure: 0.98, night: 0.12, stars: 0, cloud: 0.8, cloudCol: 0xd8dde2, wet: 0.2, rain: false, lamp: 0.25, ambientSound: 0.9 },
};
