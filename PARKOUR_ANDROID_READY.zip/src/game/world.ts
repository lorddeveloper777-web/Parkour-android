import * as THREE from 'three';
import { ColliderGrid, Slope } from './physics';
import { makeStd, radialTexture } from './materials';

export const REGION_NAMES = ['Distrito Velho', 'Zona Industrial', 'Canteiro de Obras', 'Centro Financeiro', 'Torre Central', 'Viaduto'];
export function regionAt(x: number, z: number) {
  if (Math.abs(x) < 56 && Math.abs(z) < 56) return 4;
  if (Math.abs(x) < 64 || Math.abs(z) < 64) return 5;
  if (x < 0) return z < 0 ? 0 : 3;
  return z < 0 ? 1 : 2;
}
export interface Platform { x: number; y: number; z: number; hx: number; hz: number; region: number; idx: number; kind: string; yaw: number }
export interface Bar { axis: 0 | 1; x: number; y: number; z: number; half: number }
export interface CP { id: number; x: number; y: number; z: number; yaw: number; routeIdx: number }
export interface Secret { id: string; x: number; y: number; z: number }
export interface CoinPos { id: number; x: number; y: number; z: number }
export interface StreetLine { axis: 0 | 1; k: number; y: number }
export interface World {
  group: THREE.Group; grid: ColliderGrid; route: Platform[]; cps: CP[]; secrets: Secret[]; coins: CoinPos[]; bars: Bar[];
  streets: StreetLine[]; update: (cam: THREE.Vector3, viewDist: number) => void; lampMat: THREE.MeshBasicMaterial;
  decalMat: THREE.MeshBasicMaterial; glowMat: THREE.MeshBasicMaterial; towerTop: number; routeLen: (a: number, b: number) => number;
  stats: { instances: number; colliders: number };
}

type Geo = 'box' | 'cyl' | 'sph' | 'wedge';
type MatKey = 'bld' | 'conc' | 'metal' | 'wood' | 'paint' | 'glass' | 'glow';
interface Rect { x0: number; x1: number; z0: number; z1: number }

function mulberry(a: number) {
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function wedgeGeo() {
  const A = [-.5, 0, -.5], B = [.5, 0, -.5], C = [.5, 1, -.5], D = [-.5, 0, .5], E = [.5, 0, .5], F = [.5, 1, .5];
  const tris = [[A, D, F], [A, F, C], [B, C, F], [B, F, E], [A, B, E], [A, E, D], [A, C, B], [D, E, F]];
  const pos: number[] = []; tris.forEach((t) => t.forEach((v) => pos.push(v[0], v[1], v[2])));
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.computeVertexNormals(); return g;
}
const PAL: number[][] = [
  [0x8a6a55, 0xa38b72, 0x6c5b52, 0x9c7b63, 0x77614f, 0xb09a80],
  [0x6a6f73, 0x7b6a5c, 0x555c61, 0x8a7a68, 0x6b4f45],
  [0x9a9a96, 0xaaa59a, 0x7d7f80, 0x8f8a80],
  [0x2c3e55, 0x39495e, 0x425a73, 0x25303f, 0x4f6a85, 0x30475a],
  [0x59606a, 0x6a7078, 0x4a4f58],
  [0x7a766f, 0x66707a, 0x8a8274, 0x5d6670],
];
const NEON = [0xff2d7a, 0x25e2ff, 0xffb020, 0x7cff4a, 0xb04bff];
const CAR_COL = [0xc0392b, 0x2c5aa0, 0xe0e0e0, 0x1a1a1e, 0xd4a017, 0x3a7d44, 0x8a8f96, 0xe67e22];

export function buildWorld(): World {
  const rng = mulberry(20240611);
  const R = (a: number, b: number) => a + (b - a) * rng();
  const RI = (a: number, b: number) => Math.floor(R(a, b + 1));
  const pick = <T,>(a: T[]) => a[Math.floor(rng() * a.length)];
  const grid = new ColliderGrid();
  const group = new THREE.Group();

  const MATS: Record<MatKey, THREE.Material> = {
    bld: makeStd(1, { roughness: 0.82 }), conc: makeStd(0, { roughness: 0.9 }), metal: makeStd(3, { roughness: 0.5, metalness: 0.5 }),
    wood: makeStd(4, { roughness: 0.9 }), paint: makeStd(0, { roughness: 0.3, metalness: 0.55 }), glass: makeStd(0, { roughness: 0.08, metalness: 0.85 }),
    glow: new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }),
  };
  const glowMat = MATS.glow as THREE.MeshBasicMaterial;
  const lampMat = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false });
  const GEOS: Record<Geo, THREE.BufferGeometry> = {
    box: new THREE.BoxGeometry(1, 1, 1), cyl: new THREE.CylinderGeometry(0.5, 0.5, 1, 10), sph: new THREE.IcosahedronGeometry(0.5, 1), wedge: wedgeGeo(),
  };

  // ---------- batching ----------
  interface Batch { geo: Geo; mat: MatKey | 'lamp'; chunk: number; detail: boolean; m: number[]; c: number[]; n: number }
  const batches = new Map<string, Batch>();
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3(), _c = new THREE.Color();
  const Y = new THREE.Vector3(0, 1, 0);
  const chunkOf = (x: number, z: number) => Math.min(6, Math.max(0, Math.floor((x + 320) / 100))) * 7 + Math.min(6, Math.max(0, Math.floor((z + 320) / 100)));
  let instCount = 0;
  function inst(geo: Geo, mat: MatKey | 'lamp', x: number, y: number, z: number, sx: number, sy: number, sz: number, rot: number, color: number, detail: boolean, far = false) {
    const chunk = far ? 99 : chunkOf(x, z);
    const key = `${chunk}|${geo}|${mat}|${detail ? 1 : 0}`;
    let b = batches.get(key); if (!b) { b = { geo, mat, chunk, detail, m: [], c: [], n: 0 }; batches.set(key, b); }
    _q.setFromAxisAngle(Y, rot); _m.compose(_p.set(x, y, z), _q, _s.set(sx, sy, sz));
    for (let i = 0; i < 16; i++) b.m.push(_m.elements[i]);
    _c.setHex(color); b.c.push(_c.r, _c.g, _c.b); b.n++; instCount++;
  }
  const addCol = (x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, surf = 0, slope?: Slope) =>
    grid.add({ minX: x0, maxX: x1, minY: y0, maxY: y1, minZ: z0, maxZ: z1, surf, slope, stamp: 0, solidWall: !slope });
  const reserved: Rect[] = [];
  const reserve = (r: Rect) => { reserved.push(r); };
  const isFree = (x0: number, x1: number, z0: number, z1: number, m = 0) => {
    for (let i = 0; i < reserved.length; i++) { const r = reserved[i]; if (x1 + m > r.x0 && x0 - m < r.x1 && z1 + m > r.z0 && z0 - m < r.z1) return false; }
    return true;
  };
  const surfOf = (m: MatKey) => (m === 'metal' || m === 'paint' ? 1 : m === 'wood' ? 2 : 0);
  const vary = (c: number, a = 0.04) => { _c.setHex(c); _c.offsetHSL(0, 0, R(-a, a)); return _c.getHex(); };

  function box(cx: number, y0: number, cz: number, w: number, h: number, d: number, color: number, mat: MatKey = 'conc', o: { surf?: number; col?: boolean; detail?: boolean } = {}) {
    if (o.col !== false) addCol(cx - w / 2, cx + w / 2, y0, y0 + h, cz - d / 2, cz + d / 2, o.surf ?? surfOf(mat));
    inst('box', mat, cx, y0 + h / 2, cz, w, h, d, 0, color, o.detail ?? (Math.max(w, d) < 3.5 && h < 7));
  }
  const rbox = (r: Rect, y0: number, h: number, color: number, mat: MatKey = 'conc', o: { surf?: number; col?: boolean; detail?: boolean } = {}) =>
    box((r.x0 + r.x1) / 2, y0, (r.z0 + r.z1) / 2, r.x1 - r.x0, h, r.z1 - r.z0, color, mat, o);
  function cyl(cx: number, y0: number, cz: number, r: number, h: number, color: number, mat: MatKey = 'metal', col = true, detail?: boolean) {
    if (col) addCol(cx - r, cx + r, y0, y0 + h, cz - r, cz + r, surfOf(mat));
    inst('cyl', mat, cx, y0 + h / 2, cz, r * 2, h, r * 2, 0, color, detail ?? (r < 1.2 && h < 8));
  }
  function ramp(x0: number, x1: number, z0: number, z1: number, axis: 0 | 1, dir: 1 | -1, lo: number, hi: number, color: number, slip: boolean, mat: MatKey = 'conc') {
    addCol(x0, x1, 0, hi, z0, z1, 0, { axis, dir, lo, hi, slip });
    if (lo > 0.01) inst('box', mat, (x0 + x1) / 2, lo / 2, (z0 + z1) / 2, x1 - x0, lo, z1 - z0, 0, color, false);
    const len = axis === 0 ? x1 - x0 : z1 - z0, wid = axis === 0 ? z1 - z0 : x1 - x0;
    const rot = axis === 0 ? (dir > 0 ? 0 : Math.PI) : dir > 0 ? -Math.PI / 2 : Math.PI / 2;
    inst('wedge', mat, (x0 + x1) / 2, lo, (z0 + z1) / 2, len, hi - lo, wid, rot, color, false);
  }
  function flight(x: number, z: number, axis: 0 | 1, dir: 1 | -1, y0: number, rise: number, width: number, steps: number, tread: number, color: number) {
    const rs = rise / steps;
    for (let i = 0; i < steps; i++) {
      const u = (i + 0.5) * tread * dir, top = y0 + (i + 1) * rs;
      box(axis === 0 ? x + u : x, top - 0.35, axis === 1 ? z + u : z, axis === 0 ? tread : width, 0.35, axis === 1 ? tread : width, color, 'metal', { detail: true });
    }
  }
  function slabHole(r: Rect, top: number, thick: number, hole: Rect, color: number, mat: MatKey = 'conc') {
    const y0 = top - thick;
    if (hole.z0 > r.z0) rbox({ x0: r.x0, x1: r.x1, z0: r.z0, z1: hole.z0 }, y0, thick, color, mat);
    if (hole.z1 < r.z1) rbox({ x0: r.x0, x1: r.x1, z0: hole.z1, z1: r.z1 }, y0, thick, color, mat);
    const z0 = Math.max(r.z0, hole.z0), z1 = Math.min(r.z1, hole.z1);
    if (hole.x0 > r.x0) rbox({ x0: r.x0, x1: hole.x0, z0, z1 }, y0, thick, color, mat);
    if (hole.x1 < r.x1) rbox({ x0: hole.x1, x1: r.x1, z0, z1 }, y0, thick, color, mat);
  }
  const bars: Bar[] = [];
  function gantry(x: number, z: number, axis: 0 | 1, len: number, hgt: number, y0 = 0) {
    const px = axis === 0 ? len / 2 : 0, pz = axis === 1 ? len / 2 : 0;
    cyl(x - px, y0, z - pz, 0.18, hgt, 0x444a50, 'metal'); cyl(x + px, y0, z + pz, 0.18, hgt, 0x444a50, 'metal');
    inst('cyl', 'metal', x, y0 + hgt, z, 0.12, len, 0.12, 0, 0xb0b4b8, true);
    // cilindro está em Y; gira com matriz? usa caixa fina em vez disso
    bars.push({ axis, x, y: y0 + hgt, z, half: len / 2 });
    box(x, y0 + hgt - 0.06, z, axis === 0 ? len : 0.14, 0.12, axis === 1 ? len : 0.14, 0xb0b4b8, 'metal', { col: false, detail: true });
  }

  // ---------- carros / postes ----------
  function car(x: number, z: number, axis: 0 | 1, y = 0) {
    const col = pick(CAR_COL); const L = 4.3, Wd = 1.8;
    const sx = axis === 0 ? L : Wd, sz = axis === 0 ? Wd : L;
    addCol(x - sx / 2, x + sx / 2, y, y + 1.4, z - sz / 2, z + sz / 2, 1);
    inst('box', 'conc', x, y + 0.2, z, sx * 0.92, 0.3, sz * 0.92, 0, 0x0c0c0c, true);
    inst('box', 'paint', x, y + 0.65, z, sx, 0.7, sz, 0, col, true);
    const o = axis === 0 ? 0.3 : 0;
    inst('box', 'glass', x + (axis === 0 ? -0.3 : 0), y + 1.2, z + (axis === 1 ? -0.3 : 0), axis === 0 ? 2.3 : 1.6, 0.55, axis === 0 ? 1.6 : 2.3, 0, 0x151a22, true);
    void o;
  }
  const decals: [number, number][] = [];
  function lamp(x: number, z: number, towardX: number, towardZ: number, y = 0) {
    cyl(x, y, z, 0.13, 7.4, 0x2b2f35, 'metal', true, true);
    const hx = x + towardX * 1.5, hz = z + towardZ * 1.5;
    box(x + towardX * 0.75, y + 7.3, z + towardZ * 0.75, towardX ? 1.5 : 0.1, 0.1, towardZ ? 1.5 : 0.1, 0x2b2f35, 'metal', { col: false, detail: true });
    inst('box', 'lamp', hx, y + 7.2, hz, 0.7, 0.14, 0.7, 0, 0xffe0a8, true);
    decals.push([hx, hz]);
  }
  function container(x: number, y: number, z: number, axis: 0 | 1, color?: number) {
    const c = color ?? pick([0xb03a2e, 0x2e5c9a, 0x2f7d4a, 0xd68a1c, 0x7a7f86, 0x8c3b8a]);
    box(x, y, z, axis === 0 ? 6.1 : 2.44, 2.6, axis === 0 ? 2.44 : 6.1, c, 'metal', { detail: false });
  }
  function tree(x: number, z: number, big = 1) {
    cyl(x, 0, z, 0.3 * big, 3 * big, 0x4a3a2a, 'wood', true, true);
    inst('sph', 'conc', x, 4.2 * big, z, 4.4 * big, 3.8 * big, 4.4 * big, 0, vary(pick([0x3c6e35, 0x4c7f3a, 0x2f5f33]), 0.05), true);
  }

  // ---------- parte 1: ROTA PRINCIPAL ----------
  const route: Platform[] = [];
  const spineRects: Rect[] = [];
  function addPlatform(x: number, y: number, z: number, hx: number, hz: number, kind: string, yaw: number, solid = true): Platform {
    const region = regionAt(x, z);
    const p: Platform = { x, y, z, hx, hz, region, idx: route.length, kind, yaw };
    route.push(p);
    const r = { x0: x - hx, x1: x + hx, z0: z - hz, z1: z + hz };
    spineRects.push(r); reserve(r);
    if (solid) rbox(r, 0, y, vary(pick(PAL[region === 4 ? 3 : region]), 0.05), 'bld', { detail: false });
    return p;
  }
  const anchors: [number, number][] = [[-235, -235], [-130, -235], [-130, -140], [-70, -140], [70, -140], [140, -140], [140, -235], [235, -235], [235, -120], [235, 70], [235, 235], [130, 235], [130, 150], [70, 150], [-70, 150], [-140, 150], [-140, 235], [-235, 235], [-235, 130], [-235, 0], [-30, 0]];
  const pre: number[] = [0]; let tot = 0;
  for (let i = 1; i < anchors.length; i++) { tot += Math.abs(anchors[i][0] - anchors[i - 1][0]) + Math.abs(anchors[i][1] - anchors[i - 1][1]); pre.push(tot); }

  function roofDeco(p: Platform, dx: number, _dz: number) {
    const aH = dx !== 0 ? p.hx : p.hz, lH = dx !== 0 ? p.hz : p.hx;
    const W = (s: number, l: number): [number, number] => dx !== 0 ? [p.x + s, p.z + l] : [p.x + l, p.z + s];
    const lb = (s: number, l: number, a: number, b: number, h: number, c: number, m: MatKey = 'conc') => { const [x, z] = W(s, l); box(x, p.y, z, dx !== 0 ? a : b, h, dx !== 0 ? b : a, c, m); };
    for (const sg of [-1, 1]) if (rng() < 0.5) {
      lb(-aH / 2 - 0.8, sg * (lH - 0.25), aH - 3, 0.5, 0.9, 0x8d8a84); lb(aH / 2 + 0.8, sg * (lH - 0.25), aH - 3, 0.5, 0.9, 0x8d8a84);
    }
    const nObs = RI(0, 2);
    for (let i = 0; i < nObs; i++) {
      const s = R(-aH + 3.5, aH - 3.5), l = R(-1.3, 1.3), t = rng();
      if (t < 0.4) lb(s, l, 1.6, 1.6, pick([0.9, 1.1, 1.3]), 0x8a6a43, 'wood');
      else if (t < 0.65) lb(s, l, 2.2, 1.2, 1.2, 0x778088, 'metal');
      else if (t < 0.85) lb(s, l, 0.5, 4, 1.0, 0x9a968e);
      else lb(s, l, 1.8, 1.8, 2.2, 0x7a5a38, 'wood');
    }
    for (let i = 0; i < 2; i++) {
      const s = R(-aH + 2, aH - 2), l = (rng() < 0.5 ? -1 : 1) * (lH - 1.6), t = rng();
      if (t < 0.4) lb(s, l, 2, 1.3, 1.2, 0x80888f, 'metal');
      else if (t < 0.7) { const [x, z] = W(s, l); cyl(x, p.y, z, 1.2, 2.8, 0x6b4f3a, 'wood'); }
      else if (t < 0.85) { const [x, z] = W(s, l); cyl(x, p.y, z, 0.12, R(5, 9), 0x333, 'metal'); cyl(x, p.y + 8.5, z, 0.2, 0.2, 0xff2020, 'metal', false); inst('sph', 'glow', x, p.y + 9, z, 0.5, 0.5, 0.5, 0, 0xff2020, true); }
      else lb(s, l, 3, 3, 2.6, 0x8d8a84);
    }
    if (rng() < 0.14 && p.y > 12) { // painel publicitário
      const [x, z] = W(R(-aH / 2, aH / 2), (rng() < 0.5 ? -1 : 1) * (lH - 1.2));
      cyl(x, p.y, z, 0.2, 3.2, 0x333840, 'metal');
      const col = pick(NEON);
      box(x, p.y + 3.2, z, dx !== 0 ? 7 : 0.4, 3, dx !== 0 ? 0.4 : 7, 0x20242a, 'metal');
      inst('box', 'glow', x + (dx !== 0 ? 0 : 0.25), p.y + 4.7, z + (dx !== 0 ? 0.25 : 0), dx !== 0 ? 6.4 : 0.1, 2.5, dx !== 0 ? 0.1 : 6.4, 0, col, true);
    }
    if (p.y > 8 && rng() < 0.45) { // neon na lateral
      const sg = rng() < 0.5 ? -1 : 1, [x, z] = W(R(-aH / 2, aH / 2), sg * (lH + 0.14)), c = pick(NEON);
      inst('box', 'glow', x, p.y - R(2.2, 5), z, dx !== 0 ? R(3, 6) : 0.25, R(0.8, 1.4), dx !== 0 ? 0.25 : R(3, 6), 0, c, true);
    }
  }

  function buildSpine() {
    let cur = addPlatform(anchors[0][0], 14, anchors[0][1], 7, 7, 'start', 0);
    roofDeco(cur, 1, 0);
    let ai = 1, prevDx = 1, prevDz = 0, lastType = 'normal';
    while (ai < anchors.length && route.length < 260) {
      const A = anchors[ai - 1], B = anchors[ai];
      const dx = Math.sign(B[0] - A[0]), dz = Math.sign(B[1] - A[1]);
      const remain = dx !== 0 ? (B[0] - cur.x) * dx : (B[1] - cur.z) * dz;
      const ch = dx !== 0 ? cur.hx : cur.hz, chw = dx !== 0 ? cur.hz : cur.hx;
      if (remain <= ch + 5) { ai++; continue; }
      const turned = dx !== prevDx || dz !== prevDz;
      const reg = regionAt(cur.x, cur.z), n = route.length;
      let type = 'normal';
      if (!turned && lastType === 'normal' && n > 6) {
        const r = rng();
        if (reg === 0) type = r < 0.12 ? 'wide' : r < 0.25 ? 'climb' : r < 0.33 ? 'slide' : 'normal';
        else if (reg === 1) type = r < 0.15 ? 'swing' : r < 0.28 ? 'slide' : r < 0.4 ? 'wide' : r < 0.52 ? 'wallrun' : 'normal';
        else if (reg === 2) type = r < 0.22 ? 'climb' : r < 0.35 ? 'wide' : r < 0.47 ? 'wallrun' : r < 0.52 ? 'slide' : 'normal';
        else if (reg === 3) type = r < 0.2 ? 'wallrun' : r < 0.33 ? 'wide' : r < 0.43 ? 'climb' : r < 0.5 ? 'swing' : 'normal';
        else type = r < 0.1 ? 'wide' : 'normal';
      }
      const special = type === 'wallrun' || type === 'swing';
      const L = special ? R(12, 15) : R(10, 16), W = special ? 10 : R(9, 13);
      const gap = type === 'wide' ? 6.1 : type === 'swing' ? 9 : type === 'wallrun' ? 10.5 : type === 'climb' ? 3.3 : type === 'slide' ? 12 : R(3.0, 4.2);
      const prog = (pre[ai - 1] + (dx !== 0 ? (cur.x - A[0]) * dx : (cur.z - A[1]) * dz)) / tot;
      const desired = 14 + 74 * Math.max(0, Math.min(1, prog));
      let dh = Math.max(-3, Math.min(2.0, (desired - cur.y) * 0.35 + R(-1.4, 1.4)));
      if (type === 'climb') dh = 3.3; else if (type === 'slide') dh = -5;
      else if (type === 'wide') dh = Math.max(-2, Math.min(0, dh)) - 0.3; else if (special) dh = Math.max(-1, Math.min(1, dh));
      const line = dx !== 0 ? A[1] : A[0], curPerp = dx !== 0 ? cur.z : cur.x;
      let shift = special ? 0 : Math.max(-4, Math.min(4, line - curPerp)) + R(-1.2, 1.2);
      if (type === 'slide') shift *= 0.3;
      const maxShift = chw + W / 2 - 6; shift = Math.max(-maxShift, Math.min(maxShift, shift));
      let nx = 0, nz = 0, hx = 0, hz = 0, ok = false;
      for (let tries = 0; tries < 5 && !ok; tries++) {
        const sh = tries === 0 ? shift : tries % 2 ? -shift : R(-3, 3);
        const off = ch + gap + L / 2;
        nx = cur.x + dx * off + (dx === 0 ? sh : 0); nz = cur.z + dz * off + (dz === 0 ? sh : 0);
        hx = dx !== 0 ? L / 2 : W / 2; hz = dx !== 0 ? W / 2 : L / 2;
        ok = Math.abs(nx) + hx < 252 && Math.abs(nz) + hz < 252;
        for (let i = 0; i < spineRects.length - 2 && ok; i++) { const r = spineRects[i]; if (nx + hx + 3 > r.x0 && nx - hx - 3 < r.x1 && nz + hz + 3 > r.z0 && nz - hz - 3 < r.z1) ok = false; }
        if (!ok && tries === 4) { type = 'normal'; ok = true; }
      }
      const ny = Math.max(10, cur.y + dh);
      const yaw = Math.atan2(-dx, -dz);
      const prev = cur;
      cur = addPlatform(nx, ny, nz, hx, hz, type, yaw);
      prevDx = dx; prevDz = dz; lastType = type;
      const along0 = dx !== 0 ? prev.x : prev.z, along1 = dx !== 0 ? nx : nz;
      const lat0 = dx !== 0 ? prev.z : prev.x, lat1 = dx !== 0 ? nz : nx;
      const gx0 = prev.x + dx * ch, gz0 = prev.z + dz * ch; // borda do anterior
      const gapRect = (lw: number): Rect => {
        const midLat = (lat0 + lat1) / 2;
        const a = Math.min(along0 + Math.sign(along1 - along0) * ch, along1 - Math.sign(along1 - along0) * (dx !== 0 ? hx : hz));
        const b = Math.max(along0 + Math.sign(along1 - along0) * ch, along1 - Math.sign(along1 - along0) * (dx !== 0 ? hx : hz));
        return dx !== 0 ? { x0: a, x1: b, z0: midLat - lw, z1: midLat + lw } : { x0: midLat - lw, x1: midLat + lw, z0: a, z1: b };
      };
      void gx0; void gz0;
      if (type === 'slide') {
        const lw = Math.max(3.5, Math.min(chw, W / 2) - Math.abs(lat1 - lat0) / 2 - 0.6);
        const g = gapRect(lw); reserve(g);
        const uphill = -(dx !== 0 ? dx : dz) as 1 | -1;
        ramp(g.x0, g.x1, g.z0, g.z1, dx !== 0 ? 0 : 1, uphill, ny, prev.y, 0x6b655e, true);
      } else if (type === 'swing') {
        const g = gapRect(5.2); reserve(g);
        for (const sg of [-1, 1]) {
          const lw = 4.6 * sg;
          const gr: Rect = dx !== 0 ? { x0: g.x0 - 1, x1: g.x1 + 1, z0: prev.z + lw - 0.4, z1: prev.z + lw + 0.4 } : { x0: prev.x + lw - 0.4, x1: prev.x + lw + 0.4, z0: g.z0 - 1, z1: g.z1 + 1 };
          rbox(gr, prev.y - 0.7, 0.7, 0x4a5058, 'metal');
        }
        for (const f of [1 / 3, 2 / 3]) {
          const bx = dx !== 0 ? g.x0 + (g.x1 - g.x0) * f : prev.x, bz = dx !== 0 ? prev.z : g.z0 + (g.z1 - g.z0) * f;
          const axis = dx !== 0 ? 1 : 0;
          const px = axis === 0 ? 4.6 : 0, pz = axis === 1 ? 4.6 : 0;
          cyl(bx - px, prev.y, bz - pz, 0.16, 3.5, 0x555b62); cyl(bx + px, prev.y, bz + pz, 0.16, 3.5, 0x555b62);
          bars.push({ axis: axis as 0 | 1, x: bx, y: prev.y + 3.5, z: bz, half: 4.6 });
          box(bx, prev.y + 3.44, bz, axis === 0 ? 9.2 : 0.14, 0.12, axis === 1 ? 9.2 : 0.14, 0xd9a21b, 'metal', { col: false, detail: true });
        }
      } else if (type === 'wallrun') {
        const g = gapRect(5); const ext = 3;
        for (const sg of [-1, 1]) {
          const r: Rect = dx !== 0 ? { x0: g.x0 - ext, x1: g.x1 + ext, z0: prev.z + sg * 5 - (sg > 0 ? 0 : 1.2), z1: prev.z + sg * 5 + (sg > 0 ? 1.2 : 0) }
            : { x0: prev.x + sg * 5 - (sg > 0 ? 0 : 1.2), x1: prev.x + sg * 5 + (sg > 0 ? 1.2 : 0), z0: g.z0 - ext, z1: g.z1 + ext };
          rbox(r, prev.y - 6, 15, 0x4b525c, 'conc', { detail: false });
          const inner = sg > 0 ? -0.06 : 0.06;
          const glow: Rect = dx !== 0 ? { x0: r.x0, x1: r.x1, z0: (sg > 0 ? r.z0 : r.z1) + inner - 0.04, z1: (sg > 0 ? r.z0 : r.z1) + inner + 0.04 } : { x0: (sg > 0 ? r.x0 : r.x1) + inner - 0.04, x1: (sg > 0 ? r.x0 : r.x1) + inner + 0.04, z0: r.z0, z1: r.z1 };
          rbox(glow, prev.y + 3.5, 0.3, pick(NEON), 'glow', { col: false, detail: true });
        }
      }
      if (type === 'wide' || special) { // rota segura (desvio)
        for (const sg of rng() < 0.5 ? [1, -1] : [-1, 1]) {
          const latC = lat0 + sg * (Math.max(chw, W / 2) + 7), yC = (prev.y + ny) / 2 - 0.8;
          const a0 = Math.min(along0, along1), a1 = Math.max(along0, along1);
          const rc: Rect = dx !== 0 ? { x0: a0, x1: a1, z0: latC - 3, z1: latC + 3 } : { x0: latC - 3, x1: latC + 3, z0: a0, z1: a1 };
          if (isFree(rc.x0, rc.x1, rc.z0, rc.z1, 1) && Math.abs(latC) < 255) {
            reserve(rc); rbox(rc, 0, yC, 0x777a80, 'bld', { detail: false });
            rbox({ x0: rc.x0 + 0.1, x1: rc.x1 - 0.1, z0: rc.z0 + 0.1, z1: rc.z1 - 0.1 }, yC, 0.05, 0xffc400, 'glow', { col: false, detail: true });
            break;
          }
        }
      }
      roofDeco(cur, dx, dz);
    }
  }
  buildSpine();

  // ---------- TORRE ----------
  let towerTop = 152;
  const TW = 12;
  function buildTower() {
    const last = route[route.length - 1];
    const H0 = last.y;
    reserve({ x0: -24, x1: 24, z0: -24, z1: 24 });
    // corpo
    box(0, 0, 0, TW * 2, towerTop, TW * 2, 0x3a4b63, 'bld', { detail: false });
    box(0, towerTop, 0, TW * 2 + 1.2, 1.2, TW * 2 + 1.2, 0x2a3140, 'conc', { detail: false });
    towerTop += 1.2;
    box(0, towerTop, 0, 2.2, 38, 2.2, 0x555c66, 'metal'); // antena
    inst('sph', 'glow', 0, towerTop + 38.6, 0, 1.4, 1.4, 1.4, 0, 0xff2222, false);
    for (const [cx, cz] of [[-10, -10], [10, -10], [-10, 10], [10, 10]]) { box(cx, towerTop, cz, 1.6, 1.4, 1.6, 0x444a52, 'metal'); inst('sph', 'glow', cx, towerTop + 1.8, cz, 0.6, 0.6, 0.6, 0, 0xff3030, true); }
    // faixa de luz
    for (let y = 20; y < 150; y += 22) {
      box(0, y, 0, TW * 2 + 0.4, 0.5, TW * 2 + 0.4, 0x222834, 'conc', { col: false, detail: false });
      inst('box', 'glow', 0, y + 0.1, 0, TW * 2 + 0.55, 0.12, TW * 2 + 0.55, 0, 0x25e2ff, false);
    }
    // ponte até a primeira laje
    const slabCenters: [number, number][] = [];
    const seq: [string, number][] = [['W', 0], ['W', 9], ['N', -9], ['N', 0], ['N', 9], ['E', 9], ['E', 0], ['E', -9], ['S', 9], ['S', 0], ['S', -9], ['W', -9]];
    const pos = (side: string, o: number): [number, number] => side === 'W' ? [-17, o] : side === 'E' ? [17, o] : side === 'N' ? [o, 17] : [o, -17];
    const bridgeLen = -20.5 - (last.x + last.hx);
    box((last.x + last.hx + -20.5) / 2, H0 - 1, 0, bridgeLen, 1, 5, 0x6a707a, 'metal');
    let y = H0, k = 0;
    const lastY = towerTop - 2.2;
    for (;;) {
      const yTop = y; y = Math.min(y, lastY);
      const [side, o] = seq[k % 12]; const [cx, cz] = pos(side, o);
      slabCenters.push([cx, cz]);
      box(cx, y - 0.8, cz, 7, 0.8, 7, vary(0x58606c), 'metal', { detail: false });
      // viga até a torre
      const bx = side === 'W' ? -12 - 0.75 : side === 'E' ? 12 + 0.75 : cx, bz = side === 'N' ? 12 + 0.75 : side === 'S' ? -12 - 0.75 : cz;
      box(bx, y - 1.2, bz, side === 'W' || side === 'E' ? 1.6 : 3, 0.4, side === 'W' || side === 'E' ? 3 : 1.6, 0x444a52, 'metal', { detail: true });
      inst('box', 'glow', cx, y + 0.02, cz, 6.8, 0.04, 6.8, 0, k % 6 === 0 ? 0xffc400 : 0x25e2ff, true);
      addPlatform(cx, y, cz, 3.5, 3.5, 'tower', 0, false);
      if (yTop >= lastY) break;
      y = yTop + 2.2; k++;
    }
    addPlatform(0, towerTop, 0, 12, 12, 'summit', 0, false);
  }
  buildTower();
  // paredes do mundo
  const WH = 268;
  addCol(-WH - 10, -WH, 0, 600, -400, 400); addCol(WH, WH + 10, 0, 600, -400, 400);
  addCol(-400, 400, 0, 600, -WH - 10, -WH); addCol(-400, 400, 0, 600, WH, WH + 10);

  // ---------- fire escape / skeleton / scaffold ----------
  function fireEscape(O: [number, number], a: [number, number], n: [number, number], hTop: number) {
    const L = 9, nf = Math.ceil(hTop / 3.6), fh = hTop / nf, col = 0x3b3f45;
    const P = (u: number, v: number): [number, number] => [O[0] + a[0] * u + n[0] * v, O[1] + a[1] * u + n[1] * v];
    const rect = (u0: number, u1: number, v0: number, v1: number): Rect => { const p = P(u0, v0), q = P(u1, v1); return { x0: Math.min(p[0], q[0]), x1: Math.max(p[0], q[0]), z0: Math.min(p[1], q[1]), z1: Math.max(p[1], q[1]) }; };
    for (let k = 1; k <= nf; k++) rbox(k % 2 ? rect(L - 2.4, L, 0, 1.7) : rect(0, 2.4, 0, 1.7), fh * k - 0.3, 0.3, col, 'metal', { detail: true });
    for (let k = 0; k < nf; k++) {
      const su = k % 2 === 0 ? (k === 0 ? 0 : 2.4) : L - 2.4, eu = k % 2 === 0 ? L - 2.4 : 2.4;
      for (let i = 0; i < 9; i++) {
        const u0 = su + (eu - su) * (i / 9), u1 = su + (eu - su) * ((i + 1) / 9), top = fh * k + (i + 1) * fh / 9;
        rbox(rect(u0, u1, 0, 1.1), top - 0.35, 0.35, col, 'metal', { detail: true });
      }
    }
  }
  function skeleton(r: Rect, floors: number) {
    const w = r.x1 - r.x0, d = r.z1 - r.z0, cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
    const conc = 0x8f8c85;
    const holes: Rect[] = [{ x0: r.x0 + 1, x1: r.x0 + 3, z0: r.z0 + 1, z1: r.z0 + 6.2 }, { x0: r.x1 - 3, x1: r.x1 - 1, z0: r.z1 - 6.2, z1: r.z1 - 1 }];
    const inner: Rect = { x0: r.x0 + 0.4, x1: r.x1 - 0.4, z0: r.z0 + 0.4, z1: r.z1 - 0.4 };
    for (let j = 1; j <= floors; j++) {
      if (j === 1 || true) slabHole(inner, 4 * j, 0.5, holes[(j - 1) % 2], conc);
      // escada do piso j-1 -> j
      const hc = holes[(j - 1) % 2], up = (j - 1) % 2 === 0;
      flight((hc.x0 + hc.x1) / 2, up ? hc.z0 + 0.25 : hc.z1 - 0.25, 1, up ? 1 : -1, 4 * (j - 1), 4, 1.8, 10, 0.5, 0x4a4f55);
    }
    for (let x = r.x0 + 1; x <= r.x1 - 0.9; x += (w - 2) / Math.max(1, Math.round((w - 2) / 8))) for (const z of [r.z0 + 1, r.z1 - 1, cz]) {
      if (z === cz && x > r.x0 + 1.5 && x < r.x1 - 1.5 && ((x - r.x0) % 16) > 1) continue;
      box(x, 0, z, 0.9, 4 * floors + 1, 0.9, conc, 'conc');
    }
    void d; void cx;
    // guarda-corpo parcial no topo
    rbox({ x0: r.x0, x1: r.x1, z0: r.z0, z1: r.z0 + 0.25 }, 4 * floors, 1.0, 0xe0a010, 'metal');
    // guindaste
    const mh = 4 * floors + 18;
    box(r.x1 - 2, 0, r.z0 + 2, 1.5, mh, 1.5, 0xe8b020, 'metal', { detail: false });
    box(r.x1 - 2 - 12, mh, r.z0 + 2, 36, 1.0, 1.0, 0xe8b020, 'metal', { detail: false });
    box(r.x1 - 2 + 7, mh, r.z0 + 2, 10, 1.0, 1.0, 0xe8b020, 'metal');
    box(r.x1 - 2 + 8, mh - 2.4, r.z0 + 2, 3, 2.4, 3, 0x444a52, 'metal');
    box(r.x1 - 2 - 20, mh - 8, r.z0 + 2, 0.08, 8, 0.08, 0x222, 'metal', { col: false });
  }
  function scaffold(cx: number, cz: number, w: number, d: number, levels: number) {
    const r: Rect = { x0: cx - w / 2, x1: cx + w / 2, z0: cz - d / 2, z1: cz + d / 2 }; reserve(r);
    const fh = 2.4;
    for (let l = 1; l <= levels; l++) {
      const hole: Rect = l % 2 ? { x0: r.x0, x1: r.x0 + 2.8, z0: r.z0, z1: r.z0 + 1.3 } : { x0: r.x1 - 2.8, x1: r.x1, z0: r.z0, z1: r.z0 + 1.3 };
      slabHole(r, fh * l, 0.2, hole, 0x8a6a43, 'wood');
      const odd = (l - 1) % 2 === 0; // voo do nível l-1 -> l
      const hx = (hole.x0 + hole.x1) / 2;
      flight(odd ? r.x0 + 0.25 : r.x1 - 0.25, r.z0 + 0.65, 0, odd ? 1 : -1, fh * (l - 1), fh, 1.2, 6, 0.4, 0x6a5a40);
      void hx;
    }
    for (let x = r.x0; x <= r.x1 + 0.1; x += w / Math.max(1, Math.round(w / 2.5))) for (const z of [r.z0 + 0.1, r.z1 - 0.1]) cyl(x, 0, z, 0.07, fh * levels + 1.0, 0x9aa0a6, 'metal', false, true);
    for (let l = 1; l <= levels; l++) rbox({ x0: r.x0, x1: r.x1, z0: r.z1 - 0.1, z1: r.z1 }, fh * l, 1.0, 0x9aa0a6, 'metal', { col: false, detail: true });
  }

  // ---------- parte 2: quarteirões ----------
  const builtLots: { r: Rect; h: number }[] = [];
  function roofProps(r: Rect, h: number, n: number) {
    for (let i = 0; i < n; i++) {
      const x = R(r.x0 + 3, r.x1 - 3), z = R(r.z0 + 3, r.z1 - 3), t = rng();
      if (t < 0.35) box(x, h, z, R(1.5, 2.6), R(1, 1.5), R(1.2, 1.8), 0x80888f, 'metal');
      else if (t < 0.55) cyl(x, h, z, R(1, 1.5), R(2.4, 3.2), 0x6b4f3a, 'wood');
      else if (t < 0.7) box(x, h, z, 3, 2.6, 3, 0x8d8a84, 'conc');
      else if (t < 0.85) box(x, h, z, 2.6, 0.45, 2.6, 0x151a22, 'glass');
      else { cyl(x, h, z, 0.12, R(4, 8), 0x333, 'metal'); }
    }
  }
  function sign(r: Rect, h: number) {
    const side = RI(0, 3), y = R(3.4, Math.min(8, h - 2)), c = pick(NEON), len = R(3, 6.5);
    const cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
    if (side === 0) inst('box', 'glow', cx + R(-6, 6), y, r.z0 - 0.14, len, R(0.8, 1.3), 0.25, 0, c, true);
    else if (side === 1) inst('box', 'glow', cx + R(-6, 6), y, r.z1 + 0.14, len, R(0.8, 1.3), 0.25, 0, c, true);
    else if (side === 2) inst('box', 'glow', r.x0 - 0.14, y, cz + R(-6, 6), 0.25, R(0.8, 1.3), len, 0, c, true);
    else inst('box', 'glow', r.x1 + 0.14, y, cz + R(-6, 6), 0.25, R(0.8, 1.3), len, 0, c, true);
  }
  function building(r: Rect, reg: number) {
    const w = r.x1 - r.x0, d = r.z1 - r.z0, cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
    reserve(r);
    if (reg === 1 && rng() < 0.3 && w >= 24 && d >= 24) { skeleton(r, RI(3, 8)); builtLots.push({ r, h: 20 }); return; }
    let h = reg === 0 ? R(8, 22) : reg === 1 ? R(10, 30) : reg === 2 ? R(25, 55) : reg === 3 ? R(40, 105) : R(10, 42);
    h = Math.round(h / 1.2) * 1.2;
    const col = vary(pick(PAL[reg === 4 ? 3 : reg]), 0.05);
    if (reg === 5 && d >= 40 && w >= 14 && rng() < 0.6) { // túnel passando pelo prédio
      const tw = 3.6;
      rbox({ x0: r.x0, x1: cx - tw, z0: r.z0, z1: r.z1 }, 0, h, col, 'bld', { detail: false });
      rbox({ x0: cx + tw, x1: r.x1, z0: r.z0, z1: r.z1 }, 0, h, col, 'bld', { detail: false });
      rbox({ x0: cx - tw, x1: cx + tw, z0: r.z0, z1: r.z1 }, 4.6, h - 4.6, col, 'bld', { detail: false });
      for (let z = r.z0 + 3; z < r.z1; z += 6) inst('box', 'glow', cx, 4.5, z, 0.5, 0.08, 2.4, 0, 0xcfe8ff, true);
    } else {
      rbox(r, 0, h, col, 'bld', { detail: false });
      if (h > 14) { rbox({ x0: r.x0 - 0.3, x1: r.x1 + 0.3, z0: r.z0 - 0.3, z1: r.z1 + 0.3 }, h - 0.7, 0.7, vary(col, 0.06), 'conc', { detail: false }); }
      if (reg === 3 && h > 55 && rng() < 0.5) {
        const ins = 4.5, h2 = R(10, 25), r2 = { x0: r.x0 + ins, x1: r.x1 - ins, z0: r.z0 + ins, z1: r.z1 - ins };
        rbox(r2, h, h2, vary(col, 0.05), 'bld', { detail: false });
        if (rng() < 0.6) { cyl(cx, h + h2, cz, 0.3, R(10, 24), 0x555c66, 'metal'); inst('sph', 'glow', cx, h + h2 + 24, cz, 0.7, 0.7, 0.7, 0, 0xff2222, false); }
        h += h2;
      }
    }
    const top = h;
    roofProps({ x0: r.x0, x1: r.x1, z0: r.z0, z1: r.z1 }, top, RI(2, 5));
    if (reg === 1 && rng() < 0.45) { const sx = R(r.x0 + 4, r.x1 - 4), sz = R(r.z0 + 4, r.z1 - 4); cyl(sx, top, sz, 1.7, R(14, 24), 0x7d7367, 'conc', true, false); inst('cyl', 'conc', sx, top + 6, sz, 3.5, 1.2, 3.5, 0, 0xb83a2c, false); }
    if (rng() < 0.55) sign(r, h);
    if (h < 26 && (reg === 0 || reg === 5 || reg === 2) && rng() < 0.4 && w >= 14) {
      const face = RI(0, 3);
      if (face === 0) fireEscape([r.x0 + 2, r.z0], [1, 0], [0, -1], h);
      else if (face === 1) fireEscape([r.x0 + 2, r.z1], [1, 0], [0, 1], h);
      else if (face === 2 && d >= 14) fireEscape([r.x0, r.z0 + 2], [0, 1], [-1, 0], h);
      else if (d >= 14) fireEscape([r.x1, r.z0 + 2], [0, 1], [1, 0], h);
    }
    builtLots.push({ r, h });
  }
  function lotDecor(r: Rect, reg: number) {
    const w = r.x1 - r.x0, d = r.z1 - r.z0, cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
    if (!isFree(r.x0, r.x1, r.z0, r.z1, 0)) { // só o que couber
      const free = (x: number, z: number, m: number) => isFree(x - m, x + m, z - m, z + m, 0);
      for (let i = 0; i < 4; i++) { const x = R(r.x0 + 3, r.x1 - 3), z = R(r.z0 + 3, r.z1 - 3); if (free(x, z, 2.5)) box(x, 0, z, 1.8, pick([0.9, 1.2, 1.6]), 1.8, 0x8a6a43, 'wood'); }
      return;
    }
    const opts: Record<number, string[]> = { 0: ['park', 'parking', 'play', 'play'], 1: ['yard', 'tanks', 'yard', 'build'], 2: ['build', 'yard', 'parking'], 3: ['plaza', 'parking', 'park'], 5: ['parking', 'garage', 'park', 'play'], 4: ['plaza'] };
    const t = pick(opts[reg] || opts[0]);
    reserve(r);
    if (t === 'park') {
      box(cx, 0, cz, w - 2, 0.18, d - 2, 0x3f6b3a, 'conc', { surf: 3 });
      for (let i = 0; i < 7; i++) tree(R(r.x0 + 4, r.x1 - 4), R(r.z0 + 4, r.z1 - 4), R(0.8, 1.3));
      for (let i = 0; i < 3; i++) box(R(r.x0 + 5, r.x1 - 5), 0.18, R(r.z0 + 5, r.z1 - 5), 1.8, 0.5, 0.6, 0x7a5a38, 'wood');
    } else if (t === 'parking') {
      for (let row = 0; row < Math.floor((d - 6) / 6); row++) for (let c = 0; c < Math.floor((w - 4) / 2.6); c++) if (rng() < 0.55) car(r.x0 + 3 + c * 2.6, r.z0 + 5 + row * 6, 1);
      for (let i = 0; i < 4; i++) lamp(R(r.x0 + 4, r.x1 - 4), R(r.z0 + 4, r.z1 - 4), 1, 0);
    } else if (t === 'play') { // parque de parkour
      const hs = [0.8, 1.0, 1.2, 1.5, 2.0, 2.6];
      for (let i = 0; i < 6; i++) box(r.x0 + 5 + i * 3.4, 0, r.z0 + 6, 2.2, hs[i], 2.2, 0x8f8a80, 'conc');
      for (let i = 0; i < 4; i++) box(r.x0 + 5, 0, r.z0 + 12 + i * 3.4, 2.4, 2.6 * (i + 1) * 0 + 0.6 + i * 0.5, 2.4, 0x7a7f86, 'conc');
      box(cx + 6, 0, cz + 4, 8, 2.6, 2.2, 0x7a5a38, 'wood'); box(cx + 6, 0, cz + 7.2, 8, 5.2, 2.2, 0x7a5a38, 'wood'); box(cx + 6, 0, cz + 10.4, 8, 7.8, 2.2, 0x7a5a38, 'wood');
      ramp(r.x0 + 8, r.x0 + 17, cz - 6, cz - 1, 0, 1, 0, 3.2, 0x777777, false);
      gantry(cx - 4, cz + 8, 0, 6, 3.3); gantry(cx + 4, cz + 8, 0, 6, 3.3);
      for (let i = 0; i < 5; i++) box(r.x1 - 6, 0, r.z0 + 5 + i * 5, 0.5, 1.0, 4, 0x9a968e, 'conc');
    } else if (t === 'yard') {
      for (let i = 0; i < Math.floor((w - 8) / 7); i++) for (let j = 0; j < Math.floor((d - 4) / 3.4); j++) {
        const n = rng() < 0.3 ? 0 : RI(1, 3), x = r.x0 + 5 + i * 7.2, z = r.z0 + 3 + j * 3.4;
        for (let l = 0; l < n; l++) container(x, l * 2.6, z, 0);
      }
      const px = r.x0 + 6, pz = r.z1 - 5; container(px, 0, pz, 0, 0xb03a2e); container(px + 3.5, 0, pz, 0, 0x2e5c9a); container(px + 3.5, 2.6, pz, 0, 0x2e5c9a); container(px + 7, 0, pz, 0, 0x2f7d4a); container(px + 7, 2.6, pz, 0, 0x2f7d4a); container(px + 7, 5.2, pz, 0, 0x2f7d4a);
    } else if (t === 'tanks') {
      for (let i = 0; i < 2; i++) {
        const tx = r.x0 + 10 + i * Math.max(16, w / 2 - 6), tz = cz - 4, rr = 4, th = pick([8, 10]);
        box(tx, 0, tz, rr * 2, th, rr * 2, 0x9aa0a4, 'metal', { detail: false });
        inst('cyl', 'metal', tx, th / 2, tz, rr * 2.1, th, rr * 2.1, 0, 0xb4bac0, false);
        flight(tx + rr + 1.2, tz - 6, 1, 1, 0, th, 1.5, Math.round(th / 0.4), 0.5, 0x555b62);
        box(tx + rr + 1.2, th - 0.3, tz + rr + 0.9 + (th / 0.4) * 0.5 - 6 - rr - 0.9 + 0.0, 1.5, 0.3, 0.6, 0x555b62, 'metal');
        box(tx + (rr + 1.2) / 2, th - 0.3, tz - 6 + (th / 0.4) * 0.5 + 0.5, rr + 1.8, 0.3, 1.5, 0x555b62, 'metal');
      }
      for (let i = 0; i < 3; i++) container(R(r.x0 + 6, r.x1 - 6), 0, r.z1 - 4, 0);
    } else if (t === 'build') {
      if (w >= 24 && d >= 24 && rng() < 0.6) skeleton(r, RI(3, 7));
      else for (let i = 0; i < 3; i++) scaffold(r.x0 + 8 + i * 12, cz + R(-6, 6), 6, 2.6, RI(2, 4));
      for (let i = 0; i < 5; i++) box(R(r.x0 + 3, r.x1 - 3), 0, r.z1 - 3, 0.5, 0.9, 3, 0xe08a1c, 'metal');
    } else if (t === 'plaza') {
      box(cx, 0, cz, w - 4, 0.15, d - 4, 0x8f8f90, 'conc');
      for (let i = 0; i < 6; i++) tree(R(r.x0 + 4, r.x1 - 4), R(r.z0 + 4, r.z1 - 4), R(0.8, 1.1));
      cyl(cx, 0, cz, 4, 0.9, 0x9a9a9a, 'conc'); cyl(cx, 0.9, cz, 0.8, 2.4, 0xaab0b8, 'conc');
      for (let i = 0; i < 4; i++) box(cx + (i % 2 ? 7 : -7), 0, cz + (i < 2 ? 6 : -6), 3, 0.6, 1.0, 0x6a4a2a, 'wood');
    } else if (t === 'garage') {
      const gx0 = r.x0 + 2, gx1 = r.x1 - 2, gz0 = r.z0 + 2, gz1 = r.z1 - 2, flo = 3.4;
      for (let f = 1; f <= 3; f++) {
        const hole: Rect = f % 2 ? { x0: gx0, x1: gx0 + 5, z0: gz0, z1: gz0 + 18 } : { x0: gx1 - 5, x1: gx1, z0: gz1 - 18, z1: gz1 };
        slabHole({ x0: gx0, x1: gx1, z0: gz0, z1: gz1 }, flo * f, 0.5, hole, 0x8a8a88);
        const up = f % 2 === 1;
        ramp(up ? gx0 : gx1 - 5, up ? gx0 + 5 : gx1, up ? gz0 : gz1 - 18, up ? gz0 + 18 : gz1, 1, up ? 1 : -1, flo * (f - 1), flo * f, 0x6e6e6c, false);
        for (let c = 0; c < 6; c++) if (rng() < 0.6) car(gx0 + 9 + c * 3, gz1 - 4, 1, flo * f);
      }
      for (let x = gx0; x <= gx1; x += (gx1 - gx0) / 4) for (const z of [gz0, gz1, (gz0 + gz1) / 2]) box(x, 0, z, 1, flo * 3, 1, 0x7a7a78, 'conc');
      rbox({ x0: gx0, x1: gx1, z0: gz1 - 0.3, z1: gz1 }, flo * 3, 0.9, 0x9a968e);
    }
  }
  function plazaDecor(bx: number, bz: number) {
    const r = { x0: bx - 24, x1: bx + 24, z0: bz - 24, z1: bz + 24 };
    for (let i = 0; i < 9; i++) { const x = R(r.x0 + 3, r.x1 - 3), z = R(r.z0 + 3, r.z1 - 3); if (isFree(x - 2, x + 2, z - 2, z + 2, 0) && Math.hypot(x, z) > 26) tree(x, z, R(0.9, 1.3)); }
    for (let i = 0; i < 8; i++) { const x = R(r.x0 + 3, r.x1 - 3), z = R(r.z0 + 3, r.z1 - 3); if (isFree(x - 2, x + 2, z - 2, z + 2, 0) && Math.hypot(x, z) > 26) box(x, 0, z, 3, 0.55, 0.9, 0x6a4a2a, 'wood'); }
    for (let i = 0; i < 4; i++) { const x = bx + (i % 2 ? 12 : -12), z = bz + (i < 2 ? 12 : -12); if (isFree(x - 3, x + 3, z - 3, z + 3, 0) && Math.hypot(x, z) > 28) { box(x, 0, z, 5, 1.0, 5, 0x9a9a98, 'conc'); tree(x, z, 0.8); } }
  }
  function buildBlocks() {
    for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) {
      const bx = (i - 3.5) * 64, bz = (j - 3.5) * 64, reg = regionAt(bx, bz);
      if (Math.abs(bx) < 56 && Math.abs(bz) < 56) { plazaDecor(bx, bz); continue; }
      const x0 = bx - 24, x1 = bx + 24, z0 = bz - 24, z1 = bz + 24, al = 4.2, p = rng();
      const rects: Rect[] = [];
      if (p < 0.22) rects.push({ x0, x1, z0, z1 });
      else if (p < 0.5) { const m = bx + R(-6, 6); rects.push({ x0, x1: m - al / 2, z0, z1 }, { x0: m + al / 2, x1, z0, z1 }); }
      else if (p < 0.72) { const m = bz + R(-6, 6); rects.push({ x0, x1, z0, z1: m - al / 2 }, { x0, x1, z0: m + al / 2, z1 }); }
      else { const mx = bx + R(-6, 6), mz = bz + R(-6, 6); rects.push({ x0, x1: mx - al / 2, z0, z1: mz - al / 2 }, { x0: mx + al / 2, x1, z0, z1: mz - al / 2 }, { x0, x1: mx - al / 2, z0: mz + al / 2, z1 }, { x0: mx + al / 2, x1, z0: mz + al / 2, z1 }); }
      for (const r of rects) { if (isFree(r.x0, r.x1, r.z0, r.z1, 3)) building(r, reg); else lotDecor(r, reg); }
    }
  }
  buildBlocks();

  // ---------- passarelas entre prédios ----------
  for (let a = 0; a < builtLots.length; a++) for (let b = 0; b < builtLots.length; b++) {
    const A = builtLots[a], B = builtLots[b]; if (a === b || A.h < 30 || B.h < 30 || rng() > 0.5) continue;
    const y = Math.min(A.h, B.h) - 6;
    if (Math.abs(B.r.x0 - A.r.x1 - 16) < 0.5) {
      const z0 = Math.max(A.r.z0, B.r.z0) + 3, z1 = Math.min(A.r.z1, B.r.z1) - 3;
      if (z1 - z0 > 6) { const zc = (z0 + z1) / 2, rc = { x0: A.r.x1 - 0.5, x1: B.r.x0 + 0.5, z0: zc - 2, z1: zc + 2 };
        if (isFree(rc.x0 + 1, rc.x1 - 1, rc.z0, rc.z1, 0)) { rbox(rc, y - 0.7, 0.7, 0x59616b, 'metal'); rbox({ ...rc, z1: rc.z0 + 0.2 }, y, 1, 0x59616b, 'metal'); rbox({ ...rc, z0: rc.z1 - 0.2 }, y, 1, 0x59616b, 'metal'); inst('box', 'glow', (rc.x0 + rc.x1) / 2, y - 0.75, zc, rc.x1 - rc.x0, 0.06, 4, 0, 0x25e2ff, true); } }
    } else if (Math.abs(B.r.z0 - A.r.z1 - 16) < 0.5) {
      const x0 = Math.max(A.r.x0, B.r.x0) + 3, x1 = Math.min(A.r.x1, B.r.x1) - 3;
      if (x1 - x0 > 6) { const xc = (x0 + x1) / 2, rc = { x0: xc - 2, x1: xc + 2, z0: A.r.z1 - 0.5, z1: B.r.z0 + 0.5 };
        if (isFree(rc.x0, rc.x1, rc.z0 + 1, rc.z1 - 1, 0)) { rbox(rc, y - 0.7, 0.7, 0x59616b, 'metal'); rbox({ ...rc, x1: rc.x0 + 0.2 }, y, 1, 0x59616b, 'metal'); rbox({ ...rc, x0: rc.x1 - 0.2 }, y, 1, 0x59616b, 'metal'); inst('box', 'glow', xc, y - 0.75, (rc.z0 + rc.z1) / 2, 4, 0.06, rc.z1 - rc.z0, 0, 0xff2d7a, true); } }
    }
  }

  // ---------- ruas ----------
  const streets: StreetLine[] = [];
  for (let k = -4; k <= 4; k++) { if (Math.abs(k) <= 3) { streets.push({ axis: 0, k, y: 0 }); streets.push({ axis: 1, k, y: 0 }); } }
  const cables: number[] = [];
  function streetProps() {
    for (const s of streets) {
      for (let m = -4; m <= 3; m++) {
        const t0 = m * 64 + 10;
        const P = (t: number, d: number): [number, number] => s.axis === 0 ? [s.k * 64 + d, t] : [t, s.k * 64 + d];
        if (Math.abs(m * 64 + 32) > 240) continue;
        for (const [ti, side] of [[t0 + 8, 1], [t0 + 40, -1]] as [number, number][]) {
          const [x, z] = P(ti, side * 7.4); if (!isFree(x - 1, x + 1, z - 1, z + 1, 0)) continue;
          const tx = s.axis === 0 ? -side : 0, tz = s.axis === 1 ? -side : 0;
          lamp(x, z, tx, tz);
        }
        const nc = RI(0, 3);
        for (let i = 0; i < nc; i++) {
          const t = R(t0 + 4, t0 + 44), side = rng() < 0.5 ? -1 : 1, [x, z] = P(t, side * 5.7);
          if (isFree(x - 2.4, x + 2.4, z - 2.4, z + 2.4, 0)) car(x, z, s.axis === 0 ? 1 : 0);
        }
        if (rng() < 0.3) { const side = rng() < 0.5 ? -1 : 1, t = R(t0 + 8, t0 + 40), [x, z] = P(t, side * 6.6); if (isFree(x - 3, x + 3, z - 3, z + 3, 0)) for (let i = 0; i < 3; i++) { const [bx, bz] = P(t + i * 3.2, side * 6.6); box(bx, 0, bz, s.axis === 0 ? 0.5 : 3, 0.9, s.axis === 0 ? 3 : 0.5, 0xb0aca4, 'conc'); } }
        if (rng() < 0.3) { const side = rng() < 0.5 ? -1 : 1, [x, z] = P(t0 + 24, side * 6.8); if (isFree(x - 2, x + 2, z - 2, z + 2, 0)) { if (rng() < 0.5) tree(x, z, 0.9); else box(x, 0, z, 2.4, 1.3, 1.4, 0x2f5a3a, 'metal'); } }
        if (rng() < 0.2) { const side = rng() < 0.5 ? -1 : 1, [x, z] = P(t0 + 28, side * 7.2); if (isFree(x - 2, x + 2, z - 2, z + 2, 0)) { box(x, 0, z, 1.4, 2.8, 1.4, 0xd0a020, 'metal'); inst('box', 'glow', x, 2.4, z, 1.0, 0.6, 1.0, 0, pick(NEON), true); } }
      }
    }
  }
  streetProps();

  // ---------- viadutos ----------
  function highway(axis: 0 | 1, k: number, crossAt: number) {
    const lineC = k * 64, Y1 = 8.5;
    for (let s = 0; s < 18; s++) {
      const a0 = -216 + s * 24, a1 = a0 + 24, ac = a0 + 12;
      const rc: Rect = axis === 0 ? { x0: lineC - 6, x1: lineC + 6, z0: a0, z1: a1 } : { x0: a0, x1: a1, z0: lineC - 6, z1: lineC + 6 };
      if (!isFree(rc.x0, rc.x1, rc.z0, rc.z1, 0)) continue;
      reserve(rc); rbox(rc, Y1 - 1, 1, 0x4a4a4c, 'conc', { detail: false });
      const crossing = a1 > crossAt - 8 && a0 < crossAt + 8;
      if (!crossing) {
        for (const sg of [-1, 1]) rbox(axis === 0 ? { x0: lineC + sg * 5.75 - 0.25, x1: lineC + sg * 5.75 + 0.25, z0: a0, z1: a1 } : { x0: a0, x1: a1, z0: lineC + sg * 5.75 - 0.25, z1: lineC + sg * 5.75 + 0.25 }, Y1, 0.9, 0xa8a49c, 'conc');
        for (const sg of [-1, 1]) { const px = axis === 0 ? lineC + sg * 3 : ac, pz = axis === 0 ? ac : lineC + sg * 3; box(px, 0, pz, 1.6, Y1 - 1, 1.6, 0x77777a, 'conc', { detail: false }); }
      }
      if (s % 2 === 0 && !crossing) { const sg = s % 4 === 0 ? 1 : -1; lamp(axis === 0 ? lineC + sg * 5.5 : ac, axis === 0 ? ac : lineC + sg * 5.5, axis === 0 ? -sg : 0, axis === 1 ? -sg : 0, Y1); }
    }
    const e: Rect[] = axis === 0 ? [{ x0: lineC - 6, x1: lineC + 6, z0: -256, z1: -216 }, { x0: lineC - 6, x1: lineC + 6, z0: 216, z1: 256 }] : [{ x0: -256, x1: -216, z0: lineC - 6, z1: lineC + 6 }, { x0: 216, x1: 256, z0: lineC - 6, z1: lineC + 6 }];
    e.forEach((r, i) => { if (isFree(r.x0, r.x1, r.z0, r.z1, 0)) { reserve(r); ramp(r.x0, r.x1, r.z0, r.z1, axis === 0 ? 1 : 0, i === 0 ? 1 : -1, 0, Y1, 0x4a4a4c, false); } });
    streets.push({ axis, k, y: Y1 });
  }
  highway(1, -1, 64); highway(0, 1, -64);

  // ---------- skyline distante ----------
  for (let i = 0; i < 170; i++) {
    const ang = rng() * Math.PI * 2, rad = R(330, 900);
    const x = Math.cos(ang) * rad * 1.0, z = Math.sin(ang) * rad;
    if (Math.abs(x) < 300 && Math.abs(z) < 300) continue;
    const h = R(40, 260) * (rad < 500 ? 0.8 : 1);
    inst('box', 'bld', x, h / 2, z, R(22, 55), h, R(22, 55), 0, pick([0x2c3e55, 0x39495e, 0x4a5568, 0x25303f, 0x5a6270]), false, true);
  }
  // luzes dos prédios vizinhos, helicópteros etc. ficam em life.ts

  // ---------- coletáveis / checkpoints / segredos ----------
  const coins: CoinPos[] = [];
  const secrets: Secret[] = [];
  const cps: CP[] = [];
  for (let i = 0; i < route.length - 1; i++) {
    const a = route[i], b = route[i + 1];
    if (a.kind === 'tower' && b.kind === 'tower' && i % 2) continue;
    const t = a.kind === 'tower' ? 0.5 : 0.5;
    const x = a.x + (b.x - a.x) * t, z = a.z + (b.z - a.z) * t, y = Math.max(a.y, b.y) + 1.5;
    coins.push({ id: coins.length, x, y, z });
    if (b.kind === 'wide' || b.kind === 'swing' || b.kind === 'wallrun') {
      coins.push({ id: coins.length, x: a.x + (b.x - a.x) * 0.35, y: y + 0.4, z: a.z + (b.z - a.z) * 0.35 });
      coins.push({ id: coins.length, x: a.x + (b.x - a.x) * 0.65, y: y + 0.4, z: a.z + (b.z - a.z) * 0.65 });
    }
  }
  for (let i = 0; i < route.length; i++) {
    const p = route[i];
    if (i === 0 || (i % 8 === 0 && p.kind !== 'tower') || (p.kind === 'tower' && i % 6 === 0) || p.kind === 'summit')
      cps.push({ id: cps.length, x: p.x, y: p.y, z: p.z, yaw: i + 1 < route.length ? Math.atan2(-(route[i + 1].x - p.x), -(route[i + 1].z - p.z)) : 0, routeIdx: i });
  }
  const spineN = route.findIndex((p) => p.kind === 'tower');
  for (const f of [0.07, 0.16, 0.28, 0.4, 0.52, 0.63, 0.75, 0.88]) {
    const p = route[Math.floor(f * (spineN - 1))]; if (!p) continue;
    const dxa = Math.abs(Math.sin(p.yaw)) > 0.5, hw = dxa ? p.hz : p.hx;
    for (const sg of [1, -1]) {
      const lat = sg * (hw + 5.6 + 3), cx = dxa ? p.x : p.x + lat, cz = dxa ? p.z + lat : p.z;
      const rc: Rect = { x0: cx - 3, x1: cx + 3, z0: cz - 3, z1: cz + 3 };
      if (!isFree(rc.x0, rc.x1, rc.z0, rc.z1, 0.5) || Math.abs(cx) > 258 || Math.abs(cz) > 258) continue;
      reserve(rc); const ytop = p.y + 0.6;
      rbox(rc, 0, ytop, 0x4a2f6a, 'bld', { detail: false });
      inst('box', 'glow', cx, ytop + 0.05, cz, 5.8, 0.1, 5.8, 0, 0xb04bff, true);
      cyl(cx + 2.5, ytop, cz + 2.5, 0.2, 2.5, 0x333, 'metal');
      secrets.push({ id: 's' + secrets.length, x: cx, y: ytop + 1.4, z: cz });
      coins.push({ id: coins.length, x: dxa ? p.x + Math.sin(p.yaw) * 0 : p.x + sg * (hw + 2.8), y: p.y + 2.4, z: dxa ? p.z + sg * (hw + 2.8) : p.z });
      break;
    }
  }

  // cabos (visual)
  for (let i = 0; i < spineN - 1; i++) {
    const a = route[i], b = route[i + 1];
    if (a.kind === 'slide' || b.kind === 'slide' || rng() > 0.3) continue;
    const p0 = new THREE.Vector3(a.x, a.y + 3.6, a.z), p1 = new THREE.Vector3(b.x, b.y + 3.6, b.z);
    cyl(a.x, a.y, a.z + 2, 0.1, 3.6, 0x222, 'metal', true, true); cyl(b.x, b.y, b.z + 2, 0.1, 3.6, 0x222, 'metal', true, true);
    p0.z += 2; p1.z += 2;
    for (let s = 0; s < 8; s++) for (const u of [s / 8, (s + 1) / 8]) cables.push(p0.x + (p1.x - p0.x) * u, p0.y + (p1.y - p0.y) * u - Math.sin(u * Math.PI) * 1.4, p0.z + (p1.z - p0.z) * u);
  }
  // ---------- montar meshes ----------
  const chunkGroups = new Map<number, { main: THREE.Group; detail: THREE.Group; x: number; z: number }>();
  const farGroup = new THREE.Group(); group.add(farGroup);
  batches.forEach((b) => {
    const mat = b.mat === 'lamp' ? lampMat : MATS[b.mat];
    const mesh = new THREE.InstancedMesh(GEOS[b.geo], mat, b.n);
    (mesh.instanceMatrix.array as Float32Array).set(b.m);
    mesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(b.c), 3);
    mesh.castShadow = b.mat !== 'glow' && b.mat !== 'lamp' && b.chunk !== 99; mesh.receiveShadow = true;
    mesh.computeBoundingSphere(); mesh.matrixAutoUpdate = false;
    if (b.chunk === 99) { farGroup.add(mesh); return; }
    let cg = chunkGroups.get(b.chunk);
    if (!cg) {
      const cx = Math.floor(b.chunk / 7), cz = b.chunk % 7;
      cg = { main: new THREE.Group(), detail: new THREE.Group(), x: cx * 100 - 320 + 50, z: cz * 100 - 320 + 50 };
      group.add(cg.main, cg.detail); chunkGroups.set(b.chunk, cg);
    }
    (b.detail ? cg.detail : cg.main).add(mesh);
  });
  // chão
  const groundMat = makeStd(5, { roughness: 0.92 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(5000, 5000), groundMat);
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; group.add(ground);
  // decalques de luz
  const decalMat = new THREE.MeshBasicMaterial({ map: radialTexture('rgba(255,200,120,0.9)', 'rgba(255,170,80,0)'), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0, toneMapped: false, fog: true });
  const dm = new THREE.InstancedMesh(new THREE.PlaneGeometry(14, 14).rotateX(-Math.PI / 2), decalMat, Math.max(1, decals.length));
  decals.forEach((d, i) => { _m.compose(_p.set(d[0], 0.06, d[1]), _q.identity(), _s.set(1, 1, 1)); dm.setMatrixAt(i, _m); });
  dm.frustumCulled = false; group.add(dm);
  // cabos
  if (cables.length) {
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(cables, 3));
    group.add(new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0x15171b })));
  }
  const cam2 = new THREE.Vector3();
  function update(cam: THREE.Vector3, viewDist: number) {
    cam2.copy(cam);
    chunkGroups.forEach((cg) => {
      const d = Math.hypot(cg.x - cam.x, cg.z - cam.z);
      cg.main.visible = d < viewDist + 110; cg.detail.visible = d < Math.min(viewDist * 0.75, 200) + 70;
    });
  }
  const routeLen = (a: number, b: number) => { let s = 0; for (let i = a; i < b; i++) s += Math.hypot(route[i + 1].x - route[i].x, route[i + 1].z - route[i].z); return s; };
  return { group, grid, route, cps, secrets, coins, bars, streets, update, lampMat, decalMat, glowMat, towerTop, routeLen, stats: { instances: instCount, colliders: grid.all.length } };
}
