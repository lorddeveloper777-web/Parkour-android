import * as THREE from 'three';
import { Cosmetics, OUTFITS, COLORS, GLOVES, SHOES, ACCS, find } from './store';

const box = (w: number, h: number, d: number) => new THREE.BoxGeometry(w, h, d);
const GEO = { thigh: box(0.19, 0.46, 0.21), shin: box(0.16, 0.46, 0.18), shoe: box(0.2, 0.12, 0.34), torso: box(0.46, 0.6, 0.27), upper: box(0.14, 0.3, 0.15), fore: box(0.12, 0.3, 0.13), glove: box(0.13, 0.12, 0.14), head: box(0.2, 0.23, 0.22), hood: box(0.27, 0.28, 0.3), pack: box(0.34, 0.42, 0.16), sole: box(0.205, 0.04, 0.35), stripe: box(0.47, 0.06, 0.28) };

export interface Pose { lt: number; lk: number; rt: number; rk: number; la: number; lf: number; ra: number; rf: number; lean: number; headX: number; rootX: number; rootY: number }
const zero = (): Pose => ({ lt: 0, lk: 0, rt: 0, rk: 0, la: 0, lf: 0, ra: 0, rf: 0, lean: 0, headX: 0, rootX: 0, rootY: 0 });

export class Character {
  root = new THREE.Group(); body = new THREE.Group();
  private parts: Record<string, THREE.Group> = {};
  private mats: Record<string, THREE.MeshStandardMaterial> = {};
  private acc: Record<string, THREE.Object3D> = {};
  cur = zero(); phase = 0;

  constructor(cos?: Cosmetics) {
    const M = (k: string, c = 0x222222, r = 0.8, m = 0.05) => (this.mats[k] = new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m }));
    M('cloth', 0x16181d); M('pants', 0x1b1d22); M('glove', 0x101010, 0.9); M('shoe', 0xf0f0f0, 0.6); M('sole', 0x222222); M('skin', 0xc8956b, 0.7); M('accent', 0xffc400, 0.5); M('acc', 0x111111, 0.6);
    const mk = (g: THREE.BufferGeometry, m: string, p: THREE.Object3D, x = 0, y = 0, z = 0) => { const me = new THREE.Mesh(g, this.mats[m]); me.position.set(x, y, z); me.castShadow = true; p.add(me); return me; };
    const grp = (name: string, parent: THREE.Object3D, x = 0, y = 0, z = 0) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); this.parts[name] = g; return g; };
    this.root.add(this.body);
    const hips = grp('hips', this.body, 0, 0.95, 0);
    for (const s of ['l', 'r']) {
      const sx = s === 'l' ? -0.115 : 0.115;
      const th = grp(s + 'thigh', hips, sx, 0, 0); mk(GEO.thigh, 'pants', th, 0, -0.23);
      const kn = grp(s + 'knee', th, 0, -0.46, 0); mk(GEO.shin, 'pants', kn, 0, -0.23);
      mk(GEO.shoe, 'shoe', kn, 0, -0.5, -0.06); mk(GEO.sole, 'sole', kn, 0, -0.545, -0.06);
    }
    const spine = grp('spine', hips, 0, 0, 0); mk(GEO.torso, 'cloth', spine, 0, 0.32); mk(GEO.stripe, 'accent', spine, 0, 0.12);
    for (const s of ['l', 'r']) {
      const sx = s === 'l' ? -0.31 : 0.31;
      const ar = grp(s + 'arm', spine, sx, 0.55, 0); mk(GEO.upper, 'cloth', ar, 0, -0.15);
      const fo = grp(s + 'fore', ar, 0, -0.3, 0); mk(GEO.fore, 'cloth', fo, 0, -0.15); mk(GEO.glove, 'glove', fo, 0, -0.34);
    }
    const head = grp('head', spine, 0, 0.66, 0); mk(GEO.head, 'skin', head, 0, 0.13, 0.01); mk(GEO.hood, 'cloth', head, 0, 0.15, 0.04);
    // acessórios
    const mask = mk(box(0.205, 0.1, 0.03), 'acc', head, 0, 0.07, -0.115); this.acc.a2 = mask;
    const pack = mk(GEO.pack, 'acc', spine, 0, 0.32, 0.21); this.acc.a3 = pack;
    const gog = mk(box(0.21, 0.06, 0.03), 'accent', head, 0, 0.17, -0.12); this.acc.a4 = gog;
    const cap = new THREE.Group(); mk(box(0.25, 0.07, 0.26), 'acc', cap, 0, 0.3, 0); mk(box(0.22, 0.02, 0.14), 'acc', cap, 0, 0.27, -0.2); head.add(cap); this.acc.a5 = cap;
    const band = mk(box(0.215, 0.04, 0.235), 'accent', head, 0, 0.23, 0.01); this.acc.a6 = band;
    this.root.traverse((o) => { if ((o as THREE.Mesh).isMesh) o.castShadow = true; });
    if (cos) this.setCosmetics(cos);
  }

  setCosmetics(c: Cosmetics) {
    const o = find(OUTFITS, c.outfit), col = find(COLORS, c.color), g = find(GLOVES, c.gloves), s = find(SHOES, c.shoes), a = find(ACCS, c.acc);
    this.mats.cloth.color.setHex(o.color); this.mats.pants.color.setHex(0x1b1d22); this.mats.accent.color.setHex(col.color); this.mats.accent.emissive.setHex(col.color).multiplyScalar(0.15);
    this.mats.glove.color.setHex(g.color); this.mats.shoe.color.setHex(s.color); this.mats.sole.color.setHex(col.color);
    for (const k of ['a2', 'a3', 'a4', 'a5', 'a6']) this.acc[k].visible = k === a.id;
    if (a.id === 'a5') this.mats.acc.color.setHex(0x222222); else if (a.id === 'a3') this.mats.acc.color.setHex(0x2a3340); else this.mats.acc.color.setHex(a.color || 0x111111);
  }

  /** estados: idle run jump slide roll hang wallrun climb */
  setState(st: string, speed: number, dt: number, time: number) {
    const t = zero(); const P = this.parts;
    if (st === 'run') {
      this.phase += dt * (6 + speed * 0.55); const s = Math.sin(this.phase), c = Math.cos(this.phase), a = Math.min(1, speed / 9);
      t.lt = s * 1.0 * a; t.rt = -s * 1.0 * a; t.lk = Math.max(0, -c) * 1.5 * a + 0.1; t.rk = Math.max(0, c) * 1.5 * a + 0.1;
      t.la = -s * 0.9 * a; t.ra = s * 0.9 * a; t.lf = -1.1 * a; t.rf = -1.1 * a; t.lean = 0.28 * a; t.rootY = Math.abs(Math.cos(this.phase)) * 0.05;
    } else if (st === 'jump') {
      t.lt = -1.35; t.lk = 1.5; t.rt = 0.55; t.rk = 1.2; t.la = -1.6; t.lf = -0.5; t.ra = 0.9; t.rf = -0.4; t.lean = 0.35; t.headX = -0.2;
    } else if (st === 'slide') { t.lt = -1.2; t.lk = 0.1; t.rt = -1.0; t.rk = 0.7; t.la = 0.6; t.ra = -0.4; t.lean = -0.5; t.rootY = -0.45; t.rootX = -0.5; }
    else if (st === 'roll') { t.lt = -1.6; t.lk = 2.0; t.rt = -1.6; t.rk = 2.0; t.la = -1.4; t.ra = -1.4; t.lf = -1.6; t.rf = -1.6; t.lean = 0.8; t.rootY = -0.35; }
    else if (st === 'hang') { t.la = -3.0; t.ra = -3.0; t.lt = 0.1; t.rt = -0.1; t.lk = 0.4; t.rk = 0.3; t.rootY = 0; }
    else if (st === 'wallrun') { const s = Math.sin(this.phase += dt * 11); t.lt = s * 0.9; t.rt = -s * 0.9; t.lk = 0.8; t.rk = 0.8; t.la = -0.9; t.ra = -0.9; t.lean = 0.2; }
    else if (st === 'climb') { t.la = -2.6; t.ra = -2.8; t.lt = -1.3; t.lk = 1.4; t.rt = 0.2; t.lean = 0.3; }
    else { const b = Math.sin(time * 1.6) * 0.03; t.la = b; t.ra = -b; t.lf = -0.15; t.rf = -0.15; t.headX = 0.0; }
    const k = 1 - Math.exp(-14 * dt); const cur = this.cur as any;
    for (const key of Object.keys(t)) cur[key] += ((t as any)[key] - cur[key]) * k;
    const c = this.cur;
    P.lthigh.rotation.x = c.lt; P.lknee.rotation.x = c.lk; P.rthigh.rotation.x = c.rt; P.rknee.rotation.x = c.rk;
    P.larm.rotation.x = c.la; P.lfore.rotation.x = c.lf; P.rarm.rotation.x = c.ra; P.rfore.rotation.x = c.rf;
    P.spine.rotation.x = -c.lean; P.head.rotation.x = c.headX + c.lean * 0.6; P.hips.position.y = 0.95 + c.rootY; P.hips.rotation.x = c.rootX;
  }
}

/** braços em primeira pessoa (filhos da câmera) */
export class FPArms {
  group = new THREE.Group();
  private arms: THREE.Group[] = []; private mats: Record<string, THREE.MeshStandardMaterial>;
  private p = [new THREE.Vector3(), new THREE.Vector3()]; private r = [new THREE.Euler(), new THREE.Euler()];
  private phase = 0;
  constructor() {
    const mk = (c: number, rough = 0.85) => new THREE.MeshStandardMaterial({ color: c, roughness: rough, depthTest: false });
    this.mats = { sleeve: mk(0x16181d), glove: mk(0x101010, 0.9), skin: mk(0xc8956b, 0.7) };
    for (const s of [-1, 1]) {
      const g = new THREE.Group();
      const add = (geo: THREE.BufferGeometry, m: string, x: number, y: number, z: number, rx = 0) => { const me = new THREE.Mesh(geo, this.mats[m]); me.position.set(x, y, z); me.rotation.x = rx; me.renderOrder = 999; g.add(me); return me; };
      add(new THREE.BoxGeometry(0.115, 0.115, 0.5), 'sleeve', 0, 0, -0.1);
      add(new THREE.BoxGeometry(0.11, 0.075, 0.12), 'glove', 0, 0, -0.4);
      for (let i = 0; i < 4; i++) add(new THREE.BoxGeometry(0.022, 0.026, 0.075), 'skin', -0.04 + i * 0.027, 0.0, -0.5);
      add(new THREE.BoxGeometry(0.03, 0.03, 0.07), 'skin', -s * 0.07, -0.005, -0.4, 0.3);
      g.renderOrder = 999; this.arms.push(g); this.group.add(g);
    }
    this.group.renderOrder = 999; this.group.scale.setScalar(0.72);
  }
  setCosmetics(c: Cosmetics) {
    this.mats.sleeve.color.setHex(find(OUTFITS, c.outfit).color); this.mats.glove.color.setHex(find(GLOVES, c.gloves).color);
  }
  update(dt: number, speed: number, pump: number, reach: number, wallSide: number, time: number) {
    this.phase += dt * (5 + speed * 0.5);
    const s = Math.sin(this.phase), c = Math.cos(this.phase * 2);
    for (let i = 0; i < 2; i++) {
      const sg = i === 0 ? -1 : 1; const ph = i === 0 ? s : -s;
      let x = sg * 0.3, y = -0.3, z = -0.34, rx = -0.1, ry = -sg * 0.12, rz = 0;
      x += sg * 0.0; y += c * 0.015 * pump; z += ph * 0.1 * pump; rx += ph * 0.35 * pump; y += Math.sin(time * 1.5 + i) * 0.003;
      if (reach === 0.5) { y += 0.04; rx += 0.3; z -= 0.05; }
      else if (reach === 1) { const wall = sg === wallSide; if (wall) { x = sg * 0.5; y = -0.15; rx = -0.1; rz = -sg * 0.5; ry = sg * 0.5; z = -0.45; } else { y = -0.3; rx = 0.2; } }
      else if (reach === 2 || reach === 3) { y = 0.02; z = -0.34; x = sg * 0.2; rx = 1.05; ry = -sg * 0.1; }
      else if (reach === 4) { x = sg * 0.28; y = -0.34; z = -0.15; rx = -0.4; ry = -sg * 0.3; }
      this.p[i].set(x, y, z); this.r[i].set(rx, ry, rz);
      const a = this.arms[i]; const k = 1 - Math.exp(-16 * dt);
      a.position.lerp(this.p[i], k);
      a.rotation.x += (rx - a.rotation.x) * k; a.rotation.y += (ry - a.rotation.y) * k; a.rotation.z += (rz - a.rotation.z) * k;
    }
  }
}
