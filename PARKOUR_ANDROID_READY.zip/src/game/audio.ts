import * as THREE from 'three';

interface PosEmitter { panner: PannerNode; gain: GainNode; setPos: (x: number, y: number, z: number) => void }

export class AudioSys {
  ctx: AudioContext | null = null; master!: GainNode; musicBus!: GainNode; sfxBus!: GainNode; white!: AudioBuffer; brown!: AudioBuffer;
  vols = { master: 0.8, music: 0.5, sfx: 0.8 };
  private windG!: GainNode; private windF!: BiquadFilterNode; private rainG!: GainNode; private cityG!: GainNode; private scrapeG!: GainNode; private slideG!: GainNode;
  private musicTimer: number | null = null; private nextT = 0; private step = 0; intensity = 0; private targetIntensity = 0; private musicOn = false;
  private heli?: PosEmitter; private siren?: PosEmitter; private cars: PosEmitter[] = []; 
  private breathT = 0; private eventT = 6; private ready = false;

  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    try {
      const C = window.AudioContext || (window as any).webkitAudioContext; this.ctx = new C();
    } catch { return; }
    const c = this.ctx!;
    this.master = c.createGain(); this.musicBus = c.createGain(); this.sfxBus = c.createGain();
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    this.musicBus.connect(this.master); this.sfxBus.connect(this.master); this.master.connect(comp); comp.connect(c.destination);
    this.white = c.createBuffer(1, c.sampleRate * 2, c.sampleRate); const w = this.white.getChannelData(0); for (let i = 0; i < w.length; i++) w[i] = Math.random() * 2 - 1;
    this.brown = c.createBuffer(1, c.sampleRate * 4, c.sampleRate); const b = this.brown.getChannelData(0); let l = 0; for (let i = 0; i < b.length; i++) { l = (l + 0.02 * (Math.random() * 2 - 1)) / 1.02; b[i] = l * 3.5; }
    this.setVolumes(this.vols.master, this.vols.music, this.vols.sfx);
    const loop = (buf: AudioBuffer, type: BiquadFilterType, f: number, q: number, g: number, dest: AudioNode = this.sfxBus) => {
      const s = c.createBufferSource(); s.buffer = buf; s.loop = true; const fl = c.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q;
      const gn = c.createGain(); gn.gain.value = g; s.connect(fl); fl.connect(gn); gn.connect(dest); s.start(); return { gn, fl };
    };
    const wd = loop(this.white, 'bandpass', 500, 0.5, 0); this.windG = wd.gn; this.windF = wd.fl;
    this.rainG = loop(this.white, 'highpass', 3000, 0.5, 0).gn;
    this.cityG = loop(this.brown, 'lowpass', 220, 0.7, 0.0).gn;
    this.scrapeG = loop(this.white, 'bandpass', 2600, 4, 0).gn;
    this.slideG = loop(this.white, 'bandpass', 900, 0.8, 0).gn;
    // emissores 3D
    this.heli = this.mkEmitter((out) => {
      const n = c.createBufferSource(); n.buffer = this.brown; n.loop = true; const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 500;
      const am = c.createGain(); am.gain.value = 0.5; const lfo = c.createOscillator(); lfo.frequency.value = 13; const lg = c.createGain(); lg.gain.value = 0.5; lfo.connect(lg); lg.connect(am.gain);
      n.connect(f); f.connect(am); am.connect(out); n.start(); lfo.start();
    }, 0.9);
    this.siren = this.mkEmitter((out) => {
      const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 800; const l = c.createOscillator(); l.frequency.value = 0.45; const lg = c.createGain(); lg.gain.value = 260;
      l.connect(lg); lg.connect(o.frequency); const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1800; const g = c.createGain(); g.gain.value = 0.05;
      o.connect(f); f.connect(g); g.connect(out); o.start(); l.start();
    }, 0.5);
    for (let i = 0; i < 3; i++) this.cars.push(this.mkEmitter((out) => {
      const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 55 + i * 9; const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 260;
      const n = c.createBufferSource(); n.buffer = this.brown; n.loop = true; const g = c.createGain(); g.gain.value = 0.5; o.connect(f); n.connect(f); f.connect(g); g.connect(out); o.start(); n.start();
    }, 0.6));
    this.ready = true;
  }
  private mkEmitter(build: (out: AudioNode) => void, vol: number): PosEmitter {
    const c = this.ctx!; const p = c.createPanner(); p.panningModel = 'HRTF'; p.distanceModel = 'inverse'; p.refDistance = 10; p.maxDistance = 400; p.rolloffFactor = 1.5;
    const g = c.createGain(); g.gain.value = vol; build(g); g.connect(p); p.connect(this.sfxBus);
    return { panner: p, gain: g, setPos: (x, y, z) => { if (p.positionX) { p.positionX.value = x; p.positionY.value = y; p.positionZ.value = z; } else (p as any).setPosition(x, y, z); } };
  }
  setVolumes(m: number, mu: number, s: number) {
    this.vols = { master: m, music: mu, sfx: s }; if (!this.ctx) return;
    this.master.gain.value = m; this.musicBus.gain.value = mu * 0.55; this.sfxBus.gain.value = s;
  }
  setListener(p: THREE.Vector3, yaw: number) {
    if (!this.ctx) return; const l = this.ctx.listener; const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
    if (l.positionX) { l.positionX.value = p.x; l.positionY.value = p.y; l.positionZ.value = p.z; l.forwardX.value = fx; l.forwardY.value = 0; l.forwardZ.value = fz; l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0; }
    else { (l as any).setPosition(p.x, p.y, p.z); (l as any).setOrientation(fx, 0, fz, 0, 1, 0); }
  }

  // ---------- primitivas
  private burst(dur: number, freq: number, q: number, gain: number, type: BiquadFilterType = 'bandpass', delay = 0, sweepTo?: number, dest?: AudioNode) {
    if (!this.ctx) return; const c = this.ctx, t = c.currentTime + delay;
    const s = c.createBufferSource(); s.buffer = this.white; s.loop = true; const f = c.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t); if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur); f.Q.value = q;
    const g = c.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain, t + Math.min(0.01, dur / 3)); g.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    s.connect(f); f.connect(g); g.connect(dest || this.sfxBus); s.start(t, Math.random()); s.stop(t + dur + 0.05);
  }
  private tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0, slideTo?: number, dest?: AudioNode) {
    if (!this.ctx) return; const c = this.ctx, t = c.currentTime + delay; const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    o.connect(g); g.connect(dest || this.sfxBus); o.start(t); o.stop(t + dur + 0.05);
  }

  // ---------- efeitos do jogador
  footstep(surf: number, spd: number) {
    const v = Math.min(1, 0.35 + spd / 14) * (0.8 + Math.random() * 0.4);
    if (surf === 1) { this.burst(0.12, 1700 + Math.random() * 300, 3, 0.35 * v); this.tone(380 + Math.random() * 60, 0.18, 'sine', 0.06 * v); }
    else if (surf === 2) this.burst(0.1, 520 + Math.random() * 100, 1.5, 0.45 * v);
    else if (surf === 3) this.burst(0.14, 420, 0.6, 0.3 * v, 'lowpass');
    else { this.burst(0.07, 1100 + Math.random() * 400, 1.2, 0.4 * v); this.burst(0.05, 180, 0.8, 0.25 * v, 'lowpass'); }
  }
  jump() { this.burst(0.12, 700, 0.8, 0.12, 'bandpass', 0, 1800); this.tone(180, 0.1, 'sine', 0.05, 0, 320); }
  land(impact: number, surf: number) {
    const v = Math.min(1, impact / 24); this.burst(0.25, 240, 0.7, 0.3 + v * 0.6, 'lowpass'); this.tone(70 + (1 - v) * 40, 0.25, 'sine', 0.2 + v * 0.5, 0, 40);
    if (surf === 1) this.burst(0.4, 1500, 5, 0.25 * v + 0.05); if (v > 0.5) this.burst(0.35, 90, 0.5, 0.6 * v, 'lowpass');
  }
  vault() { this.burst(0.22, 500, 1, 0.3, 'bandpass', 0, 1400); this.burst(0.08, 1200, 2, 0.25, 'bandpass', 0.18); }
  climb() { this.burst(0.3, 400, 1, 0.25, 'bandpass', 0, 900); this.burst(0.1, 900, 2, 0.3, 'bandpass', 0.35); this.tone(150, 0.14, 'triangle', 0.12, 0.34, 90); }
  hang() { this.burst(0.1, 1500, 4, 0.25); this.tone(140, 0.2, 'triangle', 0.15, 0, 100); }
  walljump() { this.burst(0.15, 900, 1.2, 0.35); this.tone(240, 0.12, 'square', 0.04, 0, 520); }
  wallStart() { this.burst(0.2, 1200, 2, 0.3, 'bandpass', 0, 3200); }
  roll() { this.burst(0.5, 300, 0.7, 0.4, 'bandpass', 0, 120); this.tone(90, 0.3, 'sine', 0.3, 0, 45); this.burst(0.2, 900, 1, 0.2, 'bandpass', 0.2); }
  heavy() { this.burst(0.5, 120, 0.6, 0.9, 'lowpass'); this.tone(55, 0.5, 'sine', 0.8, 0, 28); this.burst(0.5, 1800, 6, 0.2); }
  fatal() { this.burst(0.8, 100, 0.5, 1.0, 'lowpass'); this.tone(48, 0.8, 'sine', 1.0, 0, 20); this.burst(0.6, 2200, 6, 0.3); }
  swingGrab() { this.tone(220, 0.25, 'triangle', 0.18, 0, 160); this.burst(0.2, 2000, 5, 0.25); }
  dash() { this.burst(0.35, 600, 0.7, 0.45, 'bandpass', 0, 3000); }
  bump() { this.burst(0.15, 160, 0.7, 0.5, 'lowpass'); }
  coin() { this.tone(988, 0.1, 'square', 0.06); this.tone(1319, 0.28, 'square', 0.06, 0.07); }
  perfect() { this.tone(660, 0.12, 'triangle', 0.1); this.tone(880, 0.22, 'triangle', 0.1, 0.08); }
  checkpoint() { [523, 659, 784].forEach((f, i) => this.tone(f, 0.3, 'triangle', 0.14, i * 0.09)); }
  secret() { [392, 523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.4, 'sine', 0.15, i * 0.1)); }
  ui() { this.tone(520, 0.06, 'square', 0.05); }
  uiBack() { this.tone(380, 0.07, 'square', 0.05, 0, 260); }
  count() { this.tone(660, 0.12, 'square', 0.08); }
  go() { this.tone(990, 0.4, 'square', 0.1); }
  medal(m: number) { const n = [523, 659, 784, 1047]; for (let i = 0; i < 2 + m; i++) this.tone(n[Math.min(3, i)] * (i > 3 ? 1.25 : 1), 0.35, 'triangle', 0.15, i * 0.12); }
  levelUp() { [392, 523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, 0.5, 'sawtooth', 0.05, i * 0.08)); }
  fail() { this.tone(300, 0.5, 'sawtooth', 0.1, 0, 90); }

  // ---------- atualização contínua
  update(dt: number, s: { playing: boolean; speed: number; sprinting: boolean; sliding: boolean; wallrun: boolean; height: number; rain: boolean; weatherAmb: number; challenge: boolean; flow: number; menu: boolean;
    heli: THREE.Vector3; siren: THREE.Vector3; cars: THREE.Vector3[]; stamina: number; player: THREE.Vector3 }) {
    if (!this.ctx || !this.ready) return; const c = this.ctx, t = c.currentTime;
    const sm = (p: AudioParam, v: number, k = 0.15) => p.setTargetAtTime(v, t, k);
    const wind = s.playing ? Math.min(0.55, s.speed * 0.022 + Math.min(0.2, s.height * 0.0016)) : 0.06 + Math.min(0.1, s.height * 0.0008);
    sm(this.windG.gain, wind * (0.7 + 0.3 * s.weatherAmb)); this.windF.frequency.setTargetAtTime(350 + s.speed * 45 + s.height * 3, t, 0.2);
    sm(this.rainG.gain, s.rain ? 0.2 : 0); sm(this.cityG.gain, 0.12 * Math.max(0.2, 1 - s.height / 220) * s.weatherAmb);
    sm(this.scrapeG.gain, s.wallrun ? 0.13 : 0, 0.05); sm(this.slideG.gain, s.sliding ? Math.min(0.32, 0.06 + s.speed * 0.02) : 0, 0.05);
    // respiração
    if (s.playing && s.sprinting) { this.breathT -= dt; const rate = 0.75 - Math.min(0.3, (100 - s.stamina) * 0.004); if (this.breathT <= 0) { this.breathT = rate; this.burst(0.28, 900, 0.8, 0.07 + (1 - s.stamina / 120) * 0.1, 'bandpass', 0, 600); } }
    // emissores
    this.heli?.setPos(s.heli.x, s.heli.y, s.heli.z); this.siren?.setPos(s.siren.x, s.siren.y, s.siren.z);
    for (let i = 0; i < this.cars.length; i++) { const p = s.cars[i]; if (p) { this.cars[i].setPos(p.x, p.y, p.z); this.cars[i].gain.gain.setTargetAtTime(0.5, t, 0.2); } else this.cars[i].gain.gain.setTargetAtTime(0, t, 0.2); }
    // eventos urbanos
    this.eventT -= dt; if (this.eventT <= 0) {
      this.eventT = 5 + Math.random() * 9; const a = Math.random() * 6.28, d = 50 + Math.random() * 90; const p = this.mkTmp(s.player.x + Math.cos(a) * d, s.player.y, s.player.z + Math.sin(a) * d);
      if (Math.random() < 0.5) { this.tone(420, 0.35, 'square', 0.05, 0, undefined, p); this.tone(340, 0.5, 'square', 0.05, 0.4, undefined, p); }
      else this.burst(0.6, 1400, 8, 0.2, 'bandpass', 0, 900, p);
    }
    // música
    this.targetIntensity = s.menu ? 0.28 : s.challenge ? 0.55 + Math.min(0.45, s.speed / 22) : 0.18 + Math.min(0.3, s.flow * 0.06);
    this.intensity += (this.targetIntensity - this.intensity) * Math.min(1, dt * 0.8);
    if (!this.musicOn) this.startMusic();
  }
  private mkTmp(x: number, y: number, z: number): AudioNode {
    const p = this.ctx!.createPanner(); p.panningModel = 'HRTF'; p.refDistance = 12; p.rolloffFactor = 1.4; if (p.positionX) { p.positionX.value = x; p.positionY.value = y; p.positionZ.value = z; }
    p.connect(this.sfxBus); return p;
  }

  // ---------- música procedural
  private startMusic() {
    this.musicOn = true; this.nextT = this.ctx!.currentTime + 0.1; this.step = 0;
    this.musicTimer = window.setInterval(() => {
      const c = this.ctx!; if (c.state !== 'running') return; const bpm = 86 + this.intensity * 44, sd = 60 / bpm / 4;
      if (this.nextT < c.currentTime) this.nextT = c.currentTime + 0.05;
      while (this.nextT < c.currentTime + 0.3) { this.playStep(this.step, this.nextT); this.nextT += sd; this.step = (this.step + 1) % 64; }
    }, 80);
  }
  private mTone(f: number, t: number, dur: number, type: OscillatorType, g: number, cut = 1200) {
    const c = this.ctx!; const o = c.createOscillator(); o.type = type; o.frequency.value = f; const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.setValueAtTime(cut, t); fl.frequency.exponentialRampToValueAtTime(Math.max(120, cut * 0.25), t + dur);
    const gn = c.createGain(); gn.gain.setValueAtTime(0, t); gn.gain.linearRampToValueAtTime(g, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0005, t + dur); o.connect(fl); fl.connect(gn); gn.connect(this.musicBus); o.start(t); o.stop(t + dur + 0.05);
  }
  private mNoise(t: number, dur: number, freq: number, g: number, type: BiquadFilterType = 'highpass') {
    const c = this.ctx!; const s = c.createBufferSource(); s.buffer = this.white; const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; const gn = c.createGain();
    gn.gain.setValueAtTime(g, t); gn.gain.exponentialRampToValueAtTime(0.0005, t + dur); s.connect(f); f.connect(gn); gn.connect(this.musicBus); s.start(t, Math.random()); s.stop(t + dur + 0.02);
  }
  private playStep(s: number, t: number) {
    const I = this.intensity, bar = Math.floor(s / 16) % 4, roots = [55, 43.65, 65.41, 49], r = roots[bar], st = s % 16;
    if (st === 0) { [1, 1.189, 1.498].forEach((m) => this.mTone(r * 4 * m, t, 2.6, 'triangle', 0.035, 1500)); }
    if (I > 0.12 && st % 4 === 0) { this.mTone(120, t, 0.18, 'sine', 0.55 * Math.min(1, I * 1.6), 160); this.ctx && (() => { const o = this.ctx!.createOscillator(); void o; })(); }
    if (I > 0.4 && (st === 4 || st === 12)) this.mNoise(t, 0.16, 1800, 0.14 * I);
    if (I > 0.3 && st % 2 === 0) this.mNoise(t, 0.04, 7000, 0.05 * I);
    if (I > 0.7 && st % 2 === 1) this.mNoise(t, 0.03, 8000, 0.03 * I);
    if (I > 0.15 && [0, 3, 6, 8, 11, 14].includes(st)) this.mTone(r * (st === 6 || st === 14 ? 1.498 : 1) * 2, t, 0.22, 'sawtooth', 0.09 * Math.min(1, I * 1.5), 700 + I * 900);
    if (I > 0.45 && st % 2 === 0) { const sc = [1, 1.189, 1.335, 1.498, 1.782, 2]; this.mTone(r * 8 * sc[(s * 3 + bar) % 6], t, 0.14, 'square', 0.03 * I, 2200); }
  }
  dispose() { if (this.musicTimer) clearInterval(this.musicTimer); this.ctx?.close(); }
}
