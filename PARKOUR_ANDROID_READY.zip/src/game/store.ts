import { useSyncExternalStore } from 'react';

export type Action = 'forward' | 'back' | 'left' | 'right' | 'sprint' | 'jump' | 'crouch' | 'interact' | 'dash' | 'respawn';
export const ACTIONS: Action[] = ['forward', 'back', 'left', 'right', 'sprint', 'jump', 'crouch', 'interact', 'dash', 'respawn'];
export const ACTION_LABEL: Record<Action, string> = {
  forward: 'Frente', back: 'Trás', left: 'Esquerda', right: 'Direita', sprint: 'Correr', jump: 'Pular',
  crouch: 'Agachar / Slide', interact: 'Interagir', dash: 'Impulso', respawn: 'Voltar ao checkpoint',
};
export const DEFAULT_KEYS: Record<Action, string> = {
  forward: 'KeyW', back: 'KeyS', left: 'KeyA', right: 'KeyD', sprint: 'ShiftLeft', jump: 'Space',
  crouch: 'ControlLeft', interact: 'KeyE', dash: 'KeyQ', respawn: 'KeyR',
};

export type Quality = 'low' | 'medium' | 'high' | 'ultra';
export type Weather = 'day' | 'sunset' | 'night' | 'rain' | 'fog';

export interface Settings {
  master: number; music: number; sfx: number; sens: number; fov: number;
  quality: Quality; resolution: string; fullscreen: boolean; viewDist: number;
  shadows: boolean; fpsLimit: number; lang: 'pt' | 'en'; weather: Weather;
  minimap: boolean; ghost: boolean; invertY: boolean; keys: Record<Action, string>;
}

export interface Stats {
  distance: number; jumps: number; wallruns: number; walljumps: number; vaults: number; slides: number;
  climbs: number; rolls: number; swings: number; perfect: number; deaths: number; playTime: number;
  bestCombo: number; bestSpeed: number; totalScore: number; coins: number; dashes: number;
}
export interface Cosmetics { outfit: string; color: string; gloves: string; shoes: string; acc: string; fx: string; }
export interface MedalRec { medal: number; time: number; score: number }
export interface RankRec { time: number; score: number; date: number }
export interface Save {
  xp: number; medals: Record<string, MedalRec>; ranking: Record<string, RankRec[]>;
  coins: number[]; secrets: string[]; checkpoint: { pos: [number, number, number]; yaw: number; id: number } | null;
  stats: Stats; cosmetics: Cosmetics; finalDone: boolean; freeRoam: boolean; seenLevel: number;
}

const defaultSettings = (): Settings => ({
  master: 0.8, music: 0.5, sfx: 0.8, sens: 0.5, fov: 80, quality: 'high', resolution: 'auto', fullscreen: false,
  viewDist: 0.75, shadows: true, fpsLimit: 0, lang: 'pt', weather: 'sunset', minimap: true, ghost: true,
  invertY: false, keys: { ...DEFAULT_KEYS },
});
const defaultSave = (): Save => ({
  xp: 0, medals: {}, ranking: {}, coins: [], secrets: [], checkpoint: null, finalDone: false, freeRoam: false, seenLevel: 1,
  stats: {
    distance: 0, jumps: 0, wallruns: 0, walljumps: 0, vaults: 0, slides: 0, climbs: 0, rolls: 0, swings: 0, perfect: 0,
    deaths: 0, playTime: 0, bestCombo: 0, bestSpeed: 0, totalScore: 0, coins: 0, dashes: 0,
  },
  cosmetics: { outfit: 'o1', color: 'c1', gloves: 'g1', shoes: 's1', acc: 'a1', fx: 'f1' },
});

function load<T>(key: string, def: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return def;
    const p = JSON.parse(raw);
    return { ...def, ...p, ...(('keys' in (def as object)) ? { keys: { ...(def as any).keys, ...(p.keys || {}) } } : {}),
      ...(('stats' in (def as object)) ? { stats: { ...(def as any).stats, ...(p.stats || {}) }, cosmetics: { ...(def as any).cosmetics, ...(p.cosmetics || {}) } } : {}) };
  } catch { return def; }
}

export interface State { settings: Settings; save: Save; v: number }
let state: State = { settings: load('pk_settings_v1', defaultSettings()), save: load('pk_save_v1', defaultSave()), v: 0 };
const subs = new Set<() => void>();
let persistTimer: number | null = null;

export function persist(now = false) {
  const doIt = () => {
    persistTimer = null;
    try {
      localStorage.setItem('pk_settings_v1', JSON.stringify(state.settings));
      localStorage.setItem('pk_save_v1', JSON.stringify(state.save));
    } catch { /* ignore quota */ }
  };
  if (now) { doIt(); return; }
  if (persistTimer == null) persistTimer = window.setTimeout(doIt, 800);
}
export function getState() { return state; }
export function notify() { state = { ...state, v: state.v + 1 }; subs.forEach((s) => s()); persist(); }
export function setSettings(p: Partial<Settings>) { state.settings = { ...state.settings, ...p }; notify(); settingsListeners.forEach((l) => l(state.settings)); }
export function mutateSave(fn: (s: Save) => void, silent = false) { fn(state.save); if (silent) persist(); else notify(); }
export function resetSave() { state.save = defaultSave(); notify(); }
const settingsListeners = new Set<(s: Settings) => void>();
export function onSettings(cb: (s: Settings) => void) { settingsListeners.add(cb); return () => { settingsListeners.delete(cb); }; }
export function useStore(): State {
  return useSyncExternalStore((cb) => { subs.add(cb); return () => { subs.delete(cb); }; }, () => state);
}

// ---------- Progressão ----------
export const LEVEL_XP = [0, 0, 200, 500, 900, 1400, 2000, 2700, 3500, 4400, 5400];
export const MAX_LEVEL = 10;
export function levelFor(xp: number) { let l = 1; for (let i = 2; i <= MAX_LEVEL; i++) if (xp >= LEVEL_XP[i]) l = i; return l; }
export function levelProgress(xp: number) {
  const l = levelFor(xp); if (l >= MAX_LEVEL) return { level: l, cur: 1, need: 1, pct: 1 };
  const a = LEVEL_XP[l], b = LEVEL_XP[l + 1];
  return { level: l, cur: xp - a, need: b - a, pct: (xp - a) / (b - a) };
}
export const UNLOCK_TEXT: Record<number, string> = {
  2: 'Região: Zona Industrial · Roupas: Jaqueta Carmim, Moletom Branco · Cor Vermelha · +Fôlego',
  3: 'Região: Canteiro de Obras · Wall run mais longo · Efeito Neon · Óculos',
  4: 'Impulso aéreo (Q) desbloqueado · Roupa Amarela · Boné',
  5: 'Salto mais forte · Efeito Fogo · Roupa Verde Militar',
  6: 'Região: Centro Financeiro · Mais fôlego · Tênis neon',
  7: 'Wall run ainda mais longo · Roupa Roxa Neon',
  8: 'Região: Torre Central · Efeito Fantasma · Slide turbinado',
  9: 'Modo Mestre: aderência perfeita nas paredes',
  10: 'Lenda da Cidade: todos os itens liberados',
};
export function perks(level: number) {
  return {
    wallRunTime: 1.5 + (level >= 3 ? 0.6 : 0) + (level >= 7 ? 0.6 : 0),
    dash: level >= 4,
    jump: 9.0 + (level >= 5 ? 0.6 : 0),
    stamina: 100 + (level >= 2 ? 20 : 0) + (level >= 6 ? 30 : 0),
    slideBoost: level >= 8 ? 1.25 : 1,
  };
}

// ---------- Cosméticos ----------
export interface Item { id: string; name: string; lvl: number; color: number; color2?: number }
export const OUTFITS: Item[] = [
  { id: 'o1', name: 'Moletom Noturno', lvl: 1, color: 0x16181d }, { id: 'o2', name: 'Capuz Grafite', lvl: 1, color: 0x42464f },
  { id: 'o3', name: 'Jaqueta Carmim', lvl: 2, color: 0x8a1c1c }, { id: 'o4', name: 'Moletom Branco', lvl: 2, color: 0xd6d9de },
  { id: 'o5', name: 'Azul Urbano', lvl: 3, color: 0x1f56b8 }, { id: 'o6', name: 'Amarelo Táxi', lvl: 4, color: 0xe0b020 },
  { id: 'o7', name: 'Verde Militar', lvl: 5, color: 0x4a5a35 }, { id: 'o8', name: 'Roxo Neon', lvl: 7, color: 0x6a2fc0 },
];
export const COLORS: Item[] = [
  { id: 'c1', name: 'Branco', lvl: 1, color: 0xf2f2f2 }, { id: 'c2', name: 'Amarelo', lvl: 1, color: 0xffc400 },
  { id: 'c3', name: 'Vermelho', lvl: 2, color: 0xe02020 }, { id: 'c4', name: 'Ciano', lvl: 3, color: 0x20d0ff },
  { id: 'c5', name: 'Verde Lima', lvl: 4, color: 0x7cff3a }, { id: 'c6', name: 'Rosa', lvl: 5, color: 0xff3fa4 },
  { id: 'c7', name: 'Laranja', lvl: 6, color: 0xff7a1a }, { id: 'c8', name: 'Violeta', lvl: 8, color: 0xa65cff },
];
export const GLOVES: Item[] = [
  { id: 'g1', name: 'Pretas sem dedos', lvl: 1, color: 0x101010 }, { id: 'g2', name: 'Brancas', lvl: 2, color: 0xe8e8e8 },
  { id: 'g3', name: 'Amarelas', lvl: 3, color: 0xe0b020 }, { id: 'g4', name: 'Vermelhas', lvl: 5, color: 0xb02020 },
  { id: 'g5', name: 'Camufladas', lvl: 6, color: 0x55663a },
];
export const SHOES: Item[] = [
  { id: 's1', name: 'Branco Clássico', lvl: 1, color: 0xf0f0f0 }, { id: 's2', name: 'Preto Total', lvl: 1, color: 0x15151a },
  { id: 's3', name: 'Vermelho Sprint', lvl: 3, color: 0xd02a2a }, { id: 's4', name: 'Neon Verde', lvl: 6, color: 0x6dff3a },
  { id: 's5', name: 'Dourado', lvl: 9, color: 0xe6b422 },
];
export const ACCS: Item[] = [
  { id: 'a1', name: 'Nenhum', lvl: 1, color: 0 }, { id: 'a2', name: 'Máscara', lvl: 1, color: 0x111111 },
  { id: 'a3', name: 'Mochila', lvl: 2, color: 0x222831 }, { id: 'a4', name: 'Óculos', lvl: 3, color: 0x00e5ff },
  { id: 'a5', name: 'Boné', lvl: 4, color: 0x222222 }, { id: 'a6', name: 'Faixa', lvl: 5, color: 0xff2a2a },
];
export const FX: Item[] = [
  { id: 'f1', name: 'Poeira', lvl: 1, color: 0xb8a58c }, { id: 'f2', name: 'Neon', lvl: 3, color: 0x00e5ff, color2: 0xff2bd6 },
  { id: 'f3', name: 'Fogo', lvl: 5, color: 0xff7a1a, color2: 0xffd23a }, { id: 'f4', name: 'Fantasma', lvl: 8, color: 0x7fb0ff, color2: 0xffffff },
];
export const find = (list: Item[], id: string) => list.find((i) => i.id === id) || list[0];

// ---------- Idioma ----------
const EN: Record<string, string> = {
  'JOGAR': 'PLAY', 'DESAFIOS': 'CHALLENGES', 'MAPA': 'MAP', 'PERSONALIZAÇÃO': 'CUSTOMIZE', 'CONFIGURAÇÕES': 'SETTINGS', 'SAIR': 'EXIT',
  'VOLTAR': 'BACK', 'APLICAR': 'APPLY', 'CONTINUAR': 'CONTINUE', 'MENU PRINCIPAL': 'MAIN MENU', 'DOMINE A CIDADE!': 'OWN THE CITY!',
  'ROUPA': 'OUTFIT', 'ACESSÓRIOS': 'ACCESSORIES', 'CALÇADOS': 'SHOES', 'EFEITOS': 'EFFECTS', 'LUVAS': 'GLOVES', 'COR': 'COLOR',
  'JOGABILIDADE': 'GAMEPLAY', 'ÁUDIO': 'AUDIO', 'VÍDEO': 'VIDEO', 'CONTROLES': 'CONTROLS', 'IDIOMA': 'LANGUAGE',
  'Sensibilidade do Mouse': 'Mouse Sensitivity', 'Qualidade Gráfica': 'Graphics Quality', 'Resolução': 'Resolution',
  'Modo de Tela': 'Screen Mode', 'Distância de Visão': 'View Distance', 'Sombras': 'Shadows', 'Limite de FPS': 'FPS Limit',
  'Volume Geral': 'Master Volume', 'Música': 'Music', 'Efeitos Sonoros': 'Sound Effects', 'Clima': 'Weather',
  'Campo de Visão': 'Field of View', 'Minimapa': 'Minimap', 'Fantasma da melhor corrida': 'Best-run ghost', 'Inverter Y': 'Invert Y',
  'Janela': 'Windowed', 'Tela Cheia': 'Fullscreen', 'Baixa': 'Low', 'Média': 'Medium', 'Alta': 'High', 'Ultra': 'Ultra',
  'Ativadas': 'On', 'Desativadas': 'Off', 'Ilimitado': 'Unlimited', 'Dia': 'Day', 'Pôr do sol': 'Sunset', 'Noite': 'Night', 'Chuva': 'Rain', 'Neblina': 'Fog',
  'Movimentação': 'Movement', 'Correr': 'Sprint', 'Pular': 'Jump', 'Agachar / Slide': 'Crouch / Slide', 'Câmera': 'Camera', 'Interação': 'Interact', 'Menu': 'Menu',
  'Frente': 'Forward', 'Trás': 'Back', 'Esquerda': 'Left', 'Direita': 'Right', 'Interagir': 'Interact', 'Impulso': 'Dash', 'Voltar ao checkpoint': 'Back to checkpoint',
  'Restaurar padrão': 'Restore defaults', 'Clique e pressione uma tecla…': 'Click and press a key…',
  'INICIAR DESAFIO': 'START CHALLENGE', 'Bloqueado': 'Locked', 'Nível': 'Level', 'PARKOUR CONCLUÍDO!': 'PARKOUR COMPLETE!',
  'Tempo Final': 'Final Time', 'Pontuação': 'Score', 'Ranking': 'Rank', 'MODO LIVRE': 'FREE ROAM', 'PAUSADO': 'PAUSED',
  'REINICIAR CHECKPOINT': 'RESTART AT CHECKPOINT', 'ABANDONAR DESAFIO': 'QUIT CHALLENGE', 'ESTATÍSTICAS': 'STATISTICS',
  'Distância': 'Distance', 'Saltos': 'Jumps', 'Wall runs': 'Wall runs', 'Vaults': 'Vaults', 'Slides': 'Slides', 'Rolamentos': 'Rolls',
  'Quedas fatais': 'Deaths', 'Tempo de jogo': 'Play time', 'Melhor combo': 'Best combo', 'Velocidade máx.': 'Top speed', 'Moedas': 'Coins',
  'Apagar progresso': 'Erase progress', 'Região': 'Region', 'Medalhas': 'Medals', 'Melhores tempos': 'Best times',
  'Clique para jogar': 'Click to play', 'Controles': 'Controls', 'Desafios': 'Challenges',
};
export function t(s: string): string { return state.settings.lang === 'en' ? (EN[s] ?? s) : s; }

export function fmtTime(sec: number) {
  if (!isFinite(sec)) return '--:--.--';
  const m = Math.floor(sec / 60), s = sec - m * 60;
  return `${String(m).padStart(2, '0')}:${s.toFixed(2).padStart(5, '0')}`;
}
export function keyLabel(code: string) {
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  const m: Record<string, string> = { Space: 'ESPAÇO', ShiftLeft: 'SHIFT', ShiftRight: 'SHIFT', ControlLeft: 'CTRL', ControlRight: 'CTRL', AltLeft: 'ALT', Tab: 'TAB', Escape: 'ESC', Mouse0: 'MOUSE 1', Mouse1: 'MOUSE 3', Mouse2: 'MOUSE 2' };
  return m[code] || code.toUpperCase();
}
