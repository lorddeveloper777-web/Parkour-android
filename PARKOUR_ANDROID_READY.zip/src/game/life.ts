import * as THREE from 'three';
import { World } from './world';
import { solidAt } from './physics';
import { U } from './materials';

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3(), _e = new THREE.Euler(), _c = new THREE.Color();
const YAXIS = new THREE.Vector3(0, 1, 0);

interface Car { axis: 0 | 1; k: number; d: number; dir: 1 | -1; t: number; speed: number; y: number; color: number; active: boolean; lo: number; hi: number; x: number; z: number }
export class Traffic {
  group = new THREE.Group(); cars: Car[] = []; bodies: THREE.InstancedMesh; cabins: THREE.InstancedMesh; lights: THREE.InstancedMesh; cd = 0;
  constructor(private world: World, paint: THREE.Material, glass: THREE.Material, glow: THREE.Material) {
    const cols = [0xc0392b, 0x2c5aa0, 0xe0e0e0, 0x1a1a1e, 0xd4a017, 0x3a7d44, 0x8a8f96, 0xe67e22, 0xf1c40f];
    for (const s of world.streets) {
      const n = s.y > 0 ? 5 : 3; const lo = s.y > 0 ? -216 : -250, hi = s.y > 0 ? 216 : 250;
      for (let i = 0; i < n; i++) {
        const dir = (i % 2 ? 1 : -1) as 1 | -1;
        this.cars.push({ axis: s.axis, k: s.k, d: dir * (s.y > 0 ? 2.8 : 2.6), dir, t: lo + Math.random() * (hi - lo), speed: 8 + Math.random() * 9, y: s.y, color: cols[Math.floor(Math.random() * cols.length)], active: true, lo, hi, x: 0, z: 0 });
      }
    }
    const n = this.cars.length;
    this.bodies = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), paint, n); this.cabins = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), glass, n);
    this.lights = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), glow, n * 2);
    for (const m of [this.bodies, this.cabins, this.lights]) { m.frustumCulled = false; m.castShadow = m !== this.lights; this.group.add(m); }
    this.cars.forEach((c, i) => { _c.setHex(c.color); this.bodies.setColorAt(i, _c); _c.setHex(0x151a22); this.cabins.setColorAt(i, _c); _c.setHex(0xfff0c0); this.lights.setColorAt(i * 2, _c); this.lights.setColorAt(i * 2 + 1, _c); });
    this.update(0, new THREE.Vector3(0, 999, 0));
  }
  update(dt: number, pl: THREE.Vector3, out?: THREE.Vector3[]): { dx: number; dz: number } | null {
    let hit: { dx: number; dz: number } | null = null; this.cd = Math.max(0, this.cd - dt); const near: { d: number; p: THREE.Vector3 }[] = [];
    for (let i = 0; i < this.cars.length; i++) {
      const c = this.cars[i];
      if (c.active) {
        c.t += c.dir * c.speed * dt; if (c.t > c.hi) c.t = c.lo; if (c.t < c.lo) c.t = c.hi;
        const px = c.axis === 0 ? c.k * 64 + c.d : c.t, pz = c.axis === 0 ? c.t : c.k * 64 + c.d; c.x = px; c.z = pz;
        const ax = c.axis === 0 ? 0 : c.dir, az = c.axis === 0 ? c.dir : 0;
        if (solidAt(this.world.grid, px + ax * 3.4, c.y + 0.8, pz + az * 3.4)) { // bloqueado: reaparece mais longe
          for (let tr = 0; tr < 8; tr++) { const nt = c.lo + Math.random() * (c.hi - c.lo); const nx = c.axis === 0 ? px : nt, nz = c.axis === 0 ? nt : pz; if (!solidAt(this.world.grid, nx, c.y + 0.8, nz) && Math.hypot(nx - pl.x, nz - pl.z) > 80) { c.t = nt; break; } }
        }
        const dx = px - pl.x, dz = pz - pl.z, dd = Math.hypot(dx, dz);
        if (dd < 120) near.push({ d: dd, p: new THREE.Vector3(px, c.y + 1, pz) });
        const hx = c.axis === 0 ? 1.3 : 2.6, hz = c.axis === 0 ? 2.6 : 1.3;
        if (this.cd <= 0 && Math.abs(dx) < hx && Math.abs(dz) < hz && pl.y < c.y + 1.5 && pl.y > c.y - 1.2) { hit = { dx: ax || (dx > 0 ? -1 : 1), dz: az || (dz > 0 ? -1 : 1) }; this.cd = 1.2; }
      }
      const sx = c.axis === 0 ? 1.8 : 4.3, sz = c.axis === 0 ? 4.3 : 1.8, s = c.active ? 1 : 0;
      _m.compose(_p.set(c.x, c.y + 0.65, c.z), _q.identity(), _s.set(sx * s, 0.75 * s, sz * s)); this.bodies.setMatrixAt(i, _m);
      _m.compose(_p.set(c.x, c.y + 1.2, c.z), _q.identity(), _s.set((c.axis === 0 ? 1.6 : 2.3) * s, 0.55 * s, (c.axis === 0 ? 2.3 : 1.6) * s)); this.cabins.setMatrixAt(i, _m);
      for (const sd of [-1, 1]) {
        const fx = c.axis === 0 ? c.x + sd * 0.65 : c.x + c.dir * 2.15, fz = c.axis === 0 ? c.z + c.dir * 2.15 : c.z + sd * 0.65;
        _m.compose(_p.set(fx, c.y + 0.75, fz), _q.identity(), _s.set((c.axis === 0 ? 0.3 : 0.1) * s, 0.2 * s, (c.axis === 0 ? 0.1 : 0.3) * s)); this.lights.setMatrixAt(i * 2 + (sd > 0 ? 1 : 0), _m);
      }
    }
    this.bodies.instanceMatrix.needsUpdate = this.cabins.instanceMatrix.needsUpdate = this.lights.instanceMatrix.needsUpdate = true;
    if (out) { near.sort((a, b) => a.d - b.d); out.length = 0; near.slice(0, 3).forEach((n) => out.push(n.p)); }
    return hit;
  }
}

export class Npcs {
  group = new THREE.Group(); torso: THREE.InstancedMesh; head: THREE.InstancedMesh; legs!: THREE.InstancedMesh;
  n = 0; list: { x: number; z: number; y: number; yaw: number; sp: number; ph: number; axis: number; k: number; lo: number; hi: number; dir: number; walk: boolean; col: number }[] = [];
  constructor(world: World) {
    const cols = [0x8a2b2b, 0x2b4a8a, 0x3a3a3a, 0xc9a227, 0x2f6b4f, 0x6a4a8a, 0xd0d0d0];
    for (let i = 0; i < 26; i++) {
      const line = world.streets.filter((s) => s.y === 0)[Math.floor(Math.random() * 14)]; const side = Math.random() < 0.5 ? -1 : 1;
      this.list.push({ x: 0, z: 0, y: 0, yaw: 0, sp: 1.2 + Math.random() * 0.6, ph: Math.random() * 6, axis: line.axis, k: line.k, lo: -240, hi: 240, dir: Math.random() < 0.5 ? -1 : 1, walk: true, col: cols[i % cols.length] });
      const n = this.list[i]; n.x = side * 7.7; n.z = -240 + Math.random() * 480; n.y = side; // y guarda o lado
    }
    for (let i = 0; i < 14; i++) { // nos telhados
      const p = world.route[Math.floor(Math.random() * Math.min(120, world.route.length))];
      this.list.push({ x: p.x + (Math.random() - 0.5) * (p.hx - 2), z: p.z + (Math.random() - 0.5) * (p.hz - 2), y: p.y, yaw: Math.random() * 6.28, sp: 0, ph: Math.random() * 6, axis: 0, k: 0, lo: 0, hi: 0, dir: 1, walk: false, col: cols[(i + 3) % cols.length] });
    }
    this.n = this.list.length;
    const mk = (g: THREE.BufferGeometry, color: number | null) => { const m = new THREE.InstancedMesh(g, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8 }), this.n); m.frustumCulled = false; m.castShadow = true; this.group.add(m); void color; return m; };
    this.torso = mk(new THREE.BoxGeometry(0.4, 0.6, 0.22), null); this.head = mk(new THREE.SphereGeometry(0.12, 8, 6), null);
    this.legs = new THREE.InstancedMesh(new THREE.BoxGeometry(0.16, 0.8, 0.18), new THREE.MeshStandardMaterial({ color: 0x222831, roughness: 0.9 }), this.n * 2); this.legs.frustumCulled = false; this.legs.castShadow = true; this.group.add(this.legs);
    this.list.forEach((n, i) => { _c.setHex(n.col); this.torso.setColorAt(i, _c); _c.setHex(0xc79a74); this.head.setColorAt(i, _c); });
  }
  update(dt: number, t: number, pl: THREE.Vector3) {
    const M = new THREE.Matrix4(), L = new THREE.Matrix4();
    for (let i = 0; i < this.n; i++) {
      const n = this.list[i]; let x = n.x, z = n.z, y = n.y;
      if (n.walk) {
        const side = n.y; n.z += n.dir * n.sp * dt; if (n.z > n.hi || n.z < n.lo) n.dir = -n.dir as 1 | -1;
        const al = n.z; x = n.axis === 0 ? n.k * 64 + side * 7.7 : al; z = n.axis === 0 ? al : n.k * 64 + side * 7.7; y = 0;
        n.yaw = n.axis === 0 ? (n.dir > 0 ? 0 : Math.PI) : (n.dir > 0 ? Math.PI / 2 : -Math.PI / 2);
        if (n.axis === 1) { n.yaw = n.dir > 0 ? -Math.PI / 2 : Math.PI / 2; }
      }
      const far = Math.hypot(x - pl.x, z - pl.z) > 140 ? 0 : 1; const sw = n.walk ? Math.sin(t * 5 * n.sp + n.ph) * 0.6 : 0, bob = n.walk ? Math.abs(Math.sin(t * 5 * n.sp + n.ph)) * 0.03 : Math.sin(t + n.ph) * 0.005;
      _q.setFromAxisAngle(YAXIS, n.yaw); M.compose(_p.set(x, y, z), _q, _s.set(far, far, far));
      L.makeTranslation(0, 1.15 + bob, 0); this.torso.setMatrixAt(i, _m.multiplyMatrices(M, L));
      L.makeTranslation(0, 1.64 + bob, 0); this.head.setMatrixAt(i, _m.multiplyMatrices(M, L));
      for (let s = 0; s < 2; s++) { const a = s ? sw : -sw; L.makeTranslation(s ? 0.1 : -0.1, 0.84, 0).multiply(new THREE.Matrix4().makeRotationX(a)).multiply(new THREE.Matrix4().makeTranslation(0, -0.4, 0)); this.legs.setMatrixAt(i * 2 + s, _m.multiplyMatrices(M, L)); }
    }
    this.torso.instanceMatrix.needsUpdate = this.head.instanceMatrix.needsUpdate = this.legs.instanceMatrix.needsUpdate = true; void _e;
  }
}

export class Heli {
  group = new THREE.Group(); rotor = new THREE.Group(); tail = new THREE.Mesh(); pos = new THREE.Vector3(); blink: THREE.Mesh;
  constructor() {
    const body = new THREE.MeshStandardMaterial({ color: 0x1b1f26, roughness: 0.5, metalness: 0.6 });
    const b = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 8), body); b.scale.set(1.2, 1.1, 2.4); this.group.add(b);
    const boom = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 4.5), body); boom.position.set(0, 0.3, 4.5); this.group.add(boom);
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.2, 0.8), body); fin.position.set(0, 0.9, 6.5); this.group.add(fin);
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.8), body); mast.position.y = 1.4; this.group.add(mast);
    for (let i = 0; i < 2; i++) { const bl = new THREE.Mesh(new THREE.BoxGeometry(11, 0.04, 0.35), body); bl.rotation.y = i * Math.PI / 2; this.rotor.add(bl); }
    this.rotor.position.y = 1.85; this.group.add(this.rotor);
    this.blink = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 4), new THREE.MeshBasicMaterial({ color: 0xff2020, toneMapped: false })); this.blink.position.set(0, -1, 0); this.group.add(this.blink);
    const sp = new THREE.Mesh(new THREE.SphereGeometry(0.22, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false })); sp.position.set(0, -0.9, -2.2); this.group.add(sp);
    this.group.scale.setScalar(1.6);
  }
  update(t: number) {
    const a = t * 0.06; this.pos.set(Math.cos(a) * 190, 130 + Math.sin(t * 0.2) * 8, Math.sin(a) * 190);
    this.group.position.copy(this.pos); this.group.rotation.y = -a + Math.PI; this.group.rotation.z = 0.12; this.rotor.rotation.y = t * 40;
    (this.blink.material as THREE.MeshBasicMaterial).color.setScalar(Math.sin(t * 5) > 0 ? 3 : 0.1);
  }
}

// ============================ coletáveis e marcadores ============================
export interface PickupEvent { kind: 'coin' | 'orb' | 'secret'; id: number; sid?: string }
export class Pickups {
  group = new THREE.Group();
  coins: THREE.InstancedMesh; orbs: THREE.InstancedMesh; stars: THREE.InstancedMesh; cpMesh: THREE.InstancedMesh; beacons: THREE.InstancedMesh;
  coinGot: boolean[] = []; orbPos: THREE.Vector3[] = []; orbGot: boolean[] = []; starGot: boolean[] = []; cpActive: number = -1;
  ring: THREE.Mesh; beam: THREE.Mesh; ring2: THREE.Mesh; ringGroup = new THREE.Group();
  constructor(private world: World, collected: number[], secrets: string[]) {
    const spinMat = (color: number, emissive: number, amp = 0.12) => {
      const m = new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: 1.2, roughness: 0.3, metalness: 0.8 });
      m.onBeforeCompile = (sh) => {
        sh.uniforms.uTime = U.uTime;
        sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;').replace('#include <begin_vertex>', `#include <begin_vertex>
          float ang = uTime*2.5 + instanceMatrix[3].x*0.7 + instanceMatrix[3].z*0.3; float ca = cos(ang), sa = sin(ang);
          transformed = vec3(ca*transformed.x + sa*transformed.z, transformed.y + sin(uTime*2.0 + instanceMatrix[3].z)*${amp.toFixed(2)}, -sa*transformed.x + ca*transformed.z);`);
      };
      return m;
    };
    const wc = world.coins.length;
    this.coins = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.42, 0.42, 0.09, 18).rotateX(Math.PI / 2), spinMat(0xffc400, 0xff9a00), wc);
    world.coins.forEach((c, i) => { this.coinGot[i] = collected.includes(c.id); this.setM(this.coins, i, c.x, c.y, c.z, this.coinGot[i] ? 0 : 1); });
    this.orbs = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(0.5, 1), spinMat(0x20d0ff, 0x00a0ff, 0.2), 40);
    for (let i = 0; i < 40; i++) this.setM(this.orbs, i, 0, -999, 0, 0);
    this.stars = new THREE.InstancedMesh(new THREE.OctahedronGeometry(0.8, 0), spinMat(0xd09cff, 0xa040ff, 0.25), Math.max(1, world.secrets.length));
    world.secrets.forEach((s, i) => { this.starGot[i] = secrets.includes(s.id); this.setM(this.stars, i, s.x, s.y, s.z, this.starGot[i] ? 0 : 1); });
    const cpMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    this.cpMesh = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.5, 0.5, 1, 12, 1, true), cpMat, Math.max(1, world.cps.length));
    world.cps.forEach((c, i) => { _m.compose(_p.set(c.x, c.y + 3, c.z), _q.identity(), _s.set(1.6, 6, 1.6)); this.cpMesh.setMatrixAt(i, _m); _c.setHex(0x9ad8ff); this.cpMesh.setColorAt(i, _c); });
    this.beacons = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.5, 0.5, 1, 12, 1, true), cpMat.clone(), 24); (this.beacons.material as THREE.MeshBasicMaterial).opacity = 0.45;
    for (let i = 0; i < 24; i++) this.setM(this.beacons, i, 0, -999, 0, 0);
    for (const m of [this.coins, this.orbs, this.stars, this.cpMesh, this.beacons]) { m.frustumCulled = false; this.group.add(m); }
    const rm = new THREE.MeshBasicMaterial({ color: 0xffd400, transparent: true, opacity: 0.9, toneMapped: false, depthWrite: false });
    this.ring = new THREE.Mesh(new THREE.TorusGeometry(3, 0.16, 8, 40), rm); this.ring2 = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.08, 8, 32), rm);
    this.beam = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 60, 20, 1, true), new THREE.MeshBasicMaterial({ color: 0xffd400, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    this.beam.position.y = 30; this.ring.position.y = 1.6; this.ring2.position.y = 1.6; this.ringGroup.add(this.ring, this.ring2, this.beam); this.ringGroup.visible = false; this.group.add(this.ringGroup);
  }
  private setM(m: THREE.InstancedMesh, i: number, x: number, y: number, z: number, s: number) { _m.compose(_p.set(x, y, z), _q.identity(), _s.set(s, s, s)); m.setMatrixAt(i, _m); m.instanceMatrix.needsUpdate = true; }
  setActiveCp(i: number) {
    this.cpActive = i; this.world.cps.forEach((_c2, j) => { _c.setHex(j <= i ? 0x6dff8a : 0x9ad8ff); this.cpMesh.setColorAt(j, _c); }); if (this.cpMesh.instanceColor) this.cpMesh.instanceColor.needsUpdate = true;
  }
  setBeacons(list: { x: number; y: number; z: number; color: number }[]) {
    for (let i = 0; i < 24; i++) { const b = list[i]; if (b) { _m.compose(_p.set(b.x, b.y + 4, b.z), _q.identity(), _s.set(1.4, 8, 1.4)); this.beacons.setMatrixAt(i, _m); _c.setHex(b.color); this.beacons.setColorAt(i, _c); } else this.setM(this.beacons, i, 0, -999, 0, 0); }
    this.beacons.instanceMatrix.needsUpdate = true; if (this.beacons.instanceColor) this.beacons.instanceColor.needsUpdate = true;
  }
  setOrbs(pts: THREE.Vector3[]) {
    this.orbPos = pts; this.orbGot = pts.map(() => false);
    for (let i = 0; i < 40; i++) { const p = pts[i]; if (p) this.setM(this.orbs, i, p.x, p.y, p.z, 1); else this.setM(this.orbs, i, 0, -999, 0, 0); }
  }
  setTarget(p: THREE.Vector3 | null, color = 0xffd400, yaw = 0) {
    if (!p) { this.ringGroup.visible = false; return; }
    this.ringGroup.visible = true; this.ringGroup.position.copy(p); this.ringGroup.rotation.y = yaw;
    (this.ring.material as THREE.MeshBasicMaterial).color.setHex(color); (this.beam.material as THREE.MeshBasicMaterial).color.setHex(color);
  }
  update(t: number) { this.ring.rotation.z = t * 0.8; this.ring2.rotation.z = -t * 1.1; this.ring.scale.setScalar(1 + Math.sin(t * 3) * 0.04); }
  collect(pl: THREE.Vector3): PickupEvent[] {
    const out: PickupEvent[] = []; const r2 = 2.2 * 2.2; const cy = pl.y + 1.0;
    const w = this.world;
    for (let i = 0; i < w.coins.length; i++) {
      if (this.coinGot[i]) continue; const c = w.coins[i]; const dx = c.x - pl.x, dz = c.z - pl.z; if (dx * dx + dz * dz > r2) continue; const dy = c.y - cy; if (dx * dx + dz * dz + dy * dy < r2) { this.coinGot[i] = true; this.setM(this.coins, i, 0, -999, 0, 0); out.push({ kind: 'coin', id: c.id }); }
    }
    for (let i = 0; i < this.orbPos.length; i++) { if (this.orbGot[i]) continue; const o = this.orbPos[i]; if (o.distanceToSquared(_p.set(pl.x, cy, pl.z)) < 2.6 * 2.6) { this.orbGot[i] = true; this.setM(this.orbs, i, 0, -999, 0, 0); out.push({ kind: 'orb', id: i }); } }
    for (let i = 0; i < w.secrets.length; i++) { if (this.starGot[i]) continue; const s = w.secrets[i]; if (_p.set(s.x, s.y, s.z).distanceToSquared(_s.set(pl.x, cy, pl.z)) < 3 * 3) { this.starGot[i] = true; this.setM(this.stars, i, 0, -999, 0, 0); out.push({ kind: 'secret', id: i, sid: s.id }); } }
    return out;
  }
}
