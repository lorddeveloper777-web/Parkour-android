export interface Slope { axis: 0 | 1; dir: 1 | -1; lo: number; hi: number; slip: boolean }
export interface Collider {
  minX: number; maxX: number; minY: number; maxY: number; minZ: number; maxZ: number;
  surf: number; // 0 concreto, 1 metal, 2 madeira/macio, 3 grama
  slope?: Slope; stamp: number; solidWall: boolean;
}

export class ColliderGrid {
  cell = 12;
  map = new Map<number, Collider[]>();
  all: Collider[] = [];
  stamp = 1;
  private key(cx: number, cz: number) { return (cx + 512) * 1024 + (cz + 512); }
  add(c: Collider) {
    this.all.push(c);
    const x0 = Math.floor(c.minX / this.cell), x1 = Math.floor(c.maxX / this.cell);
    const z0 = Math.floor(c.minZ / this.cell), z1 = Math.floor(c.maxZ / this.cell);
    for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
      const k = this.key(x, z); let a = this.map.get(k);
      if (!a) { a = []; this.map.set(k, a); }
      a.push(c);
    }
  }
  query(x0: number, x1: number, z0: number, z1: number, out: Collider[]) {
    out.length = 0; this.stamp++;
    const cx0 = Math.floor(x0 / this.cell), cx1 = Math.floor(x1 / this.cell);
    const cz0 = Math.floor(z0 / this.cell), cz1 = Math.floor(z1 / this.cell);
    for (let x = cx0; x <= cx1; x++) for (let z = cz0; z <= cz1; z++) {
      const a = this.map.get(this.key(x, z)); if (!a) continue;
      for (let i = 0; i < a.length; i++) { const c = a[i]; if (c.stamp !== this.stamp) { c.stamp = this.stamp; out.push(c); } }
    }
  }
}

export function topAt(c: Collider, x: number, z: number): number {
  const s = c.slope; if (!s) return c.maxY;
  const u = s.axis === 0 ? x : z;
  const lo = s.axis === 0 ? c.minX : c.minZ, hi = s.axis === 0 ? c.maxX : c.maxZ;
  let t = (Math.min(hi, Math.max(lo, u)) - lo) / (hi - lo);
  if (s.dir < 0) t = 1 - t;
  return s.lo + (s.hi - s.lo) * t;
}
/** altura máxima sob a pegada do jogador */
export function topUnder(c: Collider, x: number, z: number, r: number): number {
  const s = c.slope; if (!s) return c.maxY;
  return s.axis === 0 ? topAt(c, x + s.dir * r, z) : topAt(c, x, z + s.dir * r);
}
export function slopeNormal(c: Collider, out: { x: number; y: number; z: number }) {
  const s = c.slope!;
  const len = (s.axis === 0 ? c.maxX - c.minX : c.maxZ - c.minZ);
  const k = (s.hi - s.lo) / len; // inclinação
  const n = 1 / Math.hypot(1, k);
  const a = -k * n * s.dir; // componente ao longo do eixo
  out.x = s.axis === 0 ? a : 0; out.z = s.axis === 1 ? a : 0; out.y = n;
  return k;
}

export const overlapXZ = (c: Collider, x: number, z: number, r: number) =>
  x + r > c.minX && x - r < c.maxX && z + r > c.minZ && z - r < c.maxZ;

export interface GroundHit { y: number; c: Collider | null }
const tmpList: Collider[] = [];
export function groundBelow(g: ColliderGrid, x: number, z: number, r: number, refY: number, out: GroundHit) {
  g.query(x - r, x + r, z - r, z + r, tmpList);
  let best = 0, bc: Collider | null = null;
  for (let i = 0; i < tmpList.length; i++) {
    const c = tmpList[i];
    if (!overlapXZ(c, x, z, r)) continue;
    const top = topUnder(c, x, z, r);
    if (top <= refY && top > best) { best = top; bc = c; }
  }
  out.y = best; out.c = bc; return out;
}

/** primeiro colisor que contém o ponto (para detectar paredes) */
export function solidAt(g: ColliderGrid, x: number, y: number, z: number, margin = 0): Collider | null {
  g.query(x - 0.1, x + 0.1, z - 0.1, z + 0.1, tmpList);
  for (let i = 0; i < tmpList.length; i++) {
    const c = tmpList[i];
    if (c.slope) continue;
    if (x >= c.minX - margin && x <= c.maxX + margin && z >= c.minZ - margin && z <= c.maxZ + margin && y >= c.minY && y <= c.maxY) return c;
  }
  return null;
}

/** existe algum colisor ocupando o volume? */
export function boxBlocked(g: ColliderGrid, x: number, z: number, r: number, y0: number, y1: number): boolean {
  g.query(x - r, x + r, z - r, z + r, tmpList);
  for (let i = 0; i < tmpList.length; i++) {
    const c = tmpList[i];
    if (!overlapXZ(c, x, z, r)) continue;
    const top = c.slope ? topUnder(c, x, z, r) : c.maxY;
    if (top > y0 && c.minY < y1) return true;
  }
  return false;
}
