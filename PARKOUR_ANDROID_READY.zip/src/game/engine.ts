import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { buildWorld, World, regionAt, REGION_NAMES } from './world';
import { Player, Input, PEvent } from './player';
import { Environment, Particles, Rain, Ambient } from './fx';
import { U } from './materials';
import { solidAt } from './physics';
import { Traffic, Npcs, Heli, Pickups } from './life';
import { Character, FPArms } from './character';
import { AudioSys } from './audio';
import { DEFS, MAIN_IDS, ChallengeRun, Resolved, resolveAll, ChallengeDef } from './challenges';
import { getState, mutateSave, setSettings, onSettings, levelFor, perks, UNLOCK_TEXT, find, FX, Settings, RankRec, Stats, persist, Action } from './store';

export type View = 'main' | 'custom' | 'map' | 'challenges' | 'settings' | 'none';
export type Mode = 'menu' | 'play' | 'pause' | 'result';
export interface ResultData { id: string; name: string; failed: boolean; reason: string; time: number; medal: number; score: number; xpGain: number; levelUp: number; newBest: boolean; ranking: RankRec[]; times: number[]; final: boolean; stats?: Stats; unlock?: string }
export interface Hud {
  speed: number; score: number; mult: number; chain: number; comboT: number; comboPts: number; region: string; stamina: number; staminaMax: number; time: number; limit: number; countdown: number;
  objective: string[]; ringText: string; challenge: string; prompt: string; level: number; xpPct: number; alert: boolean; freeRoam: boolean; hasDash: boolean; dashCd: number; fps: number; height: number; state: string; ctype: string; lastMove: string; locked: boolean;
}
const EMPTY_INPUT = (): Input => ({ f: 0, s: 0, sprint: false, crouch: false, jump: false, jumpP: false, crouchP: false, dashP: false });

export class Engine {
  canvas = document.createElement('canvas'); renderer: THREE.WebGLRenderer; scene = new THREE.Scene(); camera = new THREE.PerspectiveCamera(80, 1, 0.1, 1200);
  composer: EffectComposer | null = null; bloom: UnrealBloomPass | null = null;
  world: World; player: Player; env: Environment; particles = new Particles(); rain = new Rain(); ambient = new Ambient(); traffic: Traffic; npcs: Npcs; heli = new Heli(); pickups: Pickups;
  arms = new FPArms(); audio = new AudioSys(); resolved: Record<string, Resolved>; mapCanvas = document.createElement('canvas');
  menuChar: Character; previewChar: Character; rivalChar: Character; ghostChar: Character;
  mode: Mode = 'menu'; view: View = 'main'; run: ChallengeRun | null = null; time = 0; last = 0; lastRender = 0; fpsAcc = 0; fpsN = 0; fps = 60; raf = 0; mounted = false;
  keys = new Set<string>(); edges = { jump: false, crouch: false, dash: false, interact: false }; inp: Input = EMPTY_INPUT(); locked = false; noLock = false; lockWanted = false;
  touch = { f: 0, s: 0, sprint: false, crouch: false, lookX: 0, lookY: 0 };
  score = 0; chain = 0; comboT = 0; comboPts = 0; lastMove = ''; lastMoveT = 0; lastMoveName = ''; autoSaveT = 0; deadT = 0; hitCd = 0; prompt = ''; promptId = '';
  hud: Hud = { speed: 0, score: 0, mult: 1, chain: 0, comboT: 0, comboPts: 0, region: '', stamina: 100, staminaMax: 100, time: 0, limit: 0, countdown: 0, objective: [], ringText: '', challenge: '', prompt: '', level: 1, xpPct: 0, alert: false, freeRoam: false, hasDash: false, dashCd: 0, fps: 60, height: 0, state: 'ground', ctype: '', lastMove: '', locked: false };
  listeners: Record<string, Set<(d: any) => void>> = {};
  ghostData: number[] | null = null; recording: number[] = []; recT = 0; curCp = -1; menuT = 0; stage: any; camTarget = new THREE.Vector3(); camPosS = new THREE.Vector3(); camInit = false; chaserMesh: THREE.Mesh;
  rec: { x: number; y: number; z: number }[] = []; unsubSettings: () => void; resizeH = () => this.resize(); trafficPos: THREE.Vector3[] = []; heliPos = new THREE.Vector3(); sirenPos = new THREE.Vector3(150, 5, 0); staminaWarn = 0; pr = 1; q = { shadow: 2048, ext: 75, bloom: true, pr: 1.5 };

  constructor() {
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;outline:none';
    this.scene.add(this.camera); this.camera.rotation.order = 'YXZ';
    this.world = buildWorld(); this.scene.add(this.world.group);
    this.resolved = resolveAll(this.world);
    this.env = new Environment(this.scene, this.renderer);
    const st = getState(); this.env.apply(st.settings.weather, st.settings.viewDist, this.world);
    this.player = new Player(this.world.grid, this.world.bars); this.player.perks = perks(levelFor(st.save.xp));
    this.player.onEvent = (e, d) => this.onPlayerEvent(e, d);
    const mats = (this.world as any);
    void mats;
    this.traffic = new Traffic(this.world, new THREE.MeshStandardMaterial({ roughness: 0.3, metalness: 0.55 }), new THREE.MeshStandardMaterial({ roughness: 0.08, metalness: 0.85 }), this.world.glowMat);
    this.npcs = new Npcs(this.world);
    this.pickups = new Pickups(this.world, st.save.coins, st.save.secrets);
    this.scene.add(this.traffic.group, this.npcs.group, this.heli.group, this.pickups.group, this.particles.points, this.rain.lines, this.ambient.points);
    this.camera.add(this.arms.group); this.arms.group.visible = false;
    this.menuChar = new Character(st.save.cosmetics); this.previewChar = new Character(st.save.cosmetics); this.rivalChar = new Character({ outfit: 'o3', color: 'c3', gloves: 'g4', shoes: 's3', acc: 'a2', fx: 'f1' }); this.ghostChar = new Character(st.save.cosmetics);
    this.ghostify(this.ghostChar); this.rivalChar.root.visible = false; this.ghostChar.root.visible = false; this.previewChar.root.visible = false;
    this.scene.add(this.menuChar.root, this.previewChar.root, this.rivalChar.root, this.ghostChar.root);
    this.chaserMesh = new THREE.Mesh(new THREE.CylinderGeometry(7, 7, 120, 20, 1, true), new THREE.MeshBasicMaterial({ color: 0xff2020, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    this.chaserMesh.visible = false; this.scene.add(this.chaserMesh);
    this.setupStage(); this.buildMap(); this.applyCosmetics(); this.pickups.setActiveCp(-1); this.refreshBeacons();
    this.unsubSettings = onSettings((s) => this.applySettings(s));
    const cp = st.save.checkpoint; if (cp) { this.curCp = cp.id; this.pickups.setActiveCp(cp.id); }
    this.applySettings(st.settings);
  }

  // ---------------------------------------------------------------- infra
  on(name: string, cb: (d: any) => void) { (this.listeners[name] ||= new Set()).add(cb); return () => { this.listeners[name].delete(cb); }; }
  emit(name: string, d?: any) { this.listeners[name]?.forEach((c) => c(d)); }
  toast(text: string, kind = 'info', sub = '') { this.emit('toast', { text, kind, sub, id: Math.random() }); }
  mount(el: HTMLElement) {
    el.appendChild(this.canvas); this.resize(); window.addEventListener('resize', this.resizeH);
    window.addEventListener('keydown', this.onKeyDown); window.addEventListener('keyup', this.onKeyUp); window.addEventListener('mousemove', this.onMouse);
    document.addEventListener('pointerlockchange', this.onLockChange); document.addEventListener('pointerlockerror', this.onLockError); window.addEventListener('blur', this.onBlur);
    window.addEventListener('contextmenu', (e) => { if (this.mode === 'play') e.preventDefault(); });
    if (!this.mounted) { this.mounted = true; this.last = performance.now(); this.raf = requestAnimationFrame(this.loop); }
  }
  dispose() { cancelAnimationFrame(this.raf); window.removeEventListener('resize', this.resizeH); window.removeEventListener('keydown', this.onKeyDown); window.removeEventListener('keyup', this.onKeyUp); window.removeEventListener('mousemove', this.onMouse); this.unsubSettings(); this.audio.dispose(); this.renderer.dispose(); }
  resize() {
    const w = window.innerWidth, h = window.innerHeight, s = getState().settings; let pr = Math.min(window.devicePixelRatio || 1, this.q.pr);
    if (s.resolution !== 'auto') { const [tw] = s.resolution.split('x').map(Number); pr = Math.min(2, tw / w); }
    this.pr = pr; this.renderer.setPixelRatio(pr); this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.composer?.setPixelRatio(pr); this.composer?.setSize(w, h);
    const scale = (h * pr) / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2)); this.particles.mat.uniforms.uScale.value = scale; this.ambient.mat.uniforms.uScale.value = scale;
  }
  applySettings(s: Settings) {
    const Q: Record<string, { shadow: number; ext: number; bloom: boolean; pr: number; rain: number }> = {
      low: { shadow: 1024, ext: 45, bloom: false, pr: 0.8, rain: 1500 }, medium: { shadow: 1024, ext: 60, bloom: false, pr: 1, rain: 2500 },
      high: { shadow: 2048, ext: 75, bloom: true, pr: 1.5, rain: 3500 }, ultra: { shadow: 4096, ext: 90, bloom: true, pr: 2, rain: 3500 },
    };
    const q = Q[s.quality]; this.q = q;
    this.env.setShadowQuality(q.shadow, q.ext, s.shadows && s.quality !== 'low' || (s.shadows && s.quality === 'low'));
    this.env.apply(s.weather, s.viewDist, this.world); this.rain.lines.visible = this.env.preset.rain; this.rain.lines.geometry.setDrawRange(0, q.rain * 2);
    this.camera.far = 300 + s.viewDist * 1100; this.camera.fov = s.fov; this.camera.updateProjectionMatrix();
    if (q.bloom && !this.composer) {
      const w = window.innerWidth, h = window.innerHeight;
      const rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: 4 });
      this.composer = new EffectComposer(this.renderer, rt); this.composer.addPass(new RenderPass(this.scene, this.camera));
      this.bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.5, 0.65, 0.92); this.composer.addPass(this.bloom); this.composer.addPass(new OutputPass());
    }
    if (this.bloom) this.bloom.strength = s.quality === 'ultra' ? 0.65 : 0.45;
    this.audio.setVolumes(s.master, s.music, s.sfx);
    if (s.fullscreen && !document.fullscreenElement) document.documentElement.requestFullscreen?.().then(() => (navigator as any).keyboard?.lock?.(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ControlLeft', 'KeyC', 'KeyQ', 'KeyE', 'KeyR', 'ShiftLeft', 'Space'])).catch(() => {});
    if (!s.fullscreen && document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    this.resize();
  }
  useComposer() { return !!this.composer && this.q.bloom; }
  ghostify(c: Character) { const m = new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: 0.35, depthWrite: false }); c.root.traverse((o) => { if ((o as THREE.Mesh).isMesh) { (o as THREE.Mesh).material = m; o.castShadow = false; } }); }
  applyCosmetics() { const c = getState().save.cosmetics; this.menuChar.setCosmetics(c); this.previewChar.setCosmetics(c); this.arms.setCosmetics(c); this.ghostChar.root.traverse(() => {}); }

  // ---------------------------------------------------------------- menu / estágio
  setupStage() {
    const R = this.world.route, A = R[3], B = R[4]; const dx = B.x - A.x, dz = B.z - A.z; const horiz = Math.abs(dx) > Math.abs(dz);
    const d = new THREE.Vector3(horiz ? Math.sign(dx) : 0, 0, horiz ? 0 : Math.sign(dz)); const uA = horiz ? A.x * d.x : A.z * d.z, uB = horiz ? B.x * d.x : B.z * d.z;
    const hA = horiz ? A.hx : A.hz, hB = horiz ? B.hx : B.hz; const lat = horiz ? A.z : A.x;
    this.stage = { d, uA, uB, hA, hB, lat, yA: A.y, yB: B.y, horiz, start: uA - hA + 3, end: uB + hB - 3, edgeA: uA + hA, edgeB: uB - hB, A, B };
    this.stage.T = (this.stage.end - this.stage.start) / 9 + 0.9;
  }
  setView(v: View) { if (v !== this.view && (v === 'custom' || this.view === 'custom')) this.camInit = false; this.view = v; this.previewChar.root.visible = v === 'custom'; this.menuChar.root.visible = v !== 'custom' && this.mode === 'menu'; }
  stagePos(t: number, out: THREE.Vector3) {
    const S = this.stage; const tt = t % S.T; const u = S.start + 9 * Math.min(tt, (S.end - S.start) / 9); const ju0 = S.edgeA - 1.0, ju1 = S.edgeB + 1.1;
    let y = u < ju0 ? S.yA : u > ju1 ? S.yB : 0; let jump = false;
    if (u >= ju0 && u <= ju1) { const s = (u - ju0) / (ju1 - ju0); y = S.yA + (S.yB - S.yA) * s + 1.5 * Math.sin(Math.PI * s); jump = true; }
    const along = S.horiz ? new THREE.Vector3(u * S.d.x, y, S.lat) : new THREE.Vector3(S.lat, y, u * S.d.z); out.copy(along); return { jump, tt };
  }
  updateMenu(dt: number) {
    this.menuT += dt; const S = this.stage; const p = new THREE.Vector3(); const { jump, tt } = this.stagePos(this.menuT, p);
    const c = this.menuChar; c.root.position.copy(p); c.root.rotation.y = Math.atan2(-S.d.x, -S.d.z); c.root.visible = this.mode === 'menu' && this.view !== 'custom';
    const fade = Math.min(1, tt * 4, (S.T - tt) * 4); c.root.scale.setScalar(Math.max(0.01, fade)); c.setState(jump ? 'jump' : 'run', 9, dt, this.menuT);
    const focus = new THREE.Vector3(S.horiz ? (S.edgeA + S.edgeB) / 2 * S.d.x : S.lat, (S.yA + S.yB) / 2 + 1.4, S.horiz ? S.lat : (S.edgeA + S.edgeB) / 2 * S.d.z);
    const away = new THREE.Vector3(focus.x, 0, focus.z).normalize();
    const th = Math.sin(this.menuT * 0.16) * 0.55; const v = this.view;
    let camPos: THREE.Vector3, look: THREE.Vector3;
    if (v === 'custom') {
      const pc = this.previewChar; if (!this.customSpot) this.findCustomSpot();
      pc.root.position.copy(this.customSpot!.pos); pc.root.rotation.y = this.menuT * 0.5; pc.setState('idle', 0, dt, this.menuT);
      camPos = this.customSpot!.cam; const side = new THREE.Vector3(camPos.z - pc.root.position.z, 0, -(camPos.x - pc.root.position.x)).normalize();
      look = pc.root.position.clone().add(new THREE.Vector3(0, 0.95, 0)).addScaledVector(side, 0.9);
    } else if (v === 'map' || v === 'settings') {
      const ang = this.menuT * 0.05; camPos = new THREE.Vector3(Math.cos(ang) * 120, 135, Math.sin(ang) * 120 - 40); look = new THREE.Vector3(0, 60, 0);
    } else {
      const ang = th + (v === 'challenges' ? 0.9 : 0); const wide = v === 'main' ? 11 : 15;
      const dir = away.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), ang);
      camPos = focus.clone().addScaledVector(dir, wide).add(new THREE.Vector3(0, 0.9 + Math.sin(this.menuT * 0.2) * 0.5 - (v === 'main' ? 0.6 : 0), 0));
      const clear = (c: THREE.Vector3) => { for (let i = 0; i <= 12; i++) { const q = focus.clone().lerp(c, i / 12); if (solidAt(this.world.grid, q.x, q.y, q.z, 0.6)) return false; } return true; };
      for (let hh = 0; hh < 14 && !clear(camPos); hh++) camPos.y += 1.5;
      if (!clear(camPos)) { for (const ex of [1, -1]) { const alt = focus.clone().addScaledVector(dir.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), ex * 1.2), wide + 4).add(new THREE.Vector3(0, 3, 0)); if (clear(alt)) { camPos = alt; break; } } }
      look = focus.clone().lerp(p.clone().add(new THREE.Vector3(0, 1, 0)), 0.45);
    }
    if (!this.camInit) { this.camPosS.copy(camPos); this.camTarget.copy(look); this.camInit = true; }
    const k = 1 - Math.exp(-2.5 * dt); this.camPosS.lerp(camPos, k); this.camTarget.lerp(look, k);
    this.camera.position.copy(this.camPosS); this.camera.up.set(0, 1, 0); this.camera.lookAt(this.camTarget); this.camera.rotation.z = 0;
    this.camera.fov += (getState().settings.fov - 12 - this.camera.fov) * k; this.camera.updateProjectionMatrix();
    this.heli.update(this.time); this.heliPos.copy(this.heli.pos);
  }

  customSpot: { pos: THREE.Vector3; cam: THREE.Vector3 } | null = null;
  findCustomSpot() {
    const S = this.stage, g = this.world.grid, A = S.A as any; const free = (x: number, y: number, z: number, r: number) => { for (let a = 0; a < 8; a++) for (const h of [0.3, 1.0, 1.8]) if (solidAt(g, x + Math.cos(a * 0.785) * r, y + h, z + Math.sin(a * 0.785) * r)) return false; return !solidAt(g, x, y + 1, z); };
    let best = new THREE.Vector3(A.x, A.y, A.z);
    outer: for (const r of [0, 2, 4]) for (let k = 0; k < (r ? 8 : 1); k++) { const x = A.x + Math.cos(k * 0.785) * r, z = A.z + Math.sin(k * 0.785) * r; if (Math.abs(x - A.x) < A.hx - 1.5 && Math.abs(z - A.z) < A.hz - 1.5 && free(x, A.y, z, 1.1)) { best = new THREE.Vector3(x, A.y, z); break outer; } }
    const head = best.clone().add(new THREE.Vector3(0, 1.3, 0)); let cam = head.clone().add(new THREE.Vector3(0, 0.3, 4.8));
    const clear = (c: THREE.Vector3) => { for (let i = 1; i <= 10; i++) { const q = head.clone().lerp(c, i / 10); if (solidAt(g, q.x, q.y, q.z, 0.4)) return false; } return true; };
    const away = new THREE.Vector3(best.x, 0, best.z).normalize(); let found = false;
    for (const h of [0.2, 1.2, 2.4]) for (let k = 0; k < 8 && !found; k++) { const c = head.clone().addScaledVector(away.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), k * 0.785), 4.8); c.y += h; if (clear(c)) { cam = c; found = true; } }
    this.customSpot = { pos: best, cam };
  }

  // ---------------------------------------------------------------- minimapa
  buildMap() {
    const S = 1024, c = this.mapCanvas; c.width = c.height = S; const g = c.getContext('2d')!; const k = S / 640, o = 320;
    g.fillStyle = '#12161d'; g.fillRect(0, 0, S, S);
    g.fillStyle = '#1b212b'; for (let i = -4; i <= 4; i++) { g.fillRect((i * 64 - 8 + o) * k, 0, 16 * k, S); g.fillRect(0, (i * 64 - 8 + o) * k, S, 16 * k); }
    const cols: Array<[number, string]> = [[0, '#26303d'], [8, '#343f4f'], [20, '#46546a'], [45, '#5c6d88'], [90, '#7788a6']];
    for (const c2 of this.world.grid.all) {
      if (c2.slope || c2.maxY < 1.4 || c2.maxY - c2.minY < 1.2) continue; if (c2.maxX - c2.minX < 1.2 && c2.maxZ - c2.minZ < 1.2) continue;
      let col = cols[0][1]; for (const [h, cc] of cols) if (c2.maxY >= h) col = cc; g.fillStyle = col;
      g.fillRect((c2.minX + o) * k, (c2.minZ + o) * k, (c2.maxX - c2.minX) * k, (c2.maxZ - c2.minZ) * k);
    }
    g.strokeStyle = '#0b0e13'; g.lineWidth = 1; g.strokeRect(0, 0, S, S);
  }

  // ---------------------------------------------------------------- entrada
  actionDown(a: Action) {
    const s = getState().settings.keys; if (this.keys.has(s[a])) return true;
    if (a === 'crouch') return this.keys.has('KeyC') || this.keys.has('ControlRight'); if (a === 'sprint') return this.keys.has('ShiftRight'); return false;
  }
  onKeyDown = (e: KeyboardEvent) => {
    if (this.mode === 'play') { if (e.code === 'Space' || e.code.startsWith('Arrow') || e.ctrlKey || e.code === 'Tab') e.preventDefault(); }
    if (e.repeat) return; this.keys.add(e.code);
    const k = getState().settings.keys;
    if (this.mode === 'play') {
      if (e.code === k.jump) this.edges.jump = true; if (e.code === k.crouch || e.code === 'KeyC' || e.code === 'ControlRight') this.edges.crouch = true;
      if (e.code === k.dash) this.edges.dash = true; if (e.code === k.interact) this.edges.interact = true;
      if (e.code === k.respawn) this.respawn(false);
      if (e.code === 'Escape' && this.noLock) this.pause();
      if (e.code === 'KeyM') setSettings({ minimap: !getState().settings.minimap });
    }
  };
  onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.code); };
  onBlur = () => { this.keys.clear(); this.clearTouch(); if (this.mode === 'play') this.pause(); };
  setTouchMove(f: number, s: number) { this.touch.f = Math.max(-1, Math.min(1, f)); this.touch.s = Math.max(-1, Math.min(1, s)); }
  setTouchSprint(v: boolean) { this.touch.sprint = v; }
  setTouchCrouch(v: boolean) { this.touch.crouch = v; }
  touchAction(action: 'jump' | 'crouch' | 'dash' | 'interact') { if (action === 'jump') this.edges.jump = true; else if (action === 'crouch') this.edges.crouch = true; else if (action === 'dash') this.edges.dash = true; else this.edges.interact = true; }
  touchLook(dx: number, dy: number) { this.touch.lookX += dx; this.touch.lookY += dy; }
  clearTouch() { this.touch.f = 0; this.touch.s = 0; this.touch.sprint = false; this.touch.crouch = false; this.touch.lookX = 0; this.touch.lookY = 0; }
  consumeTouchLook() { const x = this.touch.lookX, y = this.touch.lookY; this.touch.lookX = 0; this.touch.lookY = 0; return { x, y }; }
  onMouse = (e: MouseEvent) => {
    if (this.mode !== 'play' || this.run?.state === 'countdown') return; if (!this.locked && !this.noLock) return;
    const s = getState().settings; const sens = 0.0006 + s.sens * 0.0036; const mx = Math.max(-200, Math.min(200, e.movementX)), my = Math.max(-200, Math.min(200, e.movementY));
    this.player.yaw -= mx * sens; this.player.pitch = Math.max(-1.5, Math.min(1.5, this.player.pitch - my * sens * (s.invertY ? -1 : 1)));
  };
  onLockChange = () => {
    this.locked = document.pointerLockElement === this.canvas;
    if (!this.locked && this.mode === 'play' && !this.noLock) this.pause();
  };
  onLockError = () => { this.noLock = true; if (this.lockWanted) { this.toast('Mouse livre ativado (sem captura). ESC pausa.', 'info'); } };
  lock() {
    this.lockWanted = true;
    try { const r: any = (this.canvas as any).requestPointerLock({ unadjustedMovement: true }); if (r && r.catch) r.catch(() => { try { const r2: any = this.canvas.requestPointerLock(); r2?.catch?.(() => { this.noLock = true; }); } catch { this.noLock = true; } }); } catch { try { this.canvas.requestPointerLock(); } catch { this.noLock = true; } }
    setTimeout(() => { if (this.mode === 'play' && document.pointerLockElement !== this.canvas) this.noLock = true; }, 600);
  }

  // ---------------------------------------------------------------- fluxo de jogo
  initAudio() { this.audio.init(); }
  play(challengeId?: string) {
    this.audio.init(); this.mode = 'play'; this.view = 'none'; this.menuChar.root.visible = false; this.previewChar.root.visible = false; this.arms.group.visible = true; this.camera.rotation.z = 0;
    this.lock(); const st = getState();
    if (challengeId) { this.startChallenge(challengeId); }
    else {
      this.endRun(false); const cp = st.save.checkpoint; const c0 = cp ? this.world.cps[cp.id] : this.world.cps[0]; const c = c0 || this.world.cps[0];
      this.player.teleport(c.x, c.y + 0.05, c.z, cp ? cp.yaw : c.yaw); this.emit('mode', 'play');
    }
    this.camInit = false; this.camera.fov = st.settings.fov; this.camera.updateProjectionMatrix(); this.emit('mode', 'play');
  }
  continueFree() {
    this.endRun(false); this.mode = 'play'; this.view = 'none'; this.menuChar.root.visible = false; this.arms.group.visible = true; this.lock(); this.refreshBeacons(); this.camera.rotation.z = 0; this.emit('mode', 'play');
  }
  updateResult(dt: number) {
    const P = this.player, c = this.menuChar; c.root.visible = true; c.root.scale.setScalar(1); c.root.position.copy(P.pos); c.root.rotation.y = P.yaw + 2.4; c.setState('idle', 0, dt, this.time);
    const a = this.time * 0.18 + P.yaw; const tgt = P.pos.clone().add(new THREE.Vector3(0, 1.15, 0)); const cp = tgt.clone().add(new THREE.Vector3(Math.sin(a) * 4.2, 0.35, Math.cos(a) * 4.2));
    if (!this.resultInit) { this.camPosS.copy(this.camera.position); this.camTarget.copy(tgt); this.resultInit = true; }
    const k = 1 - Math.exp(-3 * dt); this.camPosS.lerp(cp, k); this.camTarget.lerp(tgt, k);
    this.camera.position.copy(this.camPosS); this.camera.up.set(0, 1, 0); this.camera.lookAt(this.camTarget); this.camera.rotation.z = 0;
    this.camera.fov += (getState().settings.fov - 14 - this.camera.fov) * k; this.camera.updateProjectionMatrix();
  }
  resultInit = false;
  pause() { if (this.mode !== 'play') return; this.mode = 'pause'; this.keys.clear(); if (document.pointerLockElement) document.exitPointerLock(); this.emit('mode', 'pause'); }
  resume() { if (this.mode !== 'pause') return; this.mode = 'play'; this.lock(); this.emit('mode', 'play'); }
  toMenu() {
    this.endRun(false); this.mode = 'menu'; this.view = 'main'; this.arms.group.visible = false; if (document.pointerLockElement) document.exitPointerLock(); this.menuChar.root.visible = true; this.camInit = false;
    this.rivalChar.root.visible = false; this.ghostChar.root.visible = false; this.chaserMesh.visible = false; this.camera.rotation.z = 0; this.emit('mode', 'menu');
  }
  respawn(fatal: boolean) {
    const st = getState(); let x: number, y: number, z: number, yaw: number;
    if (this.run && this.run.state !== 'done') { const r = this.run.lastRing; x = r.x; y = r.y; z = r.z; yaw = r.yaw; }
    else { const cp = st.save.checkpoint ? this.world.cps[st.save.checkpoint.id] : this.world.cps[0]; x = cp.x; y = cp.y; z = cp.z; yaw = st.save.checkpoint?.yaw ?? cp.yaw; }
    this.player.teleport(x, y + 0.05, z, yaw); this.breakCombo(true);
    if (!fatal) this.toast('Voltou ao checkpoint', 'info'); this.emit('respawn', { fatal });
  }
  die(fall: number) {
    mutateSave((s) => { s.stats.deaths++; }, true); this.audio.fatal(); this.particles.burst(this.player.pos.x, this.player.pos.y + 0.2, this.player.pos.z, 30, 6, 0xb8a58c, 0.5, 1.0);
    this.emit('death', { fall }); this.toast('QUEDA FATAL', 'bad', Math.round(fall) + ' m');
    if (this.run && (this.run.r.def.type === 'nofall' || this.run.r.def.type === 'precision') && this.run.state === 'running') { this.finishRun(true, 'Queda fatal'); this.respawn(true); return; }
    this.respawn(true);
  }

  // ---------------------------------------------------------------- desafios
  level() { return levelFor(getState().save.xp); }
  completed(id: string) { return (getState().save.medals[id]?.medal || 0) >= 1; }
  allMainDone() { return MAIN_IDS.every((i) => this.completed(i)); }
  isUnlocked(id: string) { const d = DEFS.find((x) => x.id === id)!; const s = getState().save; if (s.freeRoam) return true; if (id === 'final') return this.allMainDone(); return this.level() >= d.minLevel; }
  refreshBeacons() {
    const list = DEFS.map((d) => { const r = this.resolved[d.id]; const m = getState().save.medals[d.id]?.medal || 0; return { x: r.start.x, y: r.start.y, z: r.start.z, color: !this.isUnlocked(d.id) ? 0x666b75 : m >= 3 ? 0xffd400 : m > 0 ? 0x6dff8a : d.id === 'final' ? 0xff3fa4 : 0xffffff }; });
    this.pickups.setBeacons(list);
  }
  startChallenge(id: string) {
    if (!this.isUnlocked(id)) { this.toast('Desafio bloqueado', 'bad'); return; }
    const r = this.resolved[id]; this.run = new ChallengeRun(r, this.world); this.run.startScore = this.score; const s = r.start;
    this.player.teleport(s.x, s.y + 0.05, s.z, s.yaw); this.pickups.setOrbs(r.orbs); this.nextTarget(); this.breakCombo(true);
    this.rivalChar.root.visible = r.def.type === 'rival'; this.chaserMesh.visible = r.def.type === 'escape';
    this.ghostData = null; this.ghostChar.root.visible = false;
    if (getState().settings.ghost) { try { const raw = localStorage.getItem('pk_ghost_' + id); if (raw) { this.ghostData = JSON.parse(raw); } } catch { /* */ } }
    this.recording = []; this.recT = 0; this.emit('challenge', { id }); this.emit('mode', 'play');
    if (this.mode !== 'play') { this.mode = 'play'; this.arms.group.visible = true; this.view = 'none'; this.menuChar.root.visible = false; this.lock(); }
  }
  restartChallenge() { if (this.run) { const id = this.run.r.def.id; this.endRun(false); this.mode = 'play'; this.startChallenge(id); this.lock(); this.emit('mode', 'play'); } }
  nextTarget() {
    const run = this.run; if (!run) { this.pickups.setTarget(null); return; }
    const ring = run.currentRing(); if (!ring || run.r.def.type === 'explore') { this.pickups.setTarget(null); if (run.r.def.type === 'explore' && run.r.secretIdx >= 0) { const sct = this.world.secrets[run.r.secretIdx]; this.pickups.setTarget(new THREE.Vector3(sct.x, sct.y - 1.5, sct.z), 0xb04bff); } return; }
    const last = run.nextRing === run.r.rings.length - 1;
    this.pickups.setTarget(new THREE.Vector3(ring.x, ring.y, ring.z), last ? 0x6dff8a : 0xffd400, ring.yaw);
    const sc = ring.r / 3; this.pickups.ringGroup.scale.set(sc, 1, sc);
  }
  endRun(returnPlayer: boolean) { void returnPlayer; this.run = null; this.pickups.setTarget(null); this.pickups.setOrbs([]); this.rivalChar.root.visible = false; this.ghostChar.root.visible = false; this.chaserMesh.visible = false; this.hud.challenge = ''; this.hud.objective = []; this.hud.limit = 0; this.hud.countdown = 0; }
  quitChallenge() { this.endRun(false); this.toast('Desafio abandonado', 'info'); this.refreshBeacons(); }
  finishRun(failed: boolean, reason = '') {
    const run = this.run; if (!run) return; const def = run.r.def; const time = run.time; const t = run.r.times; let medal = 0;
    if (!failed) medal = time <= t[0] ? 3 : time <= t[1] ? 2 : 1;
    const bonus = failed ? 0 : Math.round(Math.max(0, t[2] - time) * 12); const score = Math.round(this.score - run.startScore + bonus); if (!failed) this.score += bonus;
    const st = getState(); const prev = st.save.medals[def.id]; const lvBefore = levelFor(st.save.xp);
    const mult = [0, 1, 1.4, 1.8]; let xpGain = 0, newBest = false;
    if (!failed) {
      const prevXp = Math.round(def.xp * mult[prev?.medal || 0]), nowXp = Math.round(def.xp * mult[medal]); xpGain = Math.max(0, nowXp - prevXp) + (prev ? 0 : 0);
      if (!prev) xpGain = nowXp;
      newBest = !prev || time < prev.time;
      mutateSave((s) => {
        s.xp += xpGain; const m = s.medals[def.id]; if (!m || medal > m.medal || (medal === m.medal && time < m.time)) s.medals[def.id] = { medal: Math.max(medal, m?.medal || 0), time: m && m.medal === medal ? Math.min(m.time, time) : time, score: Math.max(score, m?.score || 0) };
        const rk = (s.ranking[def.id] ||= []); rk.push({ time, score, date: Date.now() }); rk.sort((a, b) => b.score - a.score); s.ranking[def.id] = rk.slice(0, 5);
        if (def.id === 'final') { s.finalDone = true; s.freeRoam = true; }
      });
      if (newBest) { try { localStorage.setItem('pk_ghost_' + def.id, JSON.stringify(this.recording)); } catch { /* */ } }
      this.audio.medal(medal);
    } else this.audio.fail();
    const lvAfter = levelFor(getState().save.xp); if (lvAfter > lvBefore) this.levelUp(lvAfter);
    const res: ResultData = { id: def.id, name: def.name, failed, reason, time, medal, score, xpGain, levelUp: lvAfter > lvBefore ? lvAfter : 0, newBest, ranking: getState().save.ranking[def.id] || [], times: t, final: def.id === 'final' && !failed, stats: { ...getState().save.stats }, unlock: lvAfter > lvBefore ? UNLOCK_TEXT[lvAfter] : undefined };
    run.state = failed ? 'failed' : 'done'; this.mode = 'result'; this.resultInit = false; this.arms.group.visible = false; this.keys.clear(); if (document.pointerLockElement) document.exitPointerLock();
    this.emit('result', res); this.emit('mode', 'result'); this.refreshBeacons(); this.pickups.setTarget(null);
  }
  addXp(n: number) { const before = levelFor(getState().save.xp); mutateSave((s) => { s.xp += n; }, true); const after = levelFor(getState().save.xp); if (after > before) this.levelUp(after); }
  levelUp(lv: number) { this.player.perks = perks(lv); this.audio.levelUp(); this.toast('NÍVEL ' + lv, 'level', UNLOCK_TEXT[lv] || ''); this.emit('levelup', lv); this.refreshBeacons(); mutateSave(() => {}, false); }

  // ---------------------------------------------------------------- pontuação
  mult() { return Math.min(10, 1 + Math.floor(this.chain / 3)); }
  addMove(kind: string, base: number, label: string) {
    const m = this.mult(); const pts = Math.round(base * m); this.score += pts; this.comboPts += pts;
    this.chain += kind !== this.lastMove ? 2 : 1; this.lastMove = kind; this.comboT = 4; this.lastMoveName = label; this.lastMoveT = 1.6;
    mutateSave((s) => { s.stats.totalScore += pts; if (this.chain > s.stats.bestCombo) s.stats.bestCombo = this.chain; }, true);
    this.emit('move', { label, pts, mult: this.mult(), id: Math.random() });
  }
  breakCombo(silent = false) { if (this.chain >= 6 && !silent) this.toast(`COMBO x${this.mult()}`, 'good', '+' + this.comboPts); this.chain = 0; this.comboT = 0; this.comboPts = 0; this.lastMove = ''; }

  // ---------------------------------------------------------------- eventos do jogador
  onPlayerEvent(e: PEvent, d: any) {
    const P = this.player, A = this.audio, fx = this.particles; const f = find(FX, getState().save.cosmetics.fx); const run = this.run?.state === 'running' ? this.run : null;
    const stat = (fn: (s: Stats) => void) => mutateSave((s) => fn(s.stats), true);
    const dust = (n: number, sp: number) => fx.burst(P.pos.x, P.pos.y + 0.1, P.pos.z, n, sp, f.id === 'f1' ? 0xb8a58c : f.color, 0.3, 0.8);
    switch (e) {
      case 'jump': stat((s) => s.jumps++); A.jump(); this.addMove('jump', 10, 'SALTO'); if (d.speed > 7) dust(4, 1.5); break;
      case 'step': A.footstep(d.surf, d.spd); if (d.spd > 8) fx.burst(P.pos.x, P.pos.y + 0.05, P.pos.z, 1, 1.2, f.id === 'f1' ? 0xb8a58c : f.color, 0.22, 0.6, 0.6); break;
      case 'land': A.land(d.impact, P.surf); dust(Math.min(18, 3 + Math.round(d.impact * 0.5)), Math.min(5, 1.5 + d.impact * 0.12)); break;
      case 'vault': stat((s) => s.vaults++); A.vault(); this.addMove('vault', 100, 'VAULT'); run?.note('vault'); break;
      case 'climb': stat((s) => s.climbs++); A.climb(); this.addMove('climb', 120, 'ESCALADA'); run?.note('climb'); break;
      case 'hang': A.hang(); this.addMove('hang', 40, 'BORDA'); break;
      case 'wallrun': stat((s) => s.wallruns++); A.wallStart(); this.addMove('wallrun', 150, 'WALL RUN'); run?.note('wallrun'); break;
      case 'walljump': case 'wallkick': stat((s) => s.walljumps++); A.walljump(); this.addMove('walljump', 200, 'WALL JUMP'); run?.note('walljump'); fx.burst(P.pos.x, P.pos.y + 1, P.pos.z, 8, 3, 0xffffff, 0.2, 0.5); break;
      case 'slide': stat((s) => s.slides++); this.addMove('slide', 80, 'SLIDE'); run?.note('slide'); break;
      case 'roll': stat((s) => s.rolls++); A.roll(); this.addMove('roll', d.perfect ? 180 : 100, d.perfect ? 'ROLAMENTO PERFEITO' : 'ROLAMENTO'); run?.note('roll'); dust(14, 3); break;
      case 'perfect': stat((s) => s.perfect++); A.perfect(); this.addMove('perfect', 150, 'ATERRISSAGEM PERFEITA'); this.emit('flash', 'perfect'); break;
      case 'heavy': A.heavy(); this.breakCombo(); this.toast('Aterrissagem pesada', 'bad'); dust(20, 4); break;
      case 'stagger': A.heavy(); this.breakCombo(); this.toast('Impacto forte! Use CTRL antes de cair', 'bad'); dust(26, 5); break;
      case 'fatal': this.die(d.fall); break;
      case 'swing': stat((s) => s.swings++); A.swingGrab(); this.addMove('swing', 200, 'BALANÇO'); run?.note('swing'); break;
      case 'swingrelease': A.jump(); break;
      case 'dash': stat((s) => s.dashes++); A.dash(); this.addMove('dash', 50, 'IMPULSO'); fx.burst(P.pos.x, P.pos.y + 1, P.pos.z, 10, 5, 0xffffff, 0.2, 0.4); break;
      case 'bump': A.bump(); break;
    }
  }

  // ---------------------------------------------------------------- loop
  loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop); const lim = getState().settings.fpsLimit;
    if (lim > 0 && now - this.lastRender < 1000 / lim - 1.5) return; this.lastRender = now;
    const dt = Math.min(0.05, Math.max(0.0005, (now - this.last) / 1000)); this.last = now; this.time += dt; U.uTime.value = this.time;
    this.fpsAcc += dt; this.fpsN++; if (this.fpsAcc > 0.5) { this.fps = Math.round(this.fpsN / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }
    try { this.update(dt); } catch (err) { console.error(err); }
    if (this.useComposer()) this.composer!.render(); else this.renderer.render(this.scene, this.camera);
  };

  update(dt: number) {
    const st = getState(); const playing = this.mode === 'play';
    if (playing) this.updatePlay(dt); else if (this.mode === 'menu') this.updateMenu(dt); else if (this.mode === 'result') this.updateResult(dt);
    // mundo vivo
    const camPos = this.camera.position;
    const hit = this.traffic.update(this.mode === 'pause' ? 0 : dt, this.player.pos, this.trafficPos);
    if (hit && playing) { const P = this.player; P.vel.x = hit.dx * 9; P.vel.z = hit.dz * 9; P.vel.y = Math.max(P.vel.y, 6); P.state = 'air'; this.audio.bump(); this.player.shake = 0.3; this.breakCombo(); this.toast('Atropelado!', 'bad'); }
    if (this.mode !== 'pause') { this.npcs.update(dt, this.time, camPos); this.heli.update(this.time); this.heliPos.copy(this.heli.pos); }
    this.sirenPos.set(150, 6, Math.sin(this.time * 0.04) * 200);
    this.particles.update(dt); this.pickups.update(this.time);
    this.world.update(camPos, 300 + st.settings.viewDist * 900);
    this.env.update(this.mode === 'menu' ? camPos : this.player.pos, camPos);
    this.rain.mat.uniforms.uTime.value = this.time; this.rain.mat.uniforms.uCam.value.copy(camPos);
    this.ambient.mat.uniforms.uTime.value = this.time; this.ambient.mat.uniforms.uCam.value.copy(camPos); this.ambient.mat.uniforms.uWind.value.set(this.env.preset.rain ? 3 : 1.4, 0, 0.8);
    // áudio
    const P = this.player; this.audio.setListener(this.mode === 'menu' ? camPos : P.camPos, P.yaw);
    this.audio.update(dt, { playing, speed: playing ? P.speedH : 0, sprinting: P.sprinting, sliding: P.state === 'slide' || P.sliding, wallrun: P.state === 'wallrun', height: playing ? P.pos.y : 60, rain: this.env.preset.rain, weatherAmb: this.env.preset.ambientSound,
      challenge: !!this.run && this.run.state === 'running', flow: this.chain, menu: this.mode === 'menu', heli: this.heliPos, siren: this.sirenPos, cars: this.trafficPos, stamina: P.stamina, player: this.mode === 'menu' ? camPos : P.pos });
    this.updateHud(dt);
  }

  updatePlay(dt: number) {
    const P = this.player, st = getState(); const run = this.run; const frozen = !!run && run.state === 'countdown';
    const i = this.inp; const e = this.edges;
    i.f = frozen ? 0 : Math.max(-1, Math.min(1, (this.actionDown('forward') ? 1 : 0) - (this.actionDown('back') ? 1 : 0) + this.touch.f));
    i.s = frozen ? 0 : Math.max(-1, Math.min(1, (this.actionDown('right') ? 1 : 0) - (this.actionDown('left') ? 1 : 0) + this.touch.s));
    i.sprint = this.actionDown('sprint') || this.touch.sprint; i.crouch = this.actionDown('crouch') || this.touch.crouch; i.jump = !frozen && (this.actionDown('jump')); i.jumpP = !frozen && e.jump; i.crouchP = e.crouch; i.dashP = !frozen && e.dash;
    if (!frozen && (this.touch.lookX || this.touch.lookY)) { const look = this.consumeTouchLook(); const sens = 0.0018 * (st.settings.sens / 0.5); const mx = Math.max(-120, Math.min(120, look.x)); const my = Math.max(-120, Math.min(120, look.y)); P.yaw -= mx * sens; P.pitch = Math.max(-1.5, Math.min(1.5, P.pitch - my * sens * (st.settings.invertY ? -1 : 1))); }
    const interact = e.interact; e.jump = e.crouch = e.dash = e.interact = false;
    this.time; const x0 = P.pos.x, z0 = P.pos.z;
    P.update(dt, i); const moved = Math.hypot(P.pos.x - x0, P.pos.z - z0);
    mutateSave((s) => { s.stats.distance += moved; s.stats.playTime += dt; if (P.speedKmh > s.stats.bestSpeed) s.stats.bestSpeed = P.speedKmh; }, true);
    this.score += moved * 0.5 + Math.max(0, P.speedKmh - 32) * dt * 0.9;
    // camera
    const cam = this.camera; cam.position.copy(P.camPos); cam.rotation.set(P.pitch + P.camPitchOff, P.yaw, P.camRoll);
    const fov = st.settings.fov + P.fovExtra; if (Math.abs(cam.fov - fov) > 0.05) { cam.fov = fov; cam.updateProjectionMatrix(); }
    this.arms.update(dt, P.speedH, P.armPose.pump, P.armPose.reach, P.wallSide, this.time);
    // partículas contínuas
    const f = find(FX, st.save.cosmetics.fx); const foot = P.pos;
    if (P.state === 'slide' || P.sliding) { const bd = P.fwd; for (let k = 0; k < 2; k++) this.particles.emit(foot.x - bd.x * 0.3 + (Math.random() - 0.5) * 0.4, foot.y + 0.1, foot.z - bd.z * 0.3 + (Math.random() - 0.5) * 0.4, -bd.x * 2 + (Math.random() - 0.5), 1 + Math.random() * 1.2, -bd.z * 2 + (Math.random() - 0.5), P.surf === 1 ? 0xffc060 : 0xb8a58c, 0.18, 0.5, 6, 2); }
    if (P.state === 'wallrun') { this.particles.emit(foot.x + (Math.random() - 0.5) * 0.3, foot.y + 0.9 + Math.random() * 0.5, foot.z + (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 2, 1, (Math.random() - 0.5) * 2, 0xffd890, 0.12, 0.35, 9, 1); }
    if (f.id !== 'f1' && P.speedH > 7.5) { const col = Math.random() < 0.5 ? f.color : f.color2 || f.color; this.particles.emit(foot.x + (Math.random() - 0.5) * 0.3, foot.y + 0.3 + Math.random() * 1.2, foot.z + (Math.random() - 0.5) * 0.3, 0, f.id === 'f3' ? 1.5 : 0.2, 0, col, 0.2, f.id === 'f4' ? 0.9 : 0.6, f.id === 'f3' ? -1 : 0, 1, 0.05); }
    // combo
    if (this.comboT > 0) { const dec = !P.grounded ? 0.5 : P.speedH < 3 ? 3 : 1; this.comboT -= dt * dec; if (this.comboT <= 0) this.breakCombo(); }
    this.lastMoveT = Math.max(0, this.lastMoveT - dt);
    // estamina / respiração
    // coletáveis
    for (const pk of this.pickups.collect(P.pos)) {
      if (pk.kind === 'coin') { mutateSave((s) => { s.coins.push(pk.id); s.stats.coins++; }, true); this.audio.coin(); this.score += 25; this.hud.lastMove = ''; this.addXp(1); }
      else if (pk.kind === 'orb') { if (run?.state === 'running') { run.orbs++; this.audio.coin(); this.score += 50; this.toast(`Orbe ${run.orbs}/${run.r.def.need?.orbs}`, 'info'); } }
      else if (pk.kind === 'secret') { const sid = pk.sid!; mutateSave((s) => { if (!s.secrets.includes(sid)) s.secrets.push(sid); }); this.audio.secret(); this.addMove('secret', 1000, 'ROTA SECRETA!'); this.addXp(100); this.toast('ROTA SECRETA DESCOBERTA', 'good', '+1000'); if (run?.r.def.type === 'explore' && run.r.secretIdx === pk.id) run.secretFound = true; }
    }
    // checkpoints do mundo
    if (!run) for (let k = 0; k < this.world.cps.length; k++) {
      const c = this.world.cps[k]; if (k === this.curCp) continue; const dx = P.pos.x - c.x, dz = P.pos.z - c.z; if (dx * dx + dz * dz < 16 && Math.abs(P.pos.y - c.y) < 4) { this.curCp = k; mutateSave((s) => { s.checkpoint = { pos: [c.x, c.y, c.z], yaw: P.yaw, id: k }; }, true); this.pickups.setActiveCp(k); this.audio.checkpoint(); this.toast('CHECKPOINT', 'good'); this.score += 50; persist(true); }
    }
    // beacons / interação
    this.prompt = ''; this.promptId = '';
    if (!run) for (const d of DEFS) {
      const r = this.resolved[d.id].start; const dx = P.pos.x - r.x, dz = P.pos.z - r.z;
      if (dx * dx + dz * dz < 36 && Math.abs(P.pos.y - r.y) < 5) { this.promptId = d.id; this.prompt = this.isUnlocked(d.id) ? `[E] Iniciar: ${d.name}` : `${d.name} — nível ${d.id === 'final' ? 'completar todos os desafios' : d.minLevel}`; break; }
    }
    if (interact && this.promptId && this.isUnlocked(this.promptId)) this.startChallenge(this.promptId);
    // desafio
    if (this.run) this.updateRun(dt);
    // carro / queda fora
    this.autoSaveT += dt; if (this.autoSaveT > 5) { this.autoSaveT = 0; persist(true); }
    void interact;
  }

  updateRun(dt: number) {
    const run = this.run!, P = this.player; const prevCount = Math.ceil(run.countdown);
    const res = run.update(dt, P, P.grounded);
    if (run.state === 'countdown') { const c = Math.ceil(run.countdown); if (c !== prevCount && c > 0) this.audio.count(); }
    else if (run.state === 'running' && run.time < dt * 2) { this.audio.go(); this.toast('VAI!', 'good'); }
    if (run.state === 'running') {
      this.recT += dt; if (this.recT > 0.2) { this.recT = 0; this.recording.push(+P.pos.x.toFixed(1), +P.pos.y.toFixed(1), +P.pos.z.toFixed(1), +P.yaw.toFixed(2)); }
      if (run.justPassed) { this.audio.checkpoint(); this.toast('ANEL', 'good'); this.score += 100; this.nextTarget(); this.world.cps.length; }
      // órbes
      const rival = run.r.def.type === 'rival';
      if (rival) { this.rivalChar.root.position.copy(run.rivalPos); this.rivalChar.root.rotation.y = run.rivalYaw; this.rivalChar.setState(run.rivalAir > 0.05 ? 'jump' : 'run', 6.4, dt, this.time); this.rivalChar.root.visible = true; }
      if (run.r.def.type === 'escape') { const R = this.world.route; const ci = Math.max(0, Math.min(R.length - 1, Math.floor(run.chaserIdx))); const p = R[ci]; this.chaserMesh.position.set(p.x, p.y + 30, p.z); this.chaserMesh.visible = true; }
      // fantasma
      if (this.ghostData && getState().settings.ghost) {
        const g = this.ghostData, n = g.length / 4, fi = run.time / 0.2, a = Math.floor(fi); if (a < n - 1) { const u = fi - a, l = (k: number) => g[a * 4 + k] + (g[(a + 1) * 4 + k] - g[a * 4 + k]) * u; this.ghostChar.root.position.set(l(0), l(1), l(2)); this.ghostChar.root.rotation.y = g[a * 4 + 3]; this.ghostChar.setState('run', 9, dt, this.time); this.ghostChar.root.visible = true; } else this.ghostChar.root.visible = false;
      }
    }
    if (res === 'finish') this.finishRun(false); else if (res === 'fail') this.finishRun(true, run.failReason);
  }

  updateHud(dt: number) {
    const h = this.hud, P = this.player, st = getState(), run = this.run; void dt;
    h.speed = this.mode === 'play' ? P.speedKmh : 0; h.score = Math.round(this.score); h.mult = this.mult(); h.chain = this.chain; h.comboT = Math.max(0, this.comboT / 4); h.comboPts = this.comboPts;
    h.region = REGION_NAMES[regionAt(P.pos.x, P.pos.z)]; h.stamina = P.stamina; h.staminaMax = P.perks.stamina; h.level = levelFor(st.save.xp); h.freeRoam = st.save.freeRoam; h.hasDash = P.perks.dash; h.dashCd = P.dashCd; h.fps = this.fps; h.height = P.pos.y; h.state = P.state;
    h.lastMove = this.lastMoveT > 0 ? this.lastMoveName : ''; h.prompt = this.prompt; h.locked = this.mode === 'play' && !this.locked && !this.noLock;
    const lv = h.level; const xs = [0, 0, 200, 500, 900, 1400, 2000, 2700, 3500, 4400, 5400]; h.xpPct = lv >= 10 ? 1 : (st.save.xp - xs[lv]) / (xs[lv + 1] - xs[lv]);
    if (run) {
      h.challenge = run.r.def.name; h.ctype = run.r.def.type; h.time = run.time; h.limit = run.limit - run.time; h.countdown = run.state === 'countdown' ? run.countdown : 0;
      h.objective = [...run.r.def.goals.slice(0, 1), ...run.progressText()]; h.alert = run.r.def.type === 'escape' && run.progIdx - run.chaserIdx < 3;
      const total = run.r.rings.length; h.ringText = run.r.def.type === 'explore' ? '' : `${Math.min(run.nextRing, total)}/${total}`;
    } else { h.challenge = ''; h.objective = []; h.time = 0; h.limit = 0; h.countdown = 0; h.ringText = ''; h.alert = false; h.ctype = ''; }
  }
}

export const defById = (id: string): ChallengeDef => DEFS.find((d) => d.id === id)!;
