import * as THREE from 'three';
import { Collider, ColliderGrid, overlapXZ, topUnder, groundBelow, GroundHit, solidAt, boxBlocked, slopeNormal } from './physics';
import { Bar } from './world';

export type PState = 'ground' | 'air' | 'slide' | 'wallrun' | 'hang' | 'mantle' | 'swing' | 'roll' | 'stagger';
export interface Input { f: number; s: number; sprint: boolean; crouch: boolean; jump: boolean; jumpP: boolean; crouchP: boolean; dashP: boolean }
export interface Perks { wallRunTime: number; dash: boolean; jump: number; stamina: number; slideBoost: number }
export type PEvent = 'jump' | 'land' | 'step' | 'vault' | 'climb' | 'hang' | 'wallrun' | 'walljump' | 'slide' | 'roll' | 'perfect' | 'heavy' | 'stagger'
  | 'fatal' | 'swing' | 'swingrelease' | 'dash' | 'bump' | 'wallkick';

export const TUNE = {
  R: 0.35, STEP: 0.5, G: 24, WALK: 5.0, SPRINT0: 8.0, SPRINTMAX: 13.8, CROUCH: 2.8, AIR_CAP: 6.5, TERMINAL: 62,
  FATAL_FALL: 22, FATAL_ROLL: 48, FATAL_AUTOROLL: 30,
};
const { R, STEP, G } = TUNE;

interface Ledge { c: Collider; top: number; nx: number; nz: number; tx: number; tz: number; fx: number; fz: number }

export class Player {
  pos = new THREE.Vector3(); vel = new THREE.Vector3();
  yaw = 0; pitch = 0;
  state: PState = 'air'; grounded = false; groundCol: Collider | null = null; surf = 0;
  hgt = 1.8; eye = 1.65; crouching = false; sprinting = false;
  stamina = 120; exhausted = false; mom = 0; peakY = 0;
  perks: Perks = { wallRunTime: 1.5, dash: false, jump: 9, stamina: 100, slideBoost: 1 };
  gravityScale = 1;
  // câmera
  camPos = new THREE.Vector3(); camRoll = 0; camPitchOff = 0; fovExtra = 0; shake = 0; landDip = 0; bobPhase = 0; spinAng = 0;
  armPose = { pump: 0, reach: 0 };
  wallSide = 0; hangT = 0; speedH = 0; dead = false; stepDist = 0; dashCd = 0; sliding = false;
  mantleKind = ''; mantleU = 0; rollT = 0; rollPerfect = false; slideT = 0; staggerT = 0;
  swingTheta = 0; swingOmega = 0; swingBar: Bar | null = null; lastWallJump = 0; airTime = 0;
  onEvent: (e: PEvent, d?: any) => void = () => {};

  private grid: ColliderGrid; private gh: GroundHit = { y: 0, c: null }; private list: Collider[] = [];
  private coyote = 0; private jumpBuf = 0; private crouchBuf = 0; private dashBuf = 0; private justJumped = 0;
  private wallCd = 0; private wallJumps = 3; private barCd = 0; private ledgeCd = 0; private wallLost = 0; private wallT = 0;
  private wr = { nx: 0, nz: 0, tx: 0, tz: 0, kind: 'side', speed: 0, col: null as Collider | null };
  private mS = new THREE.Vector3(); private mT = new THREE.Vector3(); private mDur = 0.4; private mSpeed = 0; private mDir = new THREE.Vector3();
  private hang: { x: number; y: number; z: number; tx: number; tz: number; top: number; nx: number; nz: number } | null = null;
  private slideDir = new THREE.Vector3(); private rollDir = new THREE.Vector3(); private tmpN = { x: 0, y: 1, z: 0 };
  private prevSlope: { axis: number; dir: number; k: number } | null = null; private lastLandSpeed = 0;
  private bars: Bar[];

  constructor(grid: ColliderGrid, bars: Bar[]) { this.grid = grid; this.bars = bars; }

  get speedKmh() { return Math.hypot(this.vel.x, this.vel.z) * 3.6; }
  get fwd() { return new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)); }

  teleport(x: number, y: number, z: number, yaw: number) {
    this.pos.set(x, y, z); this.vel.set(0, 0, 0); this.yaw = yaw; this.pitch = 0; this.state = 'air'; this.grounded = false;
    this.peakY = y; this.dead = false; this.hgt = 1.8; this.eye = 1.65; this.crouching = false; this.mom = 0; this.camRoll = 0; this.spinAng = 0;
    this.hang = null; this.swingBar = null; this.wallCd = 0.3; this.airTime = 0; this.staggerT = 0; this.stamina = this.perks.stamina;
  }

  private wish(inp: Input, out: THREE.Vector3) {
    const sy = Math.sin(this.yaw), cy = Math.cos(this.yaw);
    out.set(-sy * inp.f + cy * inp.s, 0, -cy * inp.f - sy * inp.s);
    const l = out.length(); if (l > 1) out.multiplyScalar(1 / l);
    return l;
  }
  private _w = new THREE.Vector3(); private _t = new THREE.Vector3();

  update(dt: number, inp: Input) {
    if (this.dead) return;
    this.jumpBuf = inp.jumpP ? 0.15 : Math.max(0, this.jumpBuf - dt);
    this.crouchBuf = inp.crouchP ? 0.4 : Math.max(0, this.crouchBuf - dt);
    this.dashBuf = inp.dashP ? 0.15 : Math.max(0, this.dashBuf - dt);
    this.wallCd = Math.max(0, this.wallCd - dt); this.barCd = Math.max(0, this.barCd - dt); this.ledgeCd = Math.max(0, this.ledgeCd - dt);
    this.justJumped = Math.max(0, this.justJumped - dt); this.dashCd = Math.max(0, this.dashCd - dt);
    this.coyote = this.grounded ? 0.13 : Math.max(0, this.coyote - dt);
    const n = Math.max(1, Math.ceil(dt / (1 / 90))), h = dt / n;
    for (let i = 0; i < n; i++) this.step(h, inp);
    if (this.pos.y < -5) this.pos.y = 0;
    this.speedH = Math.hypot(this.vel.x, this.vel.z);
    this.updateCamera(dt, inp);
  }

  // ===================================================== passo de física
  private step(h: number, inp: Input) {
    switch (this.state) {
      case 'mantle': this.stepMantle(h); return;
      case 'hang': this.stepHang(h, inp); return;
      case 'wallrun': this.stepWallrun(h, inp); return;
      case 'swing': this.stepSwing(h, inp); return;
      default: this.stepNormal(h, inp);
    }
  }

  private stepNormal(h: number, inp: Input) {
    const w = this._w; const wl = this.wish(inp, w); const has = wl > 0.05;
    const vh = this._t.set(this.vel.x, 0, this.vel.z); let spd = vh.length();
    const wasGrounded = this.grounded;
    // ---- altura / agachar
    if (this.state === 'ground' || this.state === 'air') {
      const want = inp.crouch;
      if (want && !this.crouching && this.state === 'ground') this.crouching = true;
      if (!want && this.crouching && this.canStand()) this.crouching = false;
      this.hgt = this.crouching ? 1.1 : 1.8;
    }
    if (this.state === 'stagger') {
      this.staggerT -= h; this.vel.x *= 0.9; this.vel.z *= 0.9; this.hgt = 1.2;
      if (this.staggerT <= 0) { this.state = 'ground'; this.hgt = 1.8; }
    } else if (this.state === 'roll') {
      this.rollT += h; this.hgt = 1.0;
      const u = this.rollT / 0.6; const sp = Math.max(4.5, (this.rollPerfect ? 0.97 : 0.72) * this.lastLandSpeed) * (1 - u * 0.25);
      this.vel.x = this.rollDir.x * sp; this.vel.z = this.rollDir.z * sp;
      if (u >= 1) { this.state = this.grounded ? 'ground' : 'air'; this.hgt = this.canStand() ? 1.8 : 1.1; this.crouching = this.hgt < 1.5; this.mom = 0.4; }
      if (this.jumpBuf > 0 && u > 0.5 && this.grounded) { this.state = 'ground'; this.doJump(); }
    } else if (this.state === 'slide') {
      this.stepSlide(h, inp, w, has);
    } else if (this.state === 'ground') {
      this.stepGround(h, inp, w, has, spd);
    } else {
      this.stepAir(h, inp, w, has, spd);
    }
    // ---- gravidade
    if (this.state === 'air' || !this.grounded) {
      let g = G * this.gravityScale;
      if (this.vel.y > 0 && !inp.jump && this.justJumped <= 0) g *= 1.7;
      this.vel.y = Math.max(-TUNE.TERMINAL, this.vel.y - g * h);
      this.peakY = Math.max(this.peakY, this.pos.y); this.airTime += h;
    } else this.airTime = 0;
    // ---- ações contextuais
    if (this.state === 'ground' || this.state === 'air') this.contextActions(h, inp, has);
    if (this.state !== 'ground' && this.state !== 'air' && this.state !== 'slide' && this.state !== 'roll' && this.state !== 'stagger') return;
    this.collideMove(h);
    // ---- transições de chão
    if (this.grounded && !wasGrounded) this.onLand(inp);
    if (!this.grounded && wasGrounded && (this.state === 'ground' || this.state === 'slide' || this.state === 'roll')) {
      if (this.prevSlope && this.state !== 'roll') {
        const up = this.prevSlope.axis === 0 ? this.vel.x * this.prevSlope.dir : this.vel.z * this.prevSlope.dir;
        if (up > 2 && this.vel.y < up * this.prevSlope.k) this.vel.y = up * this.prevSlope.k * 0.95;
      }
      if (this.state !== 'roll') { this.state = 'air'; this.sliding = false; }
      this.peakY = this.pos.y;
    }
    // sobe/desce sloped info
    if (this.grounded && this.groundCol?.slope) {
      const s = this.groundCol.slope; const k = slopeNormal(this.groundCol, this.tmpN);
      this.prevSlope = { axis: s.axis, dir: s.dir, k };
    } else this.prevSlope = null;
  }

  private stepGround(h: number, inp: Input, w: THREE.Vector3, has: boolean, spd: number) {
    const canSprint = inp.sprint && !this.exhausted && inp.f > 0.1 && !this.crouching;
    this.sprinting = canSprint && has;
    if (this.sprinting && spd > 3) this.mom = Math.min(1, this.mom + h / 3.2); else this.mom = Math.max(0, this.mom - h / 1.1);
    const target = !has ? 0 : this.crouching ? TUNE.CROUCH : this.sprinting ? TUNE.SPRINT0 + (TUNE.SPRINTMAX - TUNE.SPRINT0) * this.mom : TUNE.WALK;
    if (this.sprinting) this.stamina = Math.max(0, this.stamina - 7 * h * (0.6 + this.mom * 0.5)); else this.stamina = Math.min(this.perks.stamina, this.stamina + (has ? 14 : 24) * h);
    if (this.stamina <= 0) this.exhausted = true; else if (this.exhausted && this.stamina > 25) this.exhausted = false;
    // inclinação escorregadia
    let slipping = false;
    if (this.groundCol?.slope?.slip) {
      slipping = true; const sl = this.groundCol.slope; const k = slopeNormal(this.groundCol, this.tmpN);
      const downX = sl.axis === 0 ? -sl.dir : 0, downZ = sl.axis === 1 ? -sl.dir : 0;
      const a = G * k / Math.hypot(1, k) * 0.9;
      this.vel.x += downX * a * h; this.vel.z += downZ * a * h;
      spd = Math.hypot(this.vel.x, this.vel.z);
      if (has) { this.vel.x += w.x * 6 * h; this.vel.z += w.z * 6 * h; }
      if (spd > 4) this.sliding = true;
    } else this.sliding = false;
    if (!slipping) {
      if (has) {
        if (spd <= target + 0.2) {
          const dvx = w.x * target - this.vel.x, dvz = w.z * target - this.vel.z, l = Math.hypot(dvx, dvz), md = (spd < target ? 42 : 30) * h;
          const k = l > md ? md / l : 1; this.vel.x += dvx * k; this.vel.z += dvz * k;
        } else { // excesso de velocidade: gira direção e sangra devagar
          const dx = this.vel.x / spd, dz = this.vel.z / spd; const t = Math.min(1, 7 * h);
          let nx = dx + (w.x - dx) * t, nz = dz + (w.z - dz) * t; const nl = Math.hypot(nx, nz) || 1; nx /= nl; nz /= nl;
          const ns = Math.max(target, spd - 5 * h); this.vel.x = nx * ns; this.vel.z = nz * ns;
        }
      } else {
        const dec = (this.crouching ? 22 : 30) * h; const ns = Math.max(0, spd - dec);
        if (spd > 0.001) { this.vel.x *= ns / spd; this.vel.z *= ns / spd; }
      }
    }
    // pulo
    if (this.jumpBuf > 0 && (this.grounded || this.coyote > 0)) { if (this.crouching && !this.canStand()) { /* preso */ } else this.doJump(); return; }
    // slide
    if (this.crouchBuf > 0 && inp.crouch && spd > 6.0 && this.grounded) this.startSlide(inp);
    // passos
    if (this.grounded && spd > 1.2 && !slipping) {
      this.stepDist += spd * h; const stride = this.crouching ? 1.6 : 1.5 + spd * 0.07;
      if (this.stepDist > stride) { this.stepDist = 0; this.onEvent('step', { surf: this.surf, spd }); }
    }
  }

  private startSlide(_inp: Input) {
    const sp = Math.hypot(this.vel.x, this.vel.z); const boost = Math.min(15.5, Math.max(sp * 1.1, 9.5) * this.perks.slideBoost);
    this.slideDir.set(this.vel.x / sp, 0, this.vel.z / sp);
    this.vel.x = this.slideDir.x * boost; this.vel.z = this.slideDir.z * boost;
    this.state = 'slide'; this.slideT = 0; this.crouching = true; this.hgt = 0.95; this.crouchBuf = 0;
    this.onEvent('slide');
  }
  private stepSlide(h: number, inp: Input, w: THREE.Vector3, has: boolean) {
    this.slideT += h; this.hgt = 0.95; this.sprinting = false;
    let spd = Math.hypot(this.vel.x, this.vel.z);
    // direção atual com leve controle lateral
    let dx = this.vel.x / (spd || 1), dz = this.vel.z / (spd || 1);
    if (has) { const t = Math.min(1, 1.6 * h); dx += (w.x - dx) * t * 0.5; dz += (w.z - dz) * t * 0.5; const l = Math.hypot(dx, dz) || 1; dx /= l; dz /= l; }
    let fr = 5.2;
    if (this.groundCol?.slope) {
      const sl = this.groundCol.slope; const k = slopeNormal(this.groundCol, this.tmpN);
      const downX = sl.axis === 0 ? -sl.dir : 0, downZ = sl.axis === 1 ? -sl.dir : 0;
      const along = dx * downX + dz * downZ; // >0 descendo
      fr = -along * G * k / Math.hypot(1, k) * 0.9 + (along < 0 ? 3 : 0.5);
    }
    spd = Math.max(0, spd - fr * h); this.vel.x = dx * spd; this.vel.z = dz * spd;
    if (this.jumpBuf > 0 && this.grounded) { this.state = 'ground'; this.crouching = false; this.hgt = 1.8; this.doJump(1.05); return; }
    const release = !inp.crouch && this.slideT > 0.3;
    if ((release || spd < 3.4 || this.slideT > 1.7) && this.grounded) {
      this.state = 'ground'; this.crouching = !this.canStand() || inp.crouch; this.hgt = this.crouching ? 1.1 : 1.8; this.mom = Math.min(1, spd / TUNE.SPRINTMAX);
    }
    this.stepDist += spd * h; if (this.stepDist > 4) this.stepDist = 0;
  }

  private stepAir(h: number, _inp: Input, w: THREE.Vector3, has: boolean, spd: number) {
    this.sprinting = false;
    if (has) {
      const cap = Math.max(spd, TUNE.AIR_CAP + this.mom * 3);
      const cur = this.vel.x * w.x + this.vel.z * w.z, add = Math.max(0, Math.min(26 * h, cap - cur));
      this.vel.x += w.x * add; this.vel.z += w.z * add;
      const ns = Math.hypot(this.vel.x, this.vel.z); // não deixa passar do teto atual
      if (ns > Math.max(spd, cap) + 0.01) { const k = Math.max(spd, cap) / ns; this.vel.x *= k; this.vel.z *= k; }
    }
    this.mom = Math.max(0, this.mom - h * 0.12);
    if (this.jumpBuf > 0 && this.coyote > 0 && this.justJumped <= 0) this.doJump();
    this.stamina = Math.min(this.perks.stamina, this.stamina + 10 * h);
  }

  private doJump(mult = 1) {
    const sp = Math.hypot(this.vel.x, this.vel.z);
    this.vel.y = this.perks.jump * mult; this.state = 'air'; this.grounded = false; this.coyote = 0; this.jumpBuf = 0; this.justJumped = 0.15;
    this.peakY = this.pos.y; this.crouching = false; this.hgt = 1.8; this.sliding = false;
    if (sp > 7.5) { const k = Math.min(1 + 1.2 / sp, 15.8 / sp); this.vel.x *= k; this.vel.z *= k; }
    this.wallJumps = 3; this.onEvent('jump', { speed: sp });
  }
  private canStand() { return !boxBlocked(this.grid, this.pos.x, this.pos.z, R * 0.9, this.pos.y + 1.1, this.pos.y + 1.8); }

  // ===================================================== ações contextuais
  private contextActions(h: number, inp: Input, has: boolean) {
    void h;
    const fwd = this.fwd; const spd = Math.hypot(this.vel.x, this.vel.z);
    const air = this.state === 'air';
    // dash
    if (this.dashBuf > 0 && this.perks.dash && this.dashCd <= 0 && this.stamina > 12) {
      const d = has ? this._w.clone().normalize() : fwd; const ns = Math.max(spd + 3.5, 15.5);
      this.vel.x = d.x * ns; this.vel.z = d.z * ns; if (air) this.vel.y = Math.max(this.vel.y, 3.2); this.dashCd = 2.2; this.dashBuf = 0; this.stamina -= 12;
      this.onEvent('dash'); this.fovExtraKick = 14;
    }
    // vault / escalada / agarrar borda
    if (this.ledgeCd <= 0) {
      const dirX = has ? this._w.x : fwd.x, dirZ = has ? this._w.z : fwd.z, dl = Math.hypot(dirX, dirZ) || 1;
      const ux = dirX / dl, uz = dirZ / dl;
      if (!air && this.grounded && !this.crouching && inp.f > 0.2 && spd > 3.2) {
        const lg = this.probeLedge(ux, uz, 0.58, 1.95);
        if (lg) {
          const rise = lg.top - this.pos.y;
          if (rise <= 1.4) { this.startMantle('vault', lg, 0.4, spd); return; }
          this.startMantle('climb', lg, 0.72, spd); return;
        }
      }
      if (!air && this.grounded && this.jumpBuf > 0 && inp.f > -0.2) {
        const lg = this.probeLedge(fwd.x, fwd.z, 1.9, 2.8);
        if (lg) { this.startMantle('climb', lg, 0.8, spd); this.jumpBuf = 0; return; }
      }
      if (air && this.lastWallJump <= 0 && this.vel.y < 5 && (inp.f > 0.1 || inp.jump)) {
        const lg = this.probeLedge(fwd.x, fwd.z, 0.9, 2.45) || (spd > 2 ? this.probeLedge(ux, uz, 0.9, 2.45) : null);
        if (lg) { this.startHang(lg); return; }
      }
    }
    this.lastWallJump = Math.max(0, this.lastWallJump - h);
    if (!air) return;
    // barras
    if (this.barCd <= 0 && inp.jump && this.justJumped <= 0.05 || (this.barCd <= 0 && inp.jump && this.vel.y < 6)) {
      const hy = this.pos.y + 1.95;
      for (const b of this.bars) {
        const dAlong = b.axis === 0 ? Math.abs(this.pos.x - b.x) : Math.abs(this.pos.z - b.z);
        const dPerp = b.axis === 0 ? Math.abs(this.pos.z - b.z) : Math.abs(this.pos.x - b.x);
        if (dAlong <= b.half + 0.2 && dPerp < 1.0 && Math.abs(hy - b.y) < 0.9) { this.startSwing(b); return; }
      }
    }
    // wall run / wall kick
    this.tryWall(inp, has);
  }
  fovExtraKick = 0;

  private faceNormal(c: Collider, px: number, pz: number): [number, number] {
    const a = px - c.minX, b = c.maxX - px, d = pz - c.minZ, e = c.maxZ - pz; const m = Math.min(a, b, d, e);
    return m === a ? [-1, 0] : m === b ? [1, 0] : m === d ? [0, -1] : [0, 1];
  }

  private probeLedge(fx: number, fz: number, minRise: number, maxRise: number): Ledge | null {
    const feet = this.pos.y, dd = R + 0.5, px = this.pos.x + fx * dd, pz = this.pos.z + fz * dd;
    this.grid.query(px - 0.25, px + 0.25, pz - 0.25, pz + 0.25, this.list);
    let best: Ledge | null = null;
    for (let i = 0; i < this.list.length; i++) {
      const c = this.list[i]; if (c.slope) continue;
      if (px < c.minX || px > c.maxX || pz < c.minZ || pz > c.maxZ) continue;
      const rise = c.maxY - feet; if (rise < minRise || rise > maxRise || c.minY > feet + 1.2) continue;
      const [nx, nz] = this.faceNormal(c, px, pz);
      if (-(fx * nx + fz * nz) < 0.45) continue;
      const depth = nx !== 0 ? c.maxX - c.minX : c.maxZ - c.minZ, inner = Math.min(0.6, depth / 2);
      const fcx = nx < 0 ? c.minX : nx > 0 ? c.maxX : px, fcz = nz < 0 ? c.minZ : nz > 0 ? c.maxZ : pz;
      const tx = nx !== 0 ? fcx - nx * inner : Math.min(c.maxX - 0.4, Math.max(c.minX + 0.4, px));
      const tz = nz !== 0 ? fcz - nz * inner : Math.min(c.maxZ - 0.4, Math.max(c.minZ + 0.4, pz));
      if (boxBlocked(this.grid, tx, tz, 0.3, c.maxY + 0.05, c.maxY + 1.75)) continue;
      if (!best || c.maxY < best.top) best = { c, top: c.maxY, nx, nz, tx, tz, fx: fcx, fz: fcz };
    }
    return best;
  }

  private startMantle(kind: string, lg: Ledge, dur: number, spd: number) {
    this.state = 'mantle'; this.mantleKind = kind; this.mS.copy(this.pos); this.mT.set(lg.tx, lg.top, lg.tz); this.mDur = dur; this.mantleU = 0;
    this.mSpeed = spd; this.mDir.set(-lg.nx, 0, -lg.nz); this.vel.set(0, 0, 0); this.peakY = this.pos.y; this.crouching = false; this.hgt = 1.8; this.sliding = false;
    this.onEvent(kind === 'vault' ? 'vault' : 'climb', { rise: lg.top - this.pos.y, speed: spd });
  }
  private stepMantle(h: number) {
    this.mantleU += h / this.mDur; const u = Math.min(1, this.mantleU);
    const sm = (a: number) => { const t = Math.max(0, Math.min(1, a)); return t * t * (3 - 2 * t); };
    if (this.mantleKind === 'vault') {
      const e = sm(u); this.pos.x = this.mS.x + (this.mT.x - this.mS.x) * e; this.pos.z = this.mS.z + (this.mT.z - this.mS.z) * e;
      this.pos.y = this.mS.y + (this.mT.y - this.mS.y) * e + Math.sin(Math.PI * u) * 0.28;
    } else {
      const ey = sm(u / 0.65), ex = sm((u - 0.35) / 0.65);
      this.pos.y = this.mS.y + (this.mT.y - this.mS.y) * ey; this.pos.x = this.mS.x + (this.mT.x - this.mS.x) * ex; this.pos.z = this.mS.z + (this.mT.z - this.mS.z) * ex;
    }
    if (u >= 1) {
      this.pos.copy(this.mT); this.state = 'ground'; this.grounded = true;
      const sp = this.mantleKind === 'vault' ? Math.max(this.mSpeed * 0.92, 6) : Math.max(3.5, this.mSpeed * 0.35);
      this.vel.set(this.mDir.x * sp, 0, this.mDir.z * sp); this.mom = this.mantleKind === 'vault' ? Math.min(1, sp / TUNE.SPRINTMAX) : 0.1; this.peakY = this.pos.y; this.ledgeCd = 0.15;
    }
  }

  private startHang(lg: Ledge) {
    this.state = 'hang'; this.hangT = 0; this.vel.set(0, 0, 0); this.peakY = this.pos.y;
    const hx = lg.fx + lg.nx * (R + 0.12), hz = lg.fz + lg.nz * (R + 0.12);
    this.hang = { x: hx, y: lg.top - 1.95, z: hz, tx: lg.tx, tz: lg.tz, top: lg.top, nx: lg.nx, nz: lg.nz };
    this.wallJumps = 3; this.sprinting = false; this.hgt = 1.8; this.onEvent('hang');
  }
  private stepHang(h: number, inp: Input) {
    const hg = this.hang!; this.hangT += h; const k = Math.min(1, 14 * h);
    this.pos.x += (hg.x - this.pos.x) * k; this.pos.z += (hg.z - this.pos.z) * k; this.pos.y += (hg.y - this.pos.y) * k;
    this.stamina = Math.max(0, this.stamina - 2 * h);
    if (this.hangT > 0.12 && (this.jumpBuf > 0 || inp.f > 0.3)) {
      this.jumpBuf = 0; this.state = 'mantle'; this.mantleKind = 'climb'; this.mS.copy(this.pos); this.mT.set(hg.tx, hg.top, hg.tz);
      this.mDur = 0.62; this.mantleU = 0; this.mSpeed = 4; this.mDir.set(-hg.nx, 0, -hg.nz); this.onEvent('climb', { rise: 2, hang: true });
    } else if (inp.crouch || inp.f < -0.5) {
      this.state = 'air'; this.ledgeCd = 0.5; this.vel.set(hg.nx * 1.5, -1, hg.nz * 1.5);
    }
  }

  // ---------- wall run / wall kick
  private tryWall(inp: Input, has: boolean) {
    if (this.wallCd > 0) { return; }
    const spd = Math.hypot(this.vel.x, this.vel.z); const feet = this.pos.y;
    const gh = groundBelow(this.grid, this.pos.x, this.pos.z, R, feet + 0.1, this.gh);
    const aboveGround = feet - gh.y;
    const fwd = this.fwd;
    if (inp.jumpP || this.jumpBuf > 0) { // wall kick no ar
      const dirs: [number, number][] = [[fwd.x, fwd.z], [-fwd.x, -fwd.z], [Math.cos(this.yaw), -Math.sin(this.yaw)], [-Math.cos(this.yaw), Math.sin(this.yaw)]];
      if (this.wallJumps > 0 && aboveGround > 0.5) for (const d of dirs) {
        const c = solidAt(this.grid, this.pos.x + d[0] * (R + 0.4), feet + 1.0, this.pos.z + d[1] * (R + 0.4));
        if (c && c.maxY > feet + 1.5) {
          const [nx, nz] = this.faceNormal(c, this.pos.x + d[0] * (R + 0.4), this.pos.z + d[1] * (R + 0.4));
          this.wallKick(nx, nz, 'wallkick'); return;
        }
      }
    }
    if (aboveGround < 0.8 || this.vel.y < -14) return;
    if (spd >= 5 && inp.f > 0.2 && has) {
      const vx = this.vel.x / spd, vz = this.vel.z / spd;
      for (const sg of [1, -1]) {
        const rx = -vz * sg, rz = vx * sg; // lado
        const qx = this.pos.x + rx * (R + 0.3), qz = this.pos.z + rz * (R + 0.3);
        const c = solidAt(this.grid, qx, feet + 1.0, qz);
        if (!c || c.maxY < feet + 1.8) continue;
        const c2 = solidAt(this.grid, qx + vx * 0.9, feet + 1.0, qz + vz * 0.9);
        if (!c2) continue;
        const [nx, nz] = this.faceNormal(c, qx, qz);
        if (-(nx * rx + nz * rz) < 0.6 || Math.abs(nx * vx + nz * vz) > 0.6) continue;
        if (c === this.wr.col && this.wallJumps === 3 && false) continue;
        let tx = vx - (vx * nx + vz * nz) * nx, tz = vz - (vx * nx + vz * nz) * nz; const tl = Math.hypot(tx, tz) || 1; tx /= tl; tz /= tl;
        this.wr = { nx, nz, tx, tz, kind: 'side', speed: Math.max(spd, 8), col: c };
        this.state = 'wallrun'; this.wallT = 0; this.wallLost = 0; this.wallSide = sg;
        this.vel.x = tx * this.wr.speed; this.vel.z = tz * this.wr.speed; this.vel.y = Math.max(this.vel.y * 0.3, 2.2);
        this.peakY = this.pos.y; this.wallJumps = Math.max(this.wallJumps, 2); this.onEvent('wallrun', { side: sg }); return;
      }
    }
    // correr para cima na parede
    if (inp.f > 0.2 && inp.jump && this.vel.y > -4 && spd > 2.5) {
      const c = solidAt(this.grid, this.pos.x + fwd.x * (R + 0.35), feet + 1.0, this.pos.z + fwd.z * (R + 0.35));
      if (c && c.maxY > feet + 2.9) {
        const [nx, nz] = this.faceNormal(c, this.pos.x + fwd.x * (R + 0.35), this.pos.z + fwd.z * (R + 0.35));
        if (-(nx * fwd.x + nz * fwd.z) > 0.7) {
          this.wr = { nx, nz, tx: 0, tz: 0, kind: 'up', speed: spd, col: c };
          this.state = 'wallrun'; this.wallT = 0; this.wallLost = 0; this.wallSide = 0; this.vel.set(0, Math.max(6.5, this.vel.y), 0);
          this.peakY = this.pos.y; this.onEvent('wallrun', { side: 0, up: true });
        }
      }
    }
  }
  private wallKick(nx: number, nz: number, ev: PEvent) {
    const fwd = this.fwd; const sp = Math.hypot(this.vel.x, this.vel.z);
    this.vel.x = nx * 5.6 + fwd.x * Math.max(2.5, sp * 0.3); this.vel.z = nz * 5.6 + fwd.z * Math.max(2.5, sp * 0.3); this.vel.y = 9.2;
    this.wallJumps--; this.wallCd = 0.3; this.jumpBuf = 0; this.state = 'air'; this.lastWallJump = 0.3; this.justJumped = 0.15; this.peakY = this.pos.y;
    this.onEvent(ev === 'wallkick' ? 'walljump' : ev, { kick: true });
  }
  private stepWallrun(h: number, inp: Input) {
    this.wallT += h; const T = this.perks.wallRunTime, wr = this.wr; this.sprinting = false;
    this.stamina = Math.max(0, this.stamina - 3 * h);
    const feet = this.pos.y;
    if (wr.kind === 'side') {
      const rx = -wr.nx, rz = -wr.nz; const qx = this.pos.x + rx * (R + 0.3), qz = this.pos.z + rz * (R + 0.3);
      const c = solidAt(this.grid, qx, feet + 1.0, qz);
      this.wallLost = c ? 0 : this.wallLost + h;
      const u = this.wallT / T; const g = G * (0.12 + 0.55 * u * u);
      this.vel.y -= g * h; wr.speed = Math.max(7, wr.speed - 0.4 * h);
      this.vel.x = wr.tx * wr.speed + rx * 1.8; this.vel.z = wr.tz * wr.speed + rz * 1.8;
      this.armPose.reach = 1;
      if (this.jumpBuf > 0) {
        const fwd = this.fwd; const look = Math.max(0, fwd.x * wr.tx + fwd.z * wr.tz);
        this.vel.x = wr.nx * 5.4 + wr.tx * wr.speed * (0.8 + 0.15 * look); this.vel.z = wr.nz * 5.4 + wr.tz * wr.speed * (0.8 + 0.15 * look); this.vel.y = 9.3;
        this.state = 'air'; this.wallCd = 0.35; this.jumpBuf = 0; this.lastWallJump = 0.3; this.justJumped = 0.15; this.wallJumps = Math.max(2, this.wallJumps); this.peakY = this.pos.y;
        this.onEvent('walljump', { speed: wr.speed }); return;
      }
      if (this.wallT > T || this.wallLost > 0.15 || inp.crouch || inp.f < 0.1) { this.state = 'air'; this.wallCd = 0.4; this.vel.x += 0; return; }
    } else {
      const u = this.wallT / 0.9; this.vel.set(-wr.nx * 1.2, Math.max(0, 7.2 * (1 - u)), -wr.nz * 1.2);
      const fwd = this.fwd; const lg = this.probeLedge(fwd.x, fwd.z, 0.9, 2.45);
      if (lg) { this.startHang(lg); return; }
      if (this.jumpBuf > 0) { this.wallKick(wr.nx, wr.nz, 'walljump'); return; }
      if (u >= 1 || !inp.jump) { this.state = 'air'; this.wallCd = 0.4; this.vel.set(wr.nx * 1.5, 0, wr.nz * 1.5); return; }
    }
    this.collideMove(h);
    if (this.grounded) { this.state = 'ground'; this.onLandSoft(); }
    this.peakY = this.pos.y;
  }

  // ---------- balanço
  private startSwing(b: Bar) {
    this.state = 'swing'; this.swingBar = b; const q = b.axis === 0 ? this.pos.z - b.z : this.pos.x - b.x; const vq = b.axis === 0 ? this.vel.z : this.vel.x;
    this.swingTheta = Math.max(-0.7, Math.min(0.7, q / 2.2)); this.swingOmega = Math.max(-6, Math.min(6, vq / 2.2));
    if (Math.abs(this.swingOmega) < 0.8) { const f = this.fwd; this.swingOmega = (b.axis === 0 ? f.z : f.x) * 1.4; }
    this.vel.set(0, 0, 0); this.peakY = this.pos.y; this.wallJumps = 3; this.onEvent('swing');
  }
  private stepSwing(h: number, inp: Input) {
    const b = this.swingBar!; const L = 2.2; this.sprinting = false;
    const lk = this.fwd; const lookQ = b.axis === 0 ? lk.z : lk.x;
    let a = -(G / L) * Math.sin(this.swingTheta) - 0.12 * this.swingOmega;
    const dirSign = Math.abs(this.swingOmega) > 0.4 ? Math.sign(this.swingOmega) : Math.sign(lookQ);
    if (inp.f > 0.2) a += 7.5 * dirSign * inp.f; else if (inp.f < -0.2) a -= 3.5 * this.swingOmega * -inp.f;
    this.swingOmega += a * h; this.swingTheta += this.swingOmega * h;
    if (Math.abs(this.swingTheta) > 1.4) { this.swingTheta = Math.sign(this.swingTheta) * 1.4; this.swingOmega *= -0.4; }
    const along = (b.axis === 0 ? this.pos.x : this.pos.z) + inp.s * 2.4 * h * (b.axis === 0 ? 1 : -1);
    const ac = Math.max(-b.half + 0.3, Math.min(b.half - 0.3, along - (b.axis === 0 ? b.x : b.z)));
    if (b.axis === 0) { this.pos.x = b.x + ac; this.pos.z = b.z + L * Math.sin(this.swingTheta); }
    else { this.pos.z = b.z + ac; this.pos.x = b.x + L * Math.sin(this.swingTheta); }
    this.pos.y = b.y - L * Math.cos(this.swingTheta) - 0.0; this.armPose.reach = 2;
    if (!inp.jump || inp.crouch) {
      const vq = L * this.swingOmega * Math.cos(this.swingTheta), vy = L * this.swingOmega * Math.sin(this.swingTheta);
      this.vel.set(b.axis === 0 ? 0 : vq * 1.12, Math.max(vy, 0) * 1.0 + 3.5 + Math.abs(vq) * 0.15, b.axis === 0 ? vq * 1.12 : 0);
      const hs = Math.hypot(this.vel.x, this.vel.z); if (hs < 4) { this.vel.x += lk.x * (4 - hs); this.vel.z += lk.z * (4 - hs); }
      this.state = 'air'; this.barCd = 0.5; this.justJumped = 0.1; this.swingBar = null; this.peakY = this.pos.y; this.onEvent('swingrelease', { speed: hs });
    }
  }

  // ===================================================== colisão
  private collideMove(h: number) {
    this.moveAxis(0, this.vel.x * h); this.moveAxis(1, this.vel.z * h);
    this.moveY(h);
  }
  private moveAxis(axis: 0 | 1, delta: number) {
    if (delta === 0) return;
    if (axis === 0) this.pos.x += delta; else this.pos.z += delta;
    const p = this.pos; this.grid.query(p.x - R - 0.02, p.x + R + 0.02, p.z - R - 0.02, p.z + R + 0.02, this.list);
    for (let i = 0; i < this.list.length; i++) {
      const c = this.list[i]; if (!overlapXZ(c, p.x, p.z, R)) continue;
      const top = topUnder(c, p.x, p.z, R); const feet = p.y;
      if (top <= feet + 0.001 || c.minY >= feet + this.hgt - 0.001) continue;
      const rise = top - feet;
      if (rise <= STEP && (this.grounded || (this.vel.y <= 0.5 && rise <= 0.3))) {
        if (!boxBlocked(this.grid, p.x, p.z, R * 0.8, top + 0.02, top + this.hgt - 0.05)) { p.y = top; this.grounded = true; if (this.vel.y < 0) this.vel.y = 0; continue; }
      }
      if (axis === 0) { if (delta > 0) p.x = c.minX - R - 0.001; else p.x = c.maxX + R + 0.001; if (this.state !== 'wallrun') this.vel.x = 0; else this.vel.x *= 0.2; }
      else { if (delta > 0) p.z = c.minZ - R - 0.001; else p.z = c.maxZ + R + 0.001; if (this.state !== 'wallrun') this.vel.z = 0; else this.vel.z *= 0.2; }
      if (this.state === 'air' && Math.abs(delta) / 0.011 > 6) this.shake = Math.max(this.shake, 0.01);
    }
  }
  private moveY(h: number) {
    const p = this.pos; const prevFeet = p.y; const wasGrounded = this.grounded; const vy = this.vel.y;
    p.y += vy * h; this.grounded = false;
    if (vy > 0) {
      this.grid.query(p.x - R, p.x + R, p.z - R, p.z + R, this.list);
      for (let i = 0; i < this.list.length; i++) {
        const c = this.list[i]; if (c.slope || c.minY < 0.05 || !overlapXZ(c, p.x, p.z, R)) continue;
        if (c.minY >= prevFeet + this.hgt - 0.08 && p.y + this.hgt > c.minY) { p.y = c.minY - this.hgt; this.vel.y = 0; this.onEvent('bump'); this.shake = Math.max(this.shake, 0.03); }
      }
    }
    if (this.vel.y <= 0.01) {
      const gb = groundBelow(this.grid, p.x, p.z, R, prevFeet + 0.05, this.gh);
      if (p.y <= gb.y + 0.0005) { p.y = gb.y; this.grounded = true; this.groundCol = gb.c; this.surf = gb.c ? gb.c.surf : 0; this.lastImpact = this.vel.y; this.vel.y = 0; }
      else if (wasGrounded && this.justJumped <= 0 && p.y - gb.y <= 0.5) { p.y = gb.y; this.grounded = true; this.groundCol = gb.c; this.surf = gb.c ? gb.c.surf : 0; this.lastImpact = 0; this.vel.y = 0; }
    }
    if (p.y < 0) { p.y = 0; this.grounded = true; this.vel.y = Math.max(0, this.vel.y); }
  }
  lastImpact = 0;

  private onLandSoft() { this.peakY = this.pos.y; this.wallJumps = 3; }
  private onLand(inp: Input) {
    const fall = this.peakY - this.pos.y; const impact = -this.lastImpact; const sp = Math.hypot(this.vel.x, this.vel.z);
    this.lastLandSpeed = sp; this.peakY = this.pos.y; this.wallJumps = 3; this.airTime = 0;
    if (this.state === 'wallrun') this.state = 'ground';
    this.landDip = Math.min(0.55, impact * 0.022); this.shake = Math.max(this.shake, Math.min(0.2, impact * 0.006));
    const timed = this.crouchBuf > 0 || inp.crouch; const fwd = inp.f > 0.2;
    if (fall < 3) { this.state = this.state === 'slide' ? 'slide' : 'ground'; this.onEvent('land', { fall, impact, soft: true }); return; }
    if (fall < 6) {
      this.state = 'ground'; this.onEvent('land', { fall, impact });
      if (timed) { this.onEvent('perfect', { fall }); if (sp > 6 && inp.crouch) { this.startSlide(inp); } }
      return;
    }
    const dir = sp > 1 ? this._t.set(this.vel.x / sp, 0, this.vel.z / sp) : this.fwd;
    if (timed && fall < TUNE.FATAL_ROLL) { this.startRoll(dir, true, Math.max(sp, 6.5)); this.onEvent('land', { fall, impact }); this.onEvent('roll', { fall, perfect: true }); this.onEvent('perfect', { fall }); return; }
    if (fwd && fall < TUNE.FATAL_AUTOROLL) { this.startRoll(this.fwd, false, Math.max(sp, 6)); this.onEvent('land', { fall, impact }); this.onEvent('roll', { fall, perfect: false }); return; }
    if (fall >= TUNE.FATAL_FALL) { this.onEvent('land', { fall, impact }); this.onEvent('fatal', { fall }); return; }
    if (fall >= 14) { this.state = 'stagger'; this.staggerT = 0.7; this.vel.x *= 0.1; this.vel.z *= 0.1; this.onEvent('land', { fall, impact }); this.onEvent('stagger', { fall }); this.shake = 0.25; return; }
    this.state = 'ground'; this.vel.x *= 0.45; this.vel.z *= 0.45; this.mom = 0; this.onEvent('land', { fall, impact }); this.onEvent('heavy', { fall });
  }
  private startRoll(dir: THREE.Vector3, perfect: boolean, speed: number) {
    this.state = 'roll'; this.rollT = 0; this.rollPerfect = perfect; this.rollDir.set(dir.x, 0, dir.z).normalize(); this.lastLandSpeed = speed; this.hgt = 1.0; this.crouching = false;
  }

  // ===================================================== câmera
  updateCamera(dt: number, inp: Input) {
    const spd = this.speedH; const k = (r: number) => 1 - Math.exp(-r * dt);
    // altura do olho
    const tgtEye = this.state === 'slide' ? 0.75 : this.state === 'roll' ? 0.9 : this.state === 'stagger' ? 1.0 : this.crouching ? 0.9 : this.state === 'hang' ? 1.7 : 1.65;
    this.eye += (tgtEye - this.eye) * k(this.state === 'slide' ? 18 : 12);
    // bob
    let bobY = 0, bobX = 0, bobRoll = 0;
    const running = this.grounded && (this.state === 'ground') && spd > 1.5;
    if (running) {
      this.bobPhase += dt * (spd * 0.95 + 3.5); const a = Math.min(1, spd / 11) * (this.sprinting ? 1 : 0.55);
      bobY = Math.sin(this.bobPhase * 2) * 0.05 * a; bobX = Math.cos(this.bobPhase) * 0.035 * a; bobRoll = Math.cos(this.bobPhase) * 0.006 * a;
    }
    this.landDip *= Math.exp(-7 * dt);
    this.shake *= Math.exp(-6 * dt);
    this.fovExtraKick *= Math.exp(-3 * dt);
    // roll alvo
    let tr = -inp.s * 0.03 * Math.min(1, spd / 8);
    if (this.state === 'wallrun') tr = this.wr.kind === 'side' ? this.wallSide * 0.24 : 0;
    if (this.state === 'slide') tr += 0.05;
    if (this.state === 'mantle' && this.mantleKind === 'vault') tr += Math.sin(Math.PI * Math.min(1, this.mantleU)) * 0.06;
    this.camRoll += (tr - this.camRoll) * k(8);
    // somersault
    let spin = 0, dipExtra = 0;
    if (this.state === 'roll') { const u = Math.min(1, this.rollT / 0.6), e = u * u * (3 - 2 * u); spin = -(Math.PI * 2) * e; dipExtra = Math.sin(Math.PI * u) * 0.5; }
    let mDip = 0, mPitch = 0;
    if (this.state === 'mantle') { const u = Math.min(1, this.mantleU); mDip = Math.sin(Math.PI * u) * (this.mantleKind === 'vault' ? 0.25 : 0.45); mPitch = -Math.sin(Math.PI * u) * 0.12; }
    this.camPitchOff = spin + mPitch + this.landDip * 0.25;
    const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    const sh = this.shake; const rnd = () => (Math.random() - 0.5) * sh;
    this.camPos.set(this.pos.x + rx * bobX + rnd(), this.pos.y + this.eye + bobY - this.landDip - dipExtra - mDip + rnd(), this.pos.z + rz * bobX + rnd());
    this.camRoll += bobRoll * 0.0;
    this.fovExtra += ((Math.min(24, Math.max(0, (spd - 6) * 1.6)) + this.fovExtraKick + (this.state === 'wallrun' ? 4 : 0)) - this.fovExtra) * k(4);
    // pose dos braços
    this.armPose.pump = running ? Math.min(1, spd / 10) : 0;
    if (this.state !== 'wallrun' && this.state !== 'swing') this.armPose.reach = this.state === 'hang' || this.state === 'mantle' ? 3 : this.state === 'air' ? 0.5 : this.state === 'slide' ? 4 : 0;
  }
}
