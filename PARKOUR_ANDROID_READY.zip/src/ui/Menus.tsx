import { useEffect, useRef, useState } from 'react';
import type { Engine } from '../game/engine';
import { DEFS, MOVE_NAMES } from '../game/challenges';
import { useStore, t, levelProgress, fmtTime, UNLOCK_TEXT } from '../game/store';
import { REGION_NAMES } from '../game/world';
import { Icon, Medal, MEDAL_COL, MEDAL_NAME, BackBtn, Title, Btn, fmtNum } from './common';

export type Screen = 'main' | 'challenges' | 'map' | 'custom' | 'settings' | 'stats' | 'exit';

export function Stats({ compact = false }: { compact?: boolean }) {
  const { save } = useStore(); const s = save.stats; const km = s.distance >= 1000 ? (s.distance / 1000).toFixed(2) + ' km' : Math.round(s.distance) + ' m';
  const h = Math.floor(s.playTime / 3600), m = Math.floor((s.playTime % 3600) / 60), sec = Math.floor(s.playTime % 60);
  const rows: [string, string][] = [['Distância', km], ['Saltos', fmtNum(s.jumps)], ['Wall runs', fmtNum(s.wallruns)], ['Wall jumps', fmtNum(s.walljumps)], ['Vaults', fmtNum(s.vaults)], ['Slides', fmtNum(s.slides)], ['Rolamentos', fmtNum(s.rolls)], ['Escaladas', fmtNum(s.climbs)],
    ['Balanços', fmtNum(s.swings)], ['Quedas fatais', fmtNum(s.deaths)], ['Tempo de jogo', `${h ? h + 'h ' : ''}${m}m ${sec}s`], ['Melhor combo', 'x' + Math.min(10, 1 + Math.floor(s.bestCombo / 3))], ['Velocidade máx.', Math.round(s.bestSpeed) + ' km/h'], ['Moedas', fmtNum(s.coins)], ['Pontuação total', fmtNum(s.totalScore)]];
  return <div className={`grid ${compact ? 'grid-cols-2 gap-x-8' : 'grid-cols-2 gap-x-10'} gap-y-1 text-[19px]`}>{rows.map(([a, b]) => <div key={a} className="flex justify-between border-b border-white/10 py-1"><span className="text-white/70">{t(a)}</span><span className="font-bold text-[#ffc400]">{b}</span></div>)}</div>;
}

export function MainMenu({ engine, go }: { engine: Engine; go: (s: Screen) => void }) {
  const { save } = useStore(); const lp = levelProgress(save.xp); const has = !!save.checkpoint;
  const items: { icon: string; label: string; fn: () => void }[] = [
    { icon: 'play', label: 'JOGAR', fn: () => engine.play() }, { icon: 'trophy', label: 'DESAFIOS', fn: () => go('challenges') }, { icon: 'pin', label: 'MAPA', fn: () => go('map') },
    { icon: 'shirt', label: 'PERSONALIZAÇÃO', fn: () => go('custom') }, { icon: 'gear', label: 'CONFIGURAÇÕES', fn: () => go('settings') }, { icon: 'exit', label: 'SAIR', fn: () => go('exit') },
  ];
  const [hover, setHover] = useState(0);
  return (
    <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(90deg, rgba(0,0,0,.78) 0%, rgba(0,0,0,.35) 38%, transparent 62%)' }}>
      <div className="absolute left-[56px] top-[34px] pointer-events-auto">
        <div className="title-wrap"><div className="font-title brush text-white" style={{ fontSize: 'clamp(90px, 15vh, 150px)', lineHeight: 0.95 }}>PARKOUR</div></div>
        <div className="mt-[5vh] flex flex-col gap-[2px]">
          {items.map((it, i) => (
            <div key={it.label} className={`menu-item ${hover === i ? 'active' : ''}`} onMouseEnter={() => { setHover(i); engine.audio.ui(); }} onClick={() => { engine.audio.init(); engine.audio.ui(); it.fn(); }}>
              <Icon n={it.icon} fill={it.icon === 'play'} />{t(it.label === 'JOGAR' && has ? 'JOGAR' : it.label)}
              {it.label === 'JOGAR' && has && <span className="ml-auto text-[13px] opacity-80 chip">CHECKPOINT</span>}
            </div>
          ))}
        </div>
      </div>
      <div className="absolute top-5 right-6 text-right pointer-events-auto cursor-pointer" onClick={() => go('stats')}>
        <div className="text-[#ffc400] text-[26px] font-bold">{t('Nível')} {lp.level}</div>
        <div className="w-[200px] h-[6px] bg-white/20 ml-auto"><div className="h-full bg-[#ffc400]" style={{ width: `${lp.pct * 100}%` }} /></div>
        <div className="text-[14px] text-white/70 mt-1">{lp.level >= 10 ? 'MAX' : `${lp.cur}/${lp.need} XP`} · {t('ESTATÍSTICAS')}</div>
        {save.freeRoam && <div className="chip mt-2 text-[#6dff8a]">{t('MODO LIVRE')}</div>}
      </div>
      <div className="absolute right-10 bottom-[84px] flex items-center gap-3 text-white/90"><Icon n="crown" className="w-9 h-9 text-white" /><span className="text-[15px] tracking-widest font-bold">LORD DEVELOPER</span></div>
      <div className="absolute right-10 bottom-8 font-title italic text-[44px] brush text-white">{t('DOMINE A CIDADE!')}</div>
    </div>
  );
}

const REG_COL = ['#7a5a45', '#5b6670', '#8a8a82', '#2f4a68', '#3a4b63', '#555'];
export function DetailPanel({ engine, id, onStart }: { engine: Engine; id: string; onStart: () => void }) {
  const { save } = useStore(); const d = DEFS.find((x) => x.id === id)!; const r = engine.resolved[id]; const unlocked = engine.isUnlocked(id); const rec = save.medals[id]; const rank = save.ranking[id] || [];
  const nr = d.region >= 0 ? REGION_NAMES[d.region] : 'Todas as regiões';
  const need = d.id === 'final' ? 'Complete todos os desafios principais' : `${t('Nível')} ${d.minLevel}`;
  return (
    <div className="panel p-5 w-[400px] anim-slide flex flex-col gap-3 max-h-[84vh] overflow-auto scroll">
      <div className="thumb !w-full !h-[120px] text-[60px]" style={{ background: `linear-gradient(135deg, ${REG_COL[Math.max(0, d.region)]}, #0b0e13)` }}>{d.icon}<div className="absolute bottom-1 left-2 text-[14px] chip">{t('Região')}: {nr}</div></div>
      <div className="font-title text-[34px] leading-none text-white uppercase">{t(d.name)}</div>
      <div className="text-[18px] text-white/80 leading-tight font-medium">{t(d.desc)}</div>
      <div><div className="text-[#ffc400] font-bold uppercase text-[16px]">{t('Desafios')}:</div>{d.goals.map((g) => <div key={g} className="flex gap-2 items-center text-[17px]"><Icon n="star" className="w-4 h-4 text-[#ffc400]" fill />{t(g)}</div>)}</div>
      <div className="grid grid-cols-3 gap-2">{[3, 2, 1].map((m, i) => <div key={m} className="bg-white/5 p-2 flex flex-col items-center"><Medal m={m} size={28} /><div className="text-[13px] opacity-70 mt-1">{MEDAL_NAME[m]}</div><div className="font-bold text-[17px]" style={{ color: MEDAL_COL[m] }}>≤ {fmtTime(r.times[i])}</div></div>)}</div>
      {rec && <div className="flex items-center gap-3 bg-white/5 p-2"><Medal m={rec.medal} size={30} /><div><div className="text-[14px] opacity-70">{t('Melhores tempos')}</div><div className="font-bold text-[20px]">{fmtTime(rec.time)} · {fmtNum(rec.score)} pts</div></div></div>}
      {rank.length > 0 && <div><div className="text-[15px] text-white/60 uppercase">{t('Ranking')}</div>{rank.map((x, i) => <div key={i} className="flex justify-between text-[16px] border-b border-white/10"><span>#{i + 1} {fmtTime(x.time)}</span><span className="text-[#ffc400]">{fmtNum(x.score)}</span></div>)}</div>}
      <div className="flex items-center justify-between mt-1">
        {unlocked ? <span className="chip text-[#6dff8a]">XP +{d.xp}</span> : <span className="chip text-red-300 flex items-center gap-1"><Icon n="lock" className="w-3 h-3" />{t('Bloqueado')}: {need}</span>}
        <Btn y disabled={!unlocked} onClick={onStart}><Icon n="play" className="w-4 h-4" fill />{t('INICIAR DESAFIO')}</Btn>
      </div>
    </div>
  );
}

export function ChallengesScreen({ engine, back, sel, setSel }: { engine: Engine; back: () => void; sel: string; setSel: (s: string) => void }) {
  const { save } = useStore();
  const list = DEFS.filter((d) => d.id !== 'final' || engine.allMainDone() || save.finalDone);
  return (
    <div className="absolute inset-0 flex" style={{ background: 'linear-gradient(90deg, rgba(0,0,0,.88) 0, rgba(0,0,0,.6) 34%, transparent 62%)' }}>
      <div className="w-[560px] h-full p-6 flex flex-col">
        <Title icon="trophy">{t('DESAFIOS')}</Title>
        <div className="mt-4 flex-1 overflow-auto scroll pr-2">
          {list.map((d) => { const m = save.medals[d.id]?.medal || 0; const un = engine.isUnlocked(d.id); return (
            <div key={d.id} className={`ch-row ${sel === d.id ? 'active' : ''}`} onClick={() => { setSel(d.id); engine.audio.ui(); }}>
              <div className="thumb" style={{ background: `linear-gradient(135deg, ${REG_COL[Math.max(0, d.region)]}, #0b0e13)`, filter: un ? 'none' : 'grayscale(1) brightness(.6)' }}>{d.icon}</div>
              <div className="flex-1 min-w-0"><div className="text-[22px] font-bold leading-tight truncate">{t(d.name)}</div><div className="text-[15px] text-white/60 leading-tight truncate">{un ? t(d.goals[0]) : `${t('Bloqueado')} · ${d.id === 'final' ? '★' : t('Nível') + ' ' + d.minLevel}`}</div></div>
              <Medal m={m} size={40} locked={!un} />
            </div>); })}
        </div>
        <div className="pt-3"><BackBtn onClick={back} /></div>
      </div>
      <div className="flex-1 flex items-center justify-end pr-8"><DetailPanel engine={engine} id={sel} onStart={() => engine.play(sel)} /></div>
    </div>
  );
}

export function MapScreen({ engine, back, sel, setSel }: { engine: Engine; back: () => void; sel: string; setSel: (s: string) => void }) {
  const { save } = useStore(); const ref = useRef<HTMLCanvasElement>(null); const [size, setSize] = useState(620);
  useEffect(() => { const f = () => setSize(Math.max(380, Math.min(680, window.innerHeight - 190, window.innerWidth * 0.55))); f(); window.addEventListener('resize', f); return () => window.removeEventListener('resize', f); }, []);
  const toPx = (x: number, z: number) => [((x + 320) / 640) * size, ((z + 320) / 640) * size];
  useEffect(() => {
    const c = ref.current!, g = c.getContext('2d')!; c.width = size; c.height = size; g.drawImage(engine.mapCanvas, 0, 0, size, size);
    g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, 0, size, size);
    g.font = `700 ${Math.round(size / 42)}px 'Barlow Condensed', sans-serif`; g.textAlign = 'center'; g.fillStyle = 'rgba(255,255,255,.35)';
    ([[-160, -160, 0], [160, -160, 1], [160, 160, 2], [-160, 160, 3], [0, 0, 4]] as [number, number, number][]).forEach(([x, z, r]) => { const [px, py] = toPx(x, z); g.fillText(REGION_NAMES[r].toUpperCase(), px, py); });
    for (const cp of engine.world.cps) { const [px, py] = toPx(cp.x, cp.z); g.fillStyle = save.checkpoint && cp.id <= save.checkpoint.id ? '#6dff8a' : '#7fb4d8'; g.beginPath(); g.arc(px, py, 3, 0, 7); g.fill(); }
    for (const d of DEFS) {
      const s = engine.resolved[d.id].start, [px, py] = toPx(s.x, s.z), m = save.medals[d.id]?.medal || 0, un = engine.isUnlocked(d.id), r = size / 36;
      if (d.id === sel) { g.strokeStyle = '#ff2a2a'; g.lineWidth = 3; g.beginPath(); g.arc(px, py, r + 6, 0, 7); g.stroke(); g.fillStyle = 'rgba(255,40,40,.25)'; g.beginPath(); g.arc(px, py, r + 6, 0, 7); g.fill(); }
      g.fillStyle = !un ? '#555' : m === 3 ? '#ffc400' : m > 0 ? '#2ecc71' : '#fff'; g.beginPath(); g.arc(px, py, r, 0, 7); g.fill(); g.strokeStyle = '#000'; g.lineWidth = 2; g.stroke();
      g.fillStyle = '#111'; g.font = `800 ${Math.round(r * 1.2)}px sans-serif`; g.fillText(m > 0 ? '✓' : un ? '★' : '🔒', px, py + r * 0.4);
    }
    const P = engine.player; const [qx, qy] = toPx(P.pos.x, P.pos.z); g.save(); g.translate(qx, qy); g.rotate(-P.yaw); g.fillStyle = '#ffc400'; g.beginPath(); g.moveTo(0, -9); g.lineTo(6, 8); g.lineTo(0, 4); g.lineTo(-6, 8); g.closePath(); g.fill(); g.strokeStyle = '#000'; g.lineWidth = 1.5; g.stroke(); g.restore();
  }, [engine, size, sel, save]);
  const click = (e: React.MouseEvent) => {
    const rc = ref.current!.getBoundingClientRect(); const x = (e.clientX - rc.left) / rc.width * 640 - 320, z = (e.clientY - rc.top) / rc.height * 640 - 320; let best = '', bd = 18;
    for (const d of DEFS) { const s = engine.resolved[d.id].start; const dd = Math.hypot(s.x - x, s.z - z); if (dd < bd) { bd = dd; best = d.id; } }
    if (best) { setSel(best); engine.audio.ui(); }
  };
  return (
    <div className="absolute inset-0 flex items-center justify-center gap-6 p-6" style={{ background: 'rgba(0,0,0,.55)' }}>
      <div className="panel p-4"><Title icon="pin">{t('MAPA')}</Title>
        <canvas ref={ref} onClick={click} className="mt-3 cursor-pointer border border-white/10" style={{ width: size, height: size }} />
        <div className="flex gap-4 mt-3 text-[14px] text-white/70"><span>★ {t('Desafios')}</span><span className="text-[#7fb4d8]">● Checkpoint</span><span className="text-[#6dff8a]">● Checkpoint ativo</span></div>
        <div className="mt-2"><BackBtn onClick={back} /></div></div>
      <DetailPanel engine={engine} id={sel} onStart={() => engine.play(sel)} />
    </div>
  );
}

export function ExitScreen({ back }: { back: () => void }) {
  return <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 bg-black/90"><div className="font-title brush text-[90px]">PARKOUR</div><div className="text-2xl text-white/80">Obrigado por jogar! Seu progresso foi salvo automaticamente.</div><div className="text-white/50">Você pode fechar esta aba com segurança.</div><Btn y onClick={back}><Icon n="back" />{t('VOLTAR')}</Btn></div>;
}
export { UNLOCK_TEXT, MOVE_NAMES };
