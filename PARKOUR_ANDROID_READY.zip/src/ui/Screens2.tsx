import { useEffect, useState } from 'react';
import type { Engine, ResultData } from '../game/engine';
import { useStore, t, setSettings, mutateSave, levelFor, OUTFITS, COLORS, GLOVES, SHOES, ACCS, FX, Item, Cosmetics, UNLOCK_TEXT, ACTIONS, ACTION_LABEL, DEFAULT_KEYS, keyLabel, Action, fmtTime, resetSave } from '../game/store';
import { Icon, Title, BackBtn, Btn, Medal, MEDAL_NAME, MEDAL_COL, fmtNum } from './common';
import { Stats } from './Menus';

// ------------------------------------------------------------------ personalização
export function CustomScreen({ engine, back }: { engine: Engine; back: () => void }) {
  const { save } = useStore(); const lvl = levelFor(save.xp); const [tab, setTab] = useState(0); const [draft, setDraft] = useState<Cosmetics>({ ...save.cosmetics });
  const tabs: { k: keyof Cosmetics; l: string; list: Item[] }[] = [{ k: 'outfit', l: 'ROUPA', list: OUTFITS }, { k: 'color', l: 'COR', list: COLORS }, { k: 'gloves', l: 'LUVAS', list: GLOVES }, { k: 'shoes', l: 'CALÇADOS', list: SHOES }, { k: 'acc', l: 'ACESSÓRIOS', list: ACCS }, { k: 'fx', l: 'EFEITOS', list: FX }];
  useEffect(() => () => engine.applyCosmetics(), [engine]);
  const pick = (k: keyof Cosmetics, it: Item) => { if (it.lvl > lvl) return; const nd = { ...draft, [k]: it.id }; setDraft(nd); engine.previewChar.setCosmetics(nd); engine.audio.ui(); };
  const apply = () => { mutateSave((s) => { s.cosmetics = { ...draft }; }); engine.applyCosmetics(); engine.audio.checkpoint(); back(); };
  const cur = tabs[tab];
  const nextUnlock = Object.keys(UNLOCK_TEXT).map(Number).find((l) => l > lvl);
  return (
    <div className="absolute inset-0" style={{ background: 'linear-gradient(270deg, rgba(0,0,0,.88) 0, rgba(0,0,0,.6) 45%, transparent 65%)' }}>
      <div className="absolute left-6 top-6"><Title icon="shirt">{t('PERSONALIZAÇÃO')}</Title></div>
      <div className="absolute right-8 top-1/2 -translate-y-1/2 panel p-5 w-[min(640px,52vw)] anim-slide">
        <div className="flex flex-wrap border-b border-white/10 mb-4">{tabs.map((x, i) => <div key={x.k} className={`tab-y ${tab === i ? 'active' : ''}`} onClick={() => setTab(i)}>{t(x.l)}</div>)}</div>
        <div className="grid grid-cols-4 gap-3">
          {cur.list.map((it) => {
            const locked = it.lvl > lvl; const on = draft[cur.k] === it.id;
            const bg = cur.k === 'fx' ? `linear-gradient(135deg,#${it.color.toString(16).padStart(6, '0')},#${(it.color2 ?? it.color).toString(16).padStart(6, '0')})` : it.color ? `#${it.color.toString(16).padStart(6, '0')}` : '#222';
            return <div key={it.id} className={`card ${on ? 'sel-c' : ''} ${locked ? 'locked' : ''}`} onClick={() => pick(cur.k, it)}>
              <div className="absolute inset-x-3 top-3 bottom-12 rounded-sm flex items-center justify-center text-3xl text-white/40" style={{ background: bg, boxShadow: 'inset 0 0 20px rgba(0,0,0,.5)' }}>{it.color === 0 && '∅'}</div>
              <div className="relative text-[15px] font-bold text-center leading-tight">{it.name}</div>
              {locked && <div className="absolute top-1 right-1 chip flex items-center gap-1"><Icon n="lock" className="w-3 h-3" />{t('Nível')} {it.lvl}</div>}
              {on && <div className="absolute top-1 left-1 bg-[#ffc400] text-black rounded-full w-5 h-5 flex items-center justify-center"><Icon n="check" className="w-3 h-3" /></div>}
            </div>;
          })}
        </div>
        <div className="flex items-center justify-between mt-5"><div className="text-[15px] text-white/60 max-w-[300px]">{t('Nível')} {lvl}{nextUnlock ? ` · ${t('Nível')} ${nextUnlock}: ${UNLOCK_TEXT[nextUnlock]}` : ''}</div><Btn y onClick={apply}><Icon n="check" className="w-5 h-5" />{t('APLICAR')}</Btn></div>
      </div>
      <div className="absolute left-6 bottom-6"><BackBtn onClick={back} /></div>
    </div>
  );
}

// ------------------------------------------------------------------ configurações
function Row({ label, children }: { label: string; children: React.ReactNode }) { return <div className="row"><span>{t(label)}</span><div className="flex items-center gap-3">{children}</div></div>; }

export function ControlsList({ editable = false }: { editable?: boolean }) {
  const { settings } = useStore(); const [listen, setListen] = useState<Action | null>(null);
  useEffect(() => {
    if (!listen) return; const h = (e: KeyboardEvent) => { e.preventDefault(); e.stopPropagation(); if (e.code !== 'Escape') { const keys = { ...settings.keys }; keys[listen] = e.code; setSettings({ keys }); } setListen(null); };
    window.addEventListener('keydown', h, true); return () => window.removeEventListener('keydown', h, true);
  }, [listen, settings.keys]);
  const fixed: [string, string][] = [['MOUSE', 'Câmera'], ['ESC', 'Menu'], ['CTRL / C', 'Agachar / Slide'], ['M', 'Minimapa']];
  return <div>
    {ACTIONS.map((a) => <div key={a} className="row"><span>{t(ACTION_LABEL[a])}</span>
      {editable ? <button className={`sel !min-w-[130px] text-center cursor-pointer ${listen === a ? '!border-[#ffc400] text-[#ffc400]' : ''}`} onClick={() => setListen(a)}>{listen === a ? t('Clique e pressione uma tecla…') : keyLabel(settings.keys[a])}</button>
        : <span className="chip !text-[16px] !bg-white/15">{keyLabel(settings.keys[a])}</span>}</div>)}
    {fixed.map(([k, l]) => <div key={k} className="row"><span>{t(l)}</span><span className="chip !text-[16px] !bg-white/15">{k}</span></div>)}
    {editable && <div className="mt-3"><Btn onClick={() => setSettings({ keys: { ...DEFAULT_KEYS } })}><Icon n="refresh" className="w-4 h-4" />{t('Restaurar padrão')}</Btn></div>}
  </div>;
}

export function SettingsScreen({ engine, back, initialTab = 0, overlay = false }: { engine: Engine; back: () => void; initialTab?: number; overlay?: boolean }) {
  const { settings: s } = useStore(); const [tab, setTab] = useState(initialTab);
  const tabs = ['JOGABILIDADE', 'ÁUDIO', 'VÍDEO', 'CONTROLES', 'IDIOMA'];
  const Slider = ({ k, min = 0, max = 1, step = 0.01, pct = false }: { k: keyof typeof s; min?: number; max?: number; step?: number; pct?: boolean }) => <><input type="range" min={min} max={max} step={step} value={s[k] as number} onChange={(e) => setSettings({ [k]: +e.target.value } as any)} /><span className="w-14 text-right text-[16px]">{pct ? Math.round((s[k] as number) * 100) + '%' : (s[k] as number).toFixed(step < 1 ? 2 : 0)}</span></>;
  const Sel = ({ k, opts }: { k: keyof typeof s; opts: [string | number | boolean, string][] }) => <select className="sel" value={String(s[k])} onChange={(e) => { const v = opts.find((o) => String(o[0]) === e.target.value)![0]; setSettings({ [k]: v } as any); }}>{opts.map(([v, l]) => <option key={String(v)} value={String(v)}>{t(l)}</option>)}</select>;
  const Tog = ({ k }: { k: keyof typeof s }) => <Sel k={k} opts={[[true, 'Ativadas'], [false, 'Desativadas']]} />;
  return (
    <div className={`absolute inset-0 flex items-center justify-center ${overlay ? 'bg-black/70' : 'bg-black/55'}`}>
      <div className="panel w-[min(980px,94vw)] h-[min(620px,88vh)] flex flex-col anim-slide">
        <div className="p-5 pb-2"><Title icon="gear">{t('CONFIGURAÇÕES')}</Title></div>
        <div className="flex flex-1 min-h-0">
          <div className="w-[230px] p-4 pt-2 flex flex-col gap-1">{tabs.map((x, i) => <div key={x} className={`side-tab ${tab === i ? 'active' : ''}`} onClick={() => { setTab(i); engine.audio.ui(); }}>{t(x)}</div>)}</div>
          <div className="flex-1 p-4 pt-2 pr-8 overflow-auto scroll">
            {tab === 0 && <>
              <Row label="Sensibilidade do Mouse"><Slider k="sens" min={0.05} max={1} /></Row>
              <Row label="Campo de Visão"><Slider k="fov" min={60} max={110} step={1} /></Row>
              <Row label="Inverter Y"><Tog k="invertY" /></Row>
              <Row label="Minimapa"><Tog k="minimap" /></Row>
              <Row label="Fantasma da melhor corrida"><Tog k="ghost" /></Row>
              <Row label="Clima"><Sel k="weather" opts={[['day', 'Dia'], ['sunset', 'Pôr do sol'], ['night', 'Noite'], ['rain', 'Chuva'], ['fog', 'Neblina']]} /></Row>
              <div className="mt-6"><Btn onClick={() => { if (confirm('Apagar todo o progresso?')) { resetSave(); engine.applyCosmetics(); engine.refreshBeacons(); } }}>{t('Apagar progresso')}</Btn></div>
            </>}
            {tab === 1 && <>
              <Row label="Volume Geral"><Slider k="master" pct /></Row><Row label="Música"><Slider k="music" pct /></Row><Row label="Efeitos Sonoros"><Slider k="sfx" pct /></Row>
            </>}
            {tab === 2 && <>
              <Row label="Qualidade Gráfica"><Sel k="quality" opts={[['low', 'Baixa'], ['medium', 'Média'], ['high', 'Alta'], ['ultra', 'Ultra']]} /></Row>
              <Row label="Resolução"><Sel k="resolution" opts={[['auto', 'Automática'], ['1280x720', '1280x720'], ['1600x900', '1600x900'], ['1920x1080', '1920x1080'], ['2560x1440', '2560x1440']]} /></Row>
              <Row label="Modo de Tela"><Sel k="fullscreen" opts={[[true, 'Tela Cheia'], [false, 'Janela']]} /></Row>
              <Row label="Distância de Visão"><Slider k="viewDist" min={0.2} max={1} pct /></Row>
              <Row label="Sombras"><Tog k="shadows" /></Row>
              <Row label="Limite de FPS"><Sel k="fpsLimit" opts={[[0, 'Ilimitado'], [30, '30'], [60, '60'], [120, '120'], [144, '144']]} /></Row>
            </>}
            {tab === 3 && <ControlsList editable />}
            {tab === 4 && <><Row label="IDIOMA"><Sel k="lang" opts={[['pt', 'Português (Brasil)'], ['en', 'English']]} /></Row></>}
          </div>
        </div>
        <div className="p-4 flex justify-between"><BackBtn onClick={back} /><Btn y onClick={back}><Icon n="check" className="w-5 h-5" />{t('APLICAR')}</Btn></div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ pausa
export function PauseScreen({ engine, onMenu }: { engine: Engine; onMenu: () => void }) {
  const [sub, setSub] = useState<'menu' | 'settings' | 'stats'>('menu'); const run = engine.run;
  if (sub === 'settings') return <SettingsScreen engine={engine} back={() => setSub('menu')} overlay />;
  const items: [string, string, () => void][] = [['play', 'CONTINUAR', () => engine.resume()], ['flag', 'REINICIAR CHECKPOINT', () => { engine.resume(); engine.respawn(false); }]];
  if (run) { items.push(['refresh', 'REINICIAR DESAFIO', () => engine.restartChallenge()]); items.push(['exit', 'ABANDONAR DESAFIO', () => { engine.quitChallenge(); engine.resume(); }]); }
  items.push(['gear', 'CONFIGURAÇÕES', () => setSub('settings')], ['list', 'ESTATÍSTICAS', () => setSub('stats')], ['home', 'MENU PRINCIPAL', () => { engine.toMenu(); onMenu(); }]);
  return (
    <div className="absolute inset-0 bg-black/70 flex items-center justify-center gap-10 p-6">
      <div className="flex flex-col gap-1"><div className="font-title brush text-[80px] leading-none mb-4">{t('PAUSADO')}</div>
        {sub === 'menu' ? items.map(([ic, l, fn]) => <div key={l} className="menu-item" onClick={() => { engine.audio.ui(); fn(); }}><Icon n={ic} fill={ic === 'play'} />{t(l)}</div>)
          : <div className="panel p-5 w-[560px]"><Title icon="list">{t('ESTATÍSTICAS')}</Title><div className="mt-3"><Stats compact /></div><div className="mt-4"><BackBtn onClick={() => setSub('menu')} /></div></div>}
      </div>
      <div className="panel p-5 w-[400px]"><Title icon="gear">{t('Controles')}</Title><div className="mt-2"><ControlsList /></div></div>
    </div>
  );
}

// ------------------------------------------------------------------ resultado
export function ResultScreen({ engine, res, onMenu }: { engine: Engine; res: ResultData; onMenu: () => void }) {
  const title = res.failed ? 'DESAFIO FALHOU' : res.final ? 'PARKOUR CONCLUÍDO!' : 'DESAFIO CONCLUÍDO!';
  const big = res.final;
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-end pb-[6vh] overflow-auto" style={{ background: 'linear-gradient(0deg, rgba(0,0,0,.92) 0, rgba(0,0,0,.6) 55%, transparent 90%)' }}>
      <div className="anim-slide flex flex-col items-center">
        <div className="title-wrap"><div className={`font-title brush text-center leading-[0.95] ${res.failed ? 'text-red-400' : 'text-white'}`} style={{ fontSize: big ? 'clamp(70px,13vh,130px)' : 'clamp(56px,10vh,100px)' }}>{t(title)}</div></div>
        <div className="text-[28px] text-white/80 mt-5 uppercase tracking-wider">{t(res.name)}{res.failed && ` — ${res.reason}`}</div>
        {!res.failed && <div className="mt-3 flex flex-col gap-1 text-[30px]">
          <div className="flex gap-6 justify-between"><span>{t('Tempo Final')}:</span><span className="font-bold text-[#ffc400] min-w-[160px]">{fmtTime(res.time)}</span></div>
          <div className="flex gap-6 justify-between"><span>{t('Pontuação')}:</span><span className="font-bold min-w-[160px]">{fmtNum(res.score)}</span></div>
          <div className="flex gap-6 justify-between items-center"><span>{t('Ranking')}:</span><span className="font-bold min-w-[160px] flex items-center gap-2" style={{ color: MEDAL_COL[res.medal] }}><Medal m={res.medal} size={32} />{MEDAL_NAME[res.medal]}</span></div>
          <div className="flex gap-6 justify-between text-[22px] text-[#6dff8a]"><span>XP</span><span className="min-w-[160px] font-bold">+{res.xpGain}{res.newBest ? ' · ★ NOVO RECORDE' : ''}</span></div>
        </div>}
        {res.levelUp > 0 && <div className="mt-3 text-center"><div className="text-[#ffc400] font-title text-[44px]">{t('Nível')} {res.levelUp}!</div><div className="text-[18px] text-white/80 max-w-[560px]">{res.unlock}</div></div>}
        {res.final && <div className="panel p-4 mt-4 w-[min(760px,92vw)]"><div className="text-center text-[#6dff8a] text-[22px] font-bold mb-2">{t('MODO LIVRE')} — a cidade é sua!</div><Stats compact /></div>}
        <div className="flex gap-4 mt-6">
          <Btn onClick={() => { engine.toMenu(); onMenu(); }}><Icon n="home" className="w-5 h-5" />{t('MENU PRINCIPAL')}</Btn>
          {res.failed ? <Btn y onClick={() => engine.restartChallenge()}><Icon n="refresh" className="w-5 h-5" />Tentar novamente</Btn> : <Btn onClick={() => engine.restartChallenge()}><Icon n="refresh" className="w-5 h-5" />Repetir</Btn>}
          <Btn y onClick={() => engine.continueFree()}><Icon n="play" className="w-4 h-4" fill />{t('CONTINUAR')}</Btn>
        </div>
      </div>
    </div>
  );
}
