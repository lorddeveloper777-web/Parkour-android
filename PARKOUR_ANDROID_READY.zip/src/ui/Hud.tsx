import { useEffect, useRef, useState } from 'react';
import type { Engine, Hud as HudT } from '../game/engine';
import { useStore, t } from '../game/store';
import { Icon, clock, fmtNum } from './common';
import { useCallback, useRef as useTouchRef } from 'react';

interface Toast { id: number; text: string; kind: string; sub?: string; t: number }
interface MoveT { id: number; label: string; pts: number; t: number }

function Minimap({ engine }: { engine: Engine }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!; const g = c.getContext('2d')!; let raf = 0, n = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw); if (++n % 2) return;
      const P = engine.player, W = c.width, H = c.height, k = 1024 / 640, view = 80;
      g.clearRect(0, 0, W, H); g.save(); g.beginPath(); g.rect(0, 0, W, H); g.clip(); g.fillStyle = '#0c0f14'; g.fillRect(0, 0, W, H);
      g.translate(W / 2, H / 2); g.rotate(P.yaw);
      const sw = view * k, sx = (P.pos.x + 320) * k - sw / 2, sy = (P.pos.z + 320) * k - sw / 2;
      g.drawImage(engine.mapCanvas, sx, sy, sw, sw, -W / 2, -H / 2, W, H);
      const sc = W / view; const run = engine.run; const ring = run?.currentRing();
      const mark = (x: number, z: number, col: string, r = 5) => { let dx = (x - P.pos.x) * sc, dz = (z - P.pos.z) * sc; const l = Math.hypot(dx, dz), lim = W / 2 - 8; if (l > lim) { dx *= lim / l; dz *= lim / l; } g.fillStyle = col; g.beginPath(); g.arc(dx, dz, r, 0, 7); g.fill(); g.strokeStyle = '#000'; g.lineWidth = 1; g.stroke(); };
      if (ring) mark(ring.x, ring.z, '#ffd400', 6); else if (run && run.r.def.type === 'explore' && run.r.secretIdx >= 0) { const s = engine.world.secrets[run.r.secretIdx]; mark(s.x, s.z, '#b04bff', 6); }
      if (!run) for (const cp of engine.world.cps) { if (Math.hypot(cp.x - P.pos.x, cp.z - P.pos.z) < view * 0.6) mark(cp.x, cp.z, '#6dff8a', 3); }
      g.restore();
      g.fillStyle = '#ffc400'; g.beginPath(); g.moveTo(W / 2, H / 2 - 9); g.lineTo(W / 2 + 6, H / 2 + 7); g.lineTo(W / 2, H / 2 + 3); g.lineTo(W / 2 - 6, H / 2 + 7); g.closePath(); g.fill(); g.strokeStyle = '#000'; g.stroke();
    };
    draw(); return () => cancelAnimationFrame(raf);
  }, [engine]);
  return <canvas ref={ref} width={170} height={170} className="border-2 border-white/70 bg-black/50 shadow-xl" style={{ width: 170, height: 170 }} />;
}

function MobileControls({ engine }: { engine: Engine }) {
  const active = useRef<Record<number, { x: number; y: number }>>({});
  const lookRef = useTouchRef<{ id: number; x: number; y: number } | null>(null);
  const joy = useTouchRef<HTMLDivElement>(null);
  const updateJoy = useCallback((x: number, y: number) => {
    const r = joy.current?.getBoundingClientRect(); if (!r) return;
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2, dx = x - cx, dy = y - cy, max = r.width * 0.36;
    const d = Math.min(max, Math.hypot(dx, dy)), a = Math.atan2(dy, dx);
    const nx = d ? Math.cos(a) * d / max : 0, ny = d ? Math.sin(a) * d / max : 0;
    engine.setTouchMove(-ny, nx);
    const knob = r.querySelector('[data-knob]') as HTMLElement | null;
    if (knob) knob.style.transform = `translate(${nx * 38}px, ${ny * 38}px)`;
  }, [engine]);
  const endJoy = useCallback((id: number) => { delete active.current[id]; engine.setTouchMove(0, 0); const k = joy.current?.querySelector('[data-knob]') as HTMLElement | null; if (k) k.style.transform = 'translate(0,0)'; }, [engine]);
  const joyDown = (e: React.PointerEvent) => { if (e.pointerType === 'mouse') return; active.current[e.pointerId] = { x: e.clientX, y: e.clientY }; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); updateJoy(e.clientX, e.clientY); };
  const joyMove = (e: React.PointerEvent) => { if (active.current[e.pointerId]) updateJoy(e.clientX, e.clientY); };
  const joyUp = (e: React.PointerEvent) => endJoy(e.pointerId);
  const lookDown = (e: React.PointerEvent) => { if (e.pointerType === 'mouse') return; lookRef.current = { id: e.pointerId, x: e.clientX, y: e.clientY }; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); };
  const lookMove = (e: React.PointerEvent) => { const l = lookRef.current; if (!l || l.id !== e.pointerId) return; engine.touchLook(e.clientX - l.x, e.clientY - l.y); l.x = e.clientX; l.y = e.clientY; };
  const lookUp = () => { lookRef.current = null; };
  const action = (name: 'jump' | 'crouch' | 'dash' | 'interact') => (e: React.PointerEvent) => { e.preventDefault(); engine.touchAction(name); };
  return <div className="mobile-controls">
    <div className="mobile-look" onPointerDown={lookDown} onPointerMove={lookMove} onPointerUp={lookUp} onPointerCancel={lookUp} />
    <div ref={joy} className="mobile-joy" onPointerDown={joyDown} onPointerMove={joyMove} onPointerUp={joyUp} onPointerCancel={joyUp}><div data-knob className="mobile-knob" /></div>
    <div className="mobile-actions">
      <button className="mobile-btn jump" onPointerDown={action('jump')}>↑</button>
      <button className="mobile-btn" onPointerDown={action('dash')}>DASH</button>
      <button className="mobile-btn" onPointerDown={(e) => { action('crouch')(e); engine.setTouchCrouch(true); }} onPointerUp={() => engine.setTouchCrouch(false)} onPointerCancel={() => engine.setTouchCrouch(false)}>SLIDE</button>
      <button className="mobile-btn interact" onPointerDown={action('interact')}>E</button>
    </div>
    <div className="mobile-sprint" onPointerDown={() => engine.setTouchSprint(true)} onPointerUp={() => engine.setTouchSprint(false)} onPointerCancel={() => engine.setTouchSprint(false)}>RUN</div>
  </div>;
}

export default function Hud({ engine }: { engine: Engine }) {
  const { settings } = useStore();
  const [h, setH] = useState<HudT>({ ...engine.hud });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [moves, setMoves] = useState<MoveT[]>([]);
  const [flash, setFlash] = useState<{ k: string; id: number } | null>(null);
  useEffect(() => {
    const iv = setInterval(() => setH({ ...engine.hud, objective: engine.hud.objective }), 66);
    const u1 = engine.on('toast', (d) => { setToasts((a) => [...a.slice(-3), { ...d, t: Date.now() }]); });
    const u2 = engine.on('move', (d) => { setMoves((a) => [...a.slice(-4), { ...d, t: Date.now() }]); });
    const u3 = engine.on('death', () => setFlash({ k: 'death', id: Math.random() }));
    const u4 = engine.on('flash', (k) => setFlash({ k, id: Math.random() }));
    const ex = setInterval(() => { const n = Date.now(); setToasts((a) => a.filter((x) => n - x.t < 2600)); setMoves((a) => a.filter((x) => n - x.t < 1800)); }, 250);
    return () => { clearInterval(iv); clearInterval(ex); u1(); u2(); u3(); u4(); };
  }, [engine]);
  const sp = h.speed; const lines = Math.max(0, Math.min(1, (sp - 28) / 30));
  const limited = h.limit > 0 || h.challenge; const low = h.limit > 0 && h.limit < 10;
  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden" style={{ textShadow: '0 2px 6px rgba(0,0,0,.8)' }}>
      <div className="speedlines" style={{ opacity: lines }} />
      {h.alert && <div className="absolute inset-0" style={{ boxShadow: 'inset 0 0 160px 30px #ff1010', animation: 'pulse-red .6s infinite' }} />}
      {flash && <div key={flash.id} className="absolute inset-0" style={{ background: flash.k === 'death' ? 'radial-gradient(circle,#a00a,#300e)' : 'radial-gradient(circle,transparent 50%,#ffe27a55)', animation: `fade-out ${flash.k === 'death' ? 0.7 : 0.35}s forwards` }} />}
      {/* topo esquerdo */}
      <div className="absolute top-5 left-6 w-[300px]">
        <div className="flex items-center gap-3 text-[38px] leading-none font-bold"><Icon n="run" className="w-9 h-9 text-white" />{Math.round(sp)}<span className="text-[22px] font-semibold opacity-90">km/h</span></div>
        <div className="flex items-center gap-3 text-[34px] leading-none font-bold mt-2 text-white"><Icon n="star" className="w-8 h-8 text-[#ffc400]" fill />{fmtNum(h.score)}</div>
        <div className="mt-2 flex items-baseline gap-2">
          <span key={h.mult} className={`text-[40px] leading-none font-extrabold text-[#ffc400] italic ${h.mult > 1 ? 'anim-pop' : ''}`}>x{h.mult}</span>
          <span className="text-[30px] leading-none font-bold italic">COMBO</span>
          {h.comboPts > 0 && <span className="text-lg text-white/80 ml-1">+{fmtNum(h.comboPts)}</span>}
        </div>
        <div className="h-[6px] w-[210px] bg-white/15 mt-1"><div className="h-full bg-[#ffc400] shadow-[0_0_10px_#ffc400]" style={{ width: `${h.comboT * 100}%` }} /></div>
        <div className="mt-3 flex flex-col gap-1">
          {moves.slice(-4).map((m) => <div key={m.id} className="anim-toast text-[22px] font-bold italic text-white flex gap-2"><span>{m.label}</span><span className="text-[#ffc400]">+{m.pts}</span></div>)}
        </div>
      </div>
      {/* topo direito */}
      <div className="absolute top-5 right-6 text-right">
        {limited && h.countdown <= 0 && <>
          <div className="flex items-center justify-end gap-2 text-[38px] font-bold leading-none"><Icon n="clock" className="w-9 h-9" />{clock(h.time)}</div>
          {h.limit > 0 && <div className={`text-[22px] mt-1 ${low ? 'text-red-400 animate-pulse' : 'text-white/80'}`}>{t('Restante')}: {clock(h.limit)}</div>}
          {h.ringText && <div className="flex items-center justify-end gap-2 text-[30px] font-bold mt-1">{h.ringText}<Icon n="flag" className="w-7 h-7" /></div>}
        </>}
        {h.freeRoam && !h.challenge && <div className="chip text-[#ffc400]">{t('MODO LIVRE')}</div>}
        <div className="text-[16px] opacity-70 mt-1">{h.region}</div>
      </div>
      {/* objetivo */}
      {h.challenge && <div className="absolute top-[170px] right-6 text-right max-w-[360px]">
        <div className="text-[#ffc400] text-[22px] font-extrabold uppercase italic">{t(h.challenge)}</div>
        {h.objective.map((o, i) => <div key={i} className="text-[18px] text-white/90">{o}</div>)}
      </div>}
      {/* contagem */}
      {h.countdown > 0 && <div className="absolute inset-0 flex flex-col items-center justify-center"><div key={Math.ceil(h.countdown)} className="anim-count font-title text-[200px] text-white leading-none" style={{ textShadow: '0 0 40px #ffc400' }}>{Math.ceil(h.countdown)}</div><div className="text-2xl uppercase text-[#ffc400]">{t(h.challenge)}</div></div>}
      {/* mira */}
      <div className="absolute left-1/2 top-1/2 w-[5px] h-[5px] -ml-[2px] -mt-[2px] rounded-full bg-white/80 shadow-[0_0_4px_#000]" />
      {h.prompt && <div className="absolute left-1/2 -translate-x-1/2 bottom-[22%] bg-black/70 border border-[#ffc400] px-5 py-2 text-[24px] font-bold">{h.prompt}</div>}
      {/* toasts centrais */}
      <div className="absolute left-1/2 -translate-x-1/2 top-[18%] flex flex-col items-center gap-2">
        {toasts.map((x) => <div key={x.id} className={`anim-toast text-center px-5 py-1 font-extrabold uppercase italic ${x.kind === 'bad' ? 'text-red-400 text-[28px]' : x.kind === 'good' ? 'text-[#6dff8a] text-[28px]' : x.kind === 'level' ? 'text-[#ffc400] text-[44px]' : 'text-white text-[22px]'}`}>{x.text}{x.sub && <div className="text-[18px] text-white/80 not-italic normal-case font-semibold">{x.sub}</div>}</div>)}
      </div>
      {/* inferior esquerdo: fôlego */}
      <div className="absolute bottom-6 left-6 flex items-center gap-3">
        <div className="w-7 h-7 flex items-center justify-center bg-black/50 border border-white/30"><Icon n="plus" className="w-5 h-5 text-white" /></div>
        <div className="w-[240px] h-[11px] bg-black/55 border border-white/25"><div className="h-full transition-all" style={{ width: `${(h.stamina / h.staminaMax) * 100}%`, background: h.stamina < 25 ? '#ff5050' : '#2ee6a6', boxShadow: '0 0 8px #2ee6a6' }} /></div>
        {h.hasDash && <div className="chip" style={{ background: h.dashCd > 0 ? 'rgba(255,255,255,.1)' : '#ffc400', color: h.dashCd > 0 ? '#aaa' : '#111' }}>Q</div>}
        <div className="chip">{t('Nível')} {h.level}</div>
        <div className="w-24 h-[5px] bg-white/15"><div className="h-full bg-[#ffc400]" style={{ width: `${h.xpPct * 100}%` }} /></div>
      </div>
      {settings.minimap && <div className="absolute bottom-6 right-6"><Minimap engine={engine} /></div>}
      {h.locked && <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-auto cursor-pointer" onClick={() => engine.lock()}><div className="text-4xl font-title tracking-wider">{t('Clique para jogar')}</div></div>}
      <div className="absolute bottom-1 right-2 text-[12px] opacity-50">{h.fps} FPS</div>
      <MobileControls engine={engine} />
    </div>
  );
}
