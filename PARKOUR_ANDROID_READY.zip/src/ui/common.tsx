import { ReactNode } from 'react';
import { t } from '../game/store';

const P: Record<string, string> = {
  play: 'M7 4.5v15l13-7.5z', trophy: 'M7 4h10v3a5 5 0 0 1-10 0V4zM5 5H3v2a3 3 0 0 0 3 3M19 5h2v2a3 3 0 0 1-3 3M12 12v4M8 20h8M10 16h4v4h-4z',
  pin: 'M12 22s7-6.5 7-12a7 7 0 0 0-14 0c0 5.5 7 12 7 12zM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z', shirt: 'M8 3L3 6l2 4 3-1v12h8V9l3 1 2-4-5-3a4 4 0 0 1-8 0z',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  exit: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9', check: 'M5 12.5l4.5 4.5L19 7.5', back: 'M19 12H5M12 19l-7-7 7-7', home: 'M3 11l9-8 9 8v10h-6v-6H9v6H3z',
  flag: 'M5 21V4M5 4h13l-2 4 2 4H5', star: 'M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z', lock: 'M6 11h12v10H6zM8 11V7a4 4 0 0 1 8 0v4',
  run: 'M13 4.5a1.8 1.8 0 1 1-3.6 0 1.8 1.8 0 0 1 3.6 0zM8 21l3-6-2.5-2.5L10 8l4 2 3 3M11.5 15l3.5 2.5V21', clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2', plus: 'M12 5v14M5 12h14',
  crown: 'M3 8l4 4 5-7 5 7 4-4-2 11H5z', refresh: 'M20 11a8 8 0 0 0-14-4M4 4v4h4M4 13a8 8 0 0 0 14 4M20 20v-4h-4', list: 'M4 6h16M4 12h16M4 18h16',
};
export function Icon({ n, className = 'w-5 h-5', fill = false }: { n: string; className?: string; fill?: boolean }) {
  return <svg viewBox="0 0 24 24" className={className} fill={fill ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={fill ? 1 : 2} strokeLinecap="round" strokeLinejoin="round"><path d={P[n] || ''} /></svg>;
}
export const MEDAL_COL = ['#3a3f48', '#cd7f32', '#c0c8d2', '#ffc400'];
export const MEDAL_NAME = ['Sem medalha', 'Bronze', 'Prata', 'Ouro'];
export function Medal({ m, size = 36, locked = false }: { m: number; size?: number; locked?: boolean }) {
  const c = MEDAL_COL[m];
  return <div style={{ width: size, height: size, borderRadius: '50%', background: m ? `radial-gradient(circle at 35% 30%, #fff8, ${c} 40%, ${c}aa)` : 'transparent', border: `3px solid ${m ? c : '#555'}`, boxShadow: m ? `0 0 14px ${c}88` : 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}>
    {m ? <Icon n="star" className="w-1/2 h-1/2 text-black/60" fill /> : locked ? <Icon n="lock" className="w-1/2 h-1/2 text-white/30" /> : null}
  </div>;
}
export function Btn({ children, onClick, y = false, disabled = false, className = '' }: { children: ReactNode; onClick?: () => void; y?: boolean; disabled?: boolean; className?: string }) {
  return <button disabled={disabled} onClick={onClick} className={`${y ? 'btn-y' : 'btn-g'} ${className}`}>{children}</button>;
}
export function BackBtn({ onClick }: { onClick: () => void }) { return <Btn onClick={onClick}><Icon n="back" className="w-5 h-5" />{t('VOLTAR')}</Btn>; }
export function Title({ icon, children }: { icon: string; children: ReactNode }) {
  return <div className="flex items-center gap-3 text-[32px] font-title text-white tracking-wide"><Icon n={icon} className="w-8 h-8" />{children}</div>;
}
export const fmt2 = (n: number) => String(Math.floor(n)).padStart(2, '0');
export function clock(sec: number) { const s = Math.max(0, sec); const m = Math.floor(s / 60); return `${fmt2(m)}:${(s - m * 60).toFixed(2).padStart(5, '0')}`; }
export function fmtNum(n: number) { return Math.round(n).toLocaleString('pt-BR'); }
