import { useEffect, useRef, useState } from 'react';
import { Engine, Mode, ResultData } from './game/engine';
import { useStore } from './game/store';
import Hud from './ui/Hud';
import { MainMenu, ChallengesScreen, MapScreen, ExitScreen, Screen, Stats, DetailPanel } from './ui/Menus';
import { CustomScreen, SettingsScreen, PauseScreen, ResultScreen } from './ui/Screens2';
import { BackBtn, Title } from './ui/common';

let engineSingleton: Engine | null = null;
function getEngine() { if (!engineSingleton) engineSingleton = new Engine(); return engineSingleton; }

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  const [engine, setEngine] = useState<Engine | null>(null);
  const [screen, setScreen] = useState<Screen>('main');
  const [mode, setMode] = useState<Mode>('menu');
  const [result, setResult] = useState<ResultData | null>(null);
  const [sel, setSel] = useState('c1');
  const [err, setErr] = useState('');
  useStore();

  useEffect(() => {
    const id = setTimeout(() => {
      try { const e = getEngine(); e.mount(host.current!); setEngine(e); } catch (x: any) { console.error(x); setErr(String(x?.message || x)); }
    }, 80);
    return () => clearTimeout(id);
  }, []);
  useEffect(() => {
    if (!engine) return;
    const u1 = engine.on('mode', (m: Mode) => setMode(m));
    const u2 = engine.on('result', (r: ResultData) => setResult(r));
    return () => { u1(); u2(); };
  }, [engine]);
  useEffect(() => {
    if (!engine || mode !== 'menu') return;
    engine.setView(screen === 'custom' ? 'custom' : screen === 'map' ? 'map' : screen === 'challenges' ? 'challenges' : screen === 'settings' ? 'settings' : 'main');
  }, [engine, screen, mode]);

  const back = () => { engine?.audio.uiBack(); setScreen('main'); };
  return (
    <div className="fixed inset-0 bg-black overflow-hidden" onPointerDown={() => engine?.initAudio()}>
      <div ref={host} className="absolute inset-0" style={{ cursor: mode === 'play' ? 'none' : 'default' }} />
      {!engine && !err && <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#07090d]"><div className="font-title brush text-[110px]">PARKOUR</div><div className="text-xl text-white/60 animate-pulse mt-2">Construindo a cidade…</div></div>}
      {err && <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#07090d] p-10 text-center"><div className="text-3xl text-red-400 mb-3">Não foi possível iniciar o jogo 3D</div><div className="text-white/70 max-w-xl">{err}</div><div className="text-white/50 mt-3">Verifique se o seu navegador suporta WebGL.</div></div>}
      {engine && mode === 'menu' && (<>
        {screen === 'main' && <MainMenu engine={engine} go={setScreen} />}
        {screen === 'challenges' && <ChallengesScreen engine={engine} back={back} sel={sel} setSel={setSel} />}
        {screen === 'map' && <MapScreen engine={engine} back={back} sel={sel} setSel={setSel} />}
        {screen === 'custom' && <CustomScreen engine={engine} back={back} />}
        {screen === 'settings' && <SettingsScreen engine={engine} back={back} />}
        {screen === 'stats' && <div className="absolute inset-0 flex items-center justify-center bg-black/60"><div className="panel p-6 w-[640px] anim-slide"><Title icon="list">ESTATÍSTICAS</Title><div className="mt-4"><Stats /></div><div className="mt-5"><BackBtn onClick={back} /></div></div></div>}
        {screen === 'exit' && <ExitScreen back={back} />}
      </>)}
      {engine && mode === 'play' && <Hud engine={engine} />}
      {engine && mode === 'pause' && <PauseScreen engine={engine} onMenu={() => setScreen('main')} />}
      {engine && mode === 'result' && result && <ResultScreen engine={engine} res={result} onMenu={() => setScreen('main')} />}
    </div>
  );
}
void DetailPanel;
