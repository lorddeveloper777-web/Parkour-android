# PARKOUR — Android

Este projeto foi preparado para Android com Capacitor e controles touch.

## Gerar APK

1. Instale Node.js 22+ e Android Studio.
2. Abra um terminal nesta pasta.
3. Execute:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio: `Build > Generate App Bundles or APKs > Generate APKs`.

Para testar no celular conectado por USB:

```bash
npm run android:run
```

O jogo usa controles touch no celular: joystick esquerdo, área direita para câmera, pulo, dash, slide, interação e corrida.
